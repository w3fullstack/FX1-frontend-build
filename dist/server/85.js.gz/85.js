exports.ids = [85];
exports.modules = {

/***/ 1252:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQOption_vue_vue_type_style_index_0_id_917a1772_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(969);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQOption_vue_vue_type_style_index_0_id_917a1772_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQOption_vue_vue_type_style_index_0_id_917a1772_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQOption_vue_vue_type_style_index_0_id_917a1772_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQOption_vue_vue_type_style_index_0_id_917a1772_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1253:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".faqbox[data-v-917a1772]{background-color:#08252c;border-radius:8px;border:1px solid #557278;padding:20px;cursor:pointer}.faqbox .inner-text[data-v-917a1772]{border-top:1px solid #557278;padding-top:23px;margin-top:12px}.faqbox img[data-v-917a1772]{padding-top:4px}.faqbox>.row[data-v-917a1772]{width:100%}.faqbox .col-L[data-v-917a1772]{max-width:85%}.faqbox .col-L[data-v-917a1772],.faqbox .col-R[data-v-917a1772]{min-width:0;width:auto;flex:10000 1 0%}.faqbox .col-R[data-v-917a1772]{max-width:15%}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1254:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQSection_vue_vue_type_style_index_0_id_2fb69a77_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(970);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQSection_vue_vue_type_style_index_0_id_2fb69a77_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQSection_vue_vue_type_style_index_0_id_2fb69a77_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQSection_vue_vue_type_style_index_0_id_2fb69a77_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQSection_vue_vue_type_style_index_0_id_2fb69a77_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1255:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".token-faq-section[data-v-2fb69a77]{width:100%;position:relative;overflow:hidden;padding:100px 0 150px;z-index:2}.token-faq-section[data-v-2fb69a77] .top-margin-a{margin-top:25px}.token-faq-section[data-v-2fb69a77] .top-margin-b{margin-top:50px}.token-faq-section[data-v-2fb69a77] .top-margin-c{margin-top:150px}.token-faq-section[data-v-2fb69a77] .top-margin-d{margin-top:10px}.token-faq-section[data-v-2fb69a77] .top-margin-e{margin-top:30px}.token-faq-section[data-v-2fb69a77] .col-left{margin-right:1%}.token-faq-section[data-v-2fb69a77] .col-right{margin-left:1%}.token-faq-section[data-v-2fb69a77] .actions{margin:12px}.token-faq-section[data-v-2fb69a77] .btn-left a,.token-faq-section[data-v-2fb69a77] .btn-right a{width:200px;height:60px;border-radius:8px}.token-faq-section[data-v-2fb69a77] .btn-right a{background-color:transparent;outline:1px solid #fff}.token-faq-section[data-v-2fb69a77] .whatbox{padding:60px 0;background:linear-gradient(268.82deg,rgba(136,107,242,.8) 56.01%,rgba(136,107,242,0) 122.21%);border-radius:12px}.token-faq-section[data-v-2fb69a77] .address{margin-top:30px}@media screen and (max-width:1021px){.token-faq-section[data-v-2fb69a77]{padding:50px 0}.token-faq-section[data-v-2fb69a77] .col{flex:none!important;width:100%!important;margin:0!important}.token-faq-section[data-v-2fb69a77] h1.token-h{font-size:20px;letter-spacing:.01em;font-weight:700}.token-faq-section[data-v-2fb69a77] .top-margin-a{margin-top:0!important}.token-faq-section[data-v-2fb69a77] .top-margin-c{margin-top:100px}.token-faq-section[data-v-2fb69a77] .faqbox{position:relative!important;display:flex;margin-bottom:15px!important}.token-faq-section[data-v-2fb69a77] .whatbox{padding:30px 0}.token-faq-section[data-v-2fb69a77] .actions.text-left,.token-faq-section[data-v-2fb69a77] .actions.text-right{text-align:center!important}.token-faq-section[data-v-2fb69a77] .btn-left,.token-faq-section[data-v-2fb69a77] .btn-right{max-width:42%!important;height:60px!important}.token-faq-section[data-v-2fb69a77] .btn-left a,.token-faq-section[data-v-2fb69a77] .btn-right a{margin:0!important;width:100%!important;height:60px!important}.token-faq-section[data-v-2fb69a77] .btn-left,.token-faq-section[data-v-2fb69a77] .btn-right{margin-left:4%!important;margin-right:4%!important;text-align:center!important}.token-faq-section[data-v-2fb69a77] .top-margin-c{margin-top:35px!important}.token-faq-section[data-v-2fb69a77] .actions{text-align:center!important;margin-top:25px!important}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1314:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/FAQSection.vue?vue&type=template&id=2fb69a77&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"token-faq-section row",attrs:{"id":"faq"}},[_vm._ssrNode("<div class=\"container token-container text-center\" data-v-2fb69a77>","</div>",[_vm._ssrNode("<h1 data-v-2fb69a77>FAQ</h1><div class=\"top-margin-b\" data-v-2fb69a77></div>"),_vm._l((Math.ceil(_vm.faqOptions.length / 2)),function(_,index){return _vm._ssrNode("<div class=\"row top-margin-a\" data-v-2fb69a77>","</div>",[_vm._ssrNode("<div"+(_vm._ssrClass("col",{'col-left': _vm.faqOptions[index * 2 + 1]}))+" data-v-2fb69a77>","</div>",[_c('FAQOption',{attrs:{"option":_vm.faqOptions[index * 2]}})],1),(_vm.faqOptions[index * 2 + 1])?_vm._ssrNode("<div class=\"col col-right\" data-v-2fb69a77>","</div>",[_c('FAQOption',{attrs:{"option":_vm.faqOptions[index * 2 + 1]}})],1):_vm._e()])}),_vm._ssrNode("<div class=\"top-margin-c\" data-v-2fb69a77></div><div class=\"row text-center\" data-v-2fb69a77><div class=\"col\" data-v-2fb69a77><div class=\"whatbox\" data-v-2fb69a77><h1 class=\"token-h\" data-v-2fb69a77>What are you waiting for?</h1><div class=\"top-margin-a\" data-v-2fb69a77></div><div class=\"row\" data-v-2fb69a77><div class=\"col actions text-right btn-left\" data-v-2fb69a77><a href=\"https://app.uniswap.org/#/swap?outputCurrency=0x610C584F1275f0f7c982Af0aC7883Ff4Dba661Bd\" target=\"_blank\" class=\"button is-primary\" data-v-2fb69a77>Buy $FX1</a></div><div class=\"col actions text-left btn-right\" data-v-2fb69a77><a href=\"https://www.dextools.io/app/en/ether/pair-explorer/0x87B958067FD665f3937de4439450B4950Eb68e15\" target=\"_blank\" class=\"button is-primary\" data-v-2fb69a77>View Chart</a></div></div></div></div></div><div class=\"top-margin-e\" data-v-2fb69a77><span class=\"address\" data-v-2fb69a77>Contract Address:<span data-v-2fb69a77>0x610C584F1275f0f7c982Af0aC7883Ff4Dba661Bd</span></span></div>")],2)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Token/FAQSection.vue?vue&type=template&id=2fb69a77&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/atoms/Token/FAQOption.vue?vue&type=template&id=917a1772&scoped=true&lang=pug&
var FAQOptionvue_type_template_id_917a1772_scoped_true_lang_pug_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"faqbox",on:{"click":function($event){$event.preventDefault();return _vm.expand()}}},[_vm._ssrNode("<div class=\"row\" data-v-917a1772><div class=\"col-L text-left\" data-v-917a1772><p class=\"token-p3\" data-v-917a1772>"+_vm._ssrEscape(_vm._s(_vm.option.title))+"</p></div><div class=\"col-R text-right\" data-v-917a1772>"+((_vm.isOpened)?("<img"+(_vm._ssrAttr("src",__webpack_require__(638)))+" alt=\"Close\" data-v-917a1772>"):"<!---->")+((!_vm.isOpened)?("<img"+(_vm._ssrAttr("src",__webpack_require__(637)))+" alt=\"Open\" data-v-917a1772>"):"<!---->")+"</div>"+((_vm.isOpened)?("<div class=\"row\" data-v-917a1772><p class=\"token-p inner-text text-left\" data-v-917a1772>"+_vm._ssrEscape(_vm._s(_vm.option.description))+"</p></div>"):"<!---->")+"</div>")])}
var FAQOptionvue_type_template_id_917a1772_scoped_true_lang_pug_staticRenderFns = []


// CONCATENATED MODULE: ./components/atoms/Token/FAQOption.vue?vue&type=template&id=917a1772&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/atoms/Token/FAQOption.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var FAQOptionvue_type_script_lang_js_ = ({
  name: 'FAQOption',
  props: {
    option: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      isOpened: false
    };
  },
  methods: {
    expand() {
      this.isOpened = !this.isOpened;
    }
  }
});
// CONCATENATED MODULE: ./components/atoms/Token/FAQOption.vue?vue&type=script&lang=js&
 /* harmony default export */ var Token_FAQOptionvue_type_script_lang_js_ = (FAQOptionvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/atoms/Token/FAQOption.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1252)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Token_FAQOptionvue_type_script_lang_js_,
  FAQOptionvue_type_template_id_917a1772_scoped_true_lang_pug_render,
  FAQOptionvue_type_template_id_917a1772_scoped_true_lang_pug_staticRenderFns,
  false,
  injectStyles,
  "917a1772",
  "2916e1d4"
  
)

/* harmony default export */ var FAQOption = (component.exports);
// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/FAQSection.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var FAQSectionvue_type_script_lang_js_ = ({
  name: 'FAQSection',
  components: {
    FAQOption: FAQOption
  },
  data() {
    return {
      faqOptions: [{
        title: "What is $FX1?",
        description: "FX1 is revolutionizing the way we watch, consume, and pay for live sports. By harnessing the power of Blockchain and A.I. technology, FX1 delivers an unparalleled and groundbreaking experience for consuming live sports like never before."
      }, {
        title: "Where I can buy $FX1?",
        description: "$FX1 will be available to trade on Uniswap, a leading decentralized exchange. See the section above for any help needed using Uniswap."
      }, {
        title: "What can I use $FX1 for?",
        description: "You’ll be able to use the token to purchase event room services, as well as build up your collection of NFT collectibles. Using $FX1 to purchase event room experiences will be available later in 2023 as we release those features to event rooms."
      }, {
        title: "Will you have staking available?",
        description: "No, traditional staking won’t be available however by holding our token you’ll be given the chance to access private event rooms and digital collectibles that you can add to your profile."
      }, {
        title: "Will I be able to watch sports on FX1?",
        description: "No, you won’t find the traditional video stream on FX1 for the games we offer. Instead, we provide a new experience built using A.I. and Blockchain technology."
      }, {
        title: "Can you tell me more about your Ambassador program?",
        description: "As an ambassador, you have a greater ability to earn when bringing over your community, and you’ll also be able to charge a ticket fee for access to event rooms you host."
      }, {
        title: "How do I connect with friends to watch sports on FX1?",
        description: "Simple, when you enter an event room for a game just click the button to create a private room and when provided with the share link just share with your friends or community."
      }]
    };
  },
  methods: {
    showAlertMessage() {
      this.$toast.info('$FX1 available to purchase mid to late April', {
        duration: 5000,
        position: 'bottom-left',
        className: 'fx1-success'
      });
    }
  }
});
// CONCATENATED MODULE: ./components/molecules/Token/FAQSection.vue?vue&type=script&lang=js&
 /* harmony default export */ var Token_FAQSectionvue_type_script_lang_js_ = (FAQSectionvue_type_script_lang_js_); 
// CONCATENATED MODULE: ./components/molecules/Token/FAQSection.vue



function FAQSection_injectStyles (context) {
  
  var style0 = __webpack_require__(1254)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var FAQSection_component = Object(componentNormalizer["a" /* default */])(
  Token_FAQSectionvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  FAQSection_injectStyles,
  "2fb69a77",
  "4571a90b"
  
)

/* harmony default export */ var FAQSection = __webpack_exports__["default"] = (FAQSection_component.exports);

/***/ }),

/***/ 637:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjgiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCAyOCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0xNy42NDUgMC44OTQ1MzFMMjYuNzUgOS45OTk1M0wxNy42NDUgMTkuMTA0NU0xLjI1IDkuOTk5NTNIMjYuNDk1IiBzdHJva2U9IndoaXRlIiBzdHJva2Utd2lkdGg9IjEuNSIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 638:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjgiIHZpZXdCb3g9IjAgMCAyMCAyOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0xOS4xMDQ1IDEwLjM1NUw5Ljk5OTUzIDEuMjVMMC44OTQ1MzEgMTAuMzU1TTkuOTk5NTMgMjYuNzVWMS41MDUiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS13aWR0aD0iMS41IiBzdHJva2UtbWl0ZXJsaW1pdD0iMTAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPg0KPC9zdmc+DQo="

/***/ }),

/***/ 969:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1253);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("78509bb9", content, true, context)
};

/***/ }),

/***/ 970:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1255);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("c0f985d6", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=85.js.map
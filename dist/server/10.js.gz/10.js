exports.ids = [10];
exports.modules = {

/***/ 1146:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Navigation_vue_vue_type_style_index_0_id_29857d6d_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(916);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Navigation_vue_vue_type_style_index_0_id_29857d6d_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Navigation_vue_vue_type_style_index_0_id_29857d6d_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Navigation_vue_vue_type_style_index_0_id_29857d6d_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Navigation_vue_vue_type_style_index_0_id_29857d6d_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1147:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xo-default-footer-navigation[data-v-29857d6d] .desktop{flex-flow:row;grid-gap:82px;gap:82px}.xo-default-footer-navigation[data-v-29857d6d] .desktop .navigation-container{font-size:16px}.xo-default-footer-navigation[data-v-29857d6d] .desktop .navigation-container ._title{font-style:normal;font-weight:500;line-height:20px;margin-bottom:16px}.xo-default-footer-navigation[data-v-29857d6d] .desktop .navigation-container .links{grid-gap:16px;gap:16px}.xo-default-footer-navigation[data-v-29857d6d] .desktop .navigation-container .links a{color:#fff;font-weight:300;line-height:24px;display:flex;flex-flow:row;align-items:center;grid-gap:12px;gap:12px}.xo-default-footer-navigation[data-v-29857d6d] .desktop .navigation-container .links a img{width:20px;height:20px}.xo-default-footer-navigation[data-v-29857d6d] .desktop .navigation-container .links a:hover{text-decoration:underline}@media screen and (max-width:1023px){.xo-default-footer-navigation[data-v-29857d6d] .desktop{justify-content:space-around}}@media screen and (max-width:767px){.xo-default-footer-navigation[data-v-29857d6d] .desktop{flex-flow:column;align-items:flex-start;justify-content:flex-start;grid-gap:40px;gap:40px}.xo-default-footer-navigation[data-v-29857d6d] .desktop .navigation-container .links{flex-flow:row;grid-gap:30px;gap:30px}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1360:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/Default/Footer/Navigation.vue?vue&type=template&id=29857d6d&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xo-default-footer-navigation"},[_vm._ssrNode("<div class=\"row desktop\" data-v-29857d6d>","</div>",[_vm._l((_vm.navigationList),function(navigation,index){return [_vm._ssrNode("<div class=\"navigation-container\" data-v-29857d6d>","</div>",[_vm._ssrNode("<p class=\"_title\" data-v-29857d6d>"+_vm._ssrEscape(_vm._s(navigation.title))+"</p>"),_vm._ssrNode("<div class=\"links flex-column\" data-v-29857d6d>","</div>",_vm._l((navigation.links),function(link,index){return _c('nuxt-link',{key:index,staticClass:"link",attrs:{"to":("/" + (link.url))}},[(link.icon)?_c('img',{attrs:{"src":__webpack_require__(665)("./" + (link.icon) + ".svg"),"alt":link.label}}):_vm._e(),_c('span',[_vm._v(_vm._s(link.label))])])}),1)],2)]})],2)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/Default/Footer/Navigation.vue?vue&type=template&id=29857d6d&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/Default/Footer/Navigation.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Navigationvue_type_script_lang_js_ = ({
  name: 'XODefaultFooterNavigation',
  data() {
    return {
      navigationList: [{
        title: 'Product',
        links: [{
          label: 'Leagues & Clubs',
          url: 'explore'
        }, {
          label: 'Customer Support',
          url: 'locker-room/fx-1-support/'
        }]
      }, {
        title: 'Company',
        links: [{
          label: 'About',
          url: 'about'
        }, {
          label: 'Contact',
          url: 'contact'
        }]
      }, {
        title: 'Legal stuff',
        links: [{
          label: 'Terms',
          url: 'terms-conditions'
        }, {
          label: 'Privacy',
          url: 'privacy'
        }]
      }, {
        title: 'Socials',
        links: [{
          label: 'Telegram',
          icon: 'telegram-footer',
          url: 'https://t.me/fx1_sports_portal'
        }, {
          label: 'Twitter',
          icon: 'twitter-footer',
          url: 'https://twitter.com/FX1Sports'
        }, {
          label: 'Medium',
          icon: 'medium-footer',
          url: 'https://medium.com/fx1sports'
        }]
      }]
    };
  }
});
// CONCATENATED MODULE: ./components/organisms/Default/Footer/Navigation.vue?vue&type=script&lang=js&
 /* harmony default export */ var Footer_Navigationvue_type_script_lang_js_ = (Navigationvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/organisms/Default/Footer/Navigation.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1146)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Footer_Navigationvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "29857d6d",
  "1d4cfa65"
  
)

/* harmony default export */ var Navigation = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 486:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/app-store-group.352ef34.svg";

/***/ }),

/***/ 487:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/app-store.39fe2f5.svg";

/***/ }),

/***/ 488:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAiIGhlaWdodD0iNiIgdmlld0JveD0iMCAwIDEwIDYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+DQo8cGF0aCBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTIuODU4ODNlLTA4IDAuODQ5MzM2TDQuOTUyMTMgNS44MDE0N0w1IDUuNzUzNkw1LjA0Nzg3IDUuODAxNDdMMTAgMC44NDkzMzZMOS4zNDU5OCAwLjE5NTMxMkw1IDQuNTQxMjlMMC42NTQwMjQgMC4xOTUzMTJMMi44NTg4M2UtMDggMC44NDkzMzZaIiBmaWxsPSJ3aGl0ZSIvPg0KPC9zdmc+DQo="

/***/ }),

/***/ 489:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/discord.f1104f0.svg";

/***/ }),

/***/ 490:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxMCAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik02LjI0NDUgMTZWOC43MTExMUg4LjczMzM5TDkuMDg4OTQgNS44NjY2N0g2LjI0NDVWNC4wODg4OUM2LjI0NDUgMy4yODg4OSA2LjUxMTE3IDIuNjY2NjcgNy42NjY3MiAyLjY2NjY3SDkuMTc3ODNWMC4wODg4ODg5QzguODIyMjggMC4wODg4ODg5IDcuOTMzMzggMCA2Ljk1NTU5IDBDNC44MjIyNiAwIDMuMzExMTUgMS4zMzMzMyAzLjMxMTE1IDMuNzMzMzNWNS44NjY2N0gwLjgyMjI2NlY4LjcxMTExSDMuMzExMTVWMTZINi4yNDQ1WiIgZmlsbD0id2hpdGUiLz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 491:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/google-play-group.e80e818.svg";

/***/ }),

/***/ 492:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/instagram.52a516e.svg";

/***/ }),

/***/ 493:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0xNiAxNS42NDQxVjkuNzI4MDZDMTYgNi41NTgwNiAxNC4zMDggNS4wODMwNiAxMi4wNTIgNS4wODMwNkMxMC4yMzE1IDUuMDgzMDYgOS40MTU1IDYuMDg0NTYgOC45NjEgNi43ODc1NlY1LjMyNTU2SDUuNTMxQzUuNTc2NSA2LjI5NDA2IDUuNTMxIDE1LjY0NDEgNS41MzEgMTUuNjQ0MUg4Ljk2MVY5Ljg4MTU2QzguOTYxIDkuNTc0MDYgOC45ODMgOS4yNjU1NiA5LjA3NCA5LjA0NTU2QzkuMzIxNSA4LjQyOTA2IDkuODg2IDcuNzkxMDYgMTAuODMzIDcuNzkxMDZDMTIuMDc0NSA3Ljc5MTA2IDEyLjU3MDUgOC43MzcwNiAxMi41NzA1IDEwLjEyNDFWMTUuNjQ0NkgxNlYxNS42NDQxWk0xLjkxNzUgMy45MTcwNkMzLjExMyAzLjkxNzA2IDMuODU4NSAzLjEyNDA2IDMuODU4NSAyLjEzMzU2QzMuODM2NSAxLjEyMTU2IDMuMTEzNSAwLjM1MTU2MiAxLjk0MDUgMC4zNTE1NjJDMC43Njc1IDAuMzUxNTYyIDAgMS4xMjEwNiAwIDIuMTMzNTZDMCAzLjEyNDA2IDAuNzQ0NSAzLjkxNzA2IDEuODk2IDMuOTE3MDZIMS45MTc1Wk0zLjYzMjUgMTUuNjQ0MVY1LjMyNTU2SDAuMjAzVjE1LjY0NDFIMy42MzI1WiIgZmlsbD0id2hpdGUiLz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 494:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzYiIGhlaWdodD0iMjIiIHZpZXdCb3g9IjAgMCAzNiAyMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0yMC4zMDYyIDExQzIwLjMwNjIgMTYuNTkxMyAxNS43NjEzIDIxLjEyNSAxMC4xNTIgMjEuMTI1QzguODIwNTkgMjEuMTI2OCA3LjUwMTg3IDIwLjg2NjMgNi4yNzExMyAyMC4zNTg0QzUuMDQwNCAxOS44NTA2IDMuOTIxNzQgMTkuMTA1MyAyLjk3OTA0IDE4LjE2NTFDMi4wMzYzNCAxNy4yMjQ5IDEuMjg4MDYgMTYuMTA4MiAwLjc3NjkxMSAxNC44Nzg4QzAuMjY1NzY2IDEzLjY0OTQgMC4wMDE3NzE2NyAxMi4zMzE0IDAgMTFDMCA1LjQwNjUxIDQuNTQ1IDAuODc1MDEyIDEwLjE1MiAwLjg3NTAxMkMxMS40ODM2IDAuODcyOTQyIDEyLjgwMjYgMS4xMzMyMSAxNC4wMzM2IDEuNjQwOTRDMTUuMjY0NiAyLjE0ODY4IDE2LjM4MzUgMi44OTM5NCAxNy4zMjY0IDMuODM0MTdDMTguMjY5NCA0Ljc3NDM5IDE5LjAxNzggNS44OTExNSAxOS41MjkxIDcuMTIwNjhDMjAuMDQwNCA4LjM1MDIxIDIwLjMwNDUgOS42Njg0MiAyMC4zMDYyIDExWk0zMS40NDM4IDExQzMxLjQ0MzggMTYuMjY1IDI5LjE3MTIgMjAuNTMxIDI2LjM2NzggMjAuNTMxQzIzLjU2NDIgMjAuNTMxIDIxLjI5MTcgMTYuMjYyOCAyMS4yOTE3IDExQzIxLjI5MTcgNS43MzUwMSAyMy41NjQyIDEuNDY5MDEgMjYuMzY3OCAxLjQ2OTAxQzI5LjE3MTIgMS40NjkwMSAzMS40NDM4IDUuNzM3MjYgMzEuNDQzOCAxMVpNMzYgMTFDMzYgMTUuNzE2IDM1LjIwMTMgMTkuNTM4OCAzNC4yMTM1IDE5LjUzODhDMzMuMjI4IDE5LjUzODggMzIuNDI5MiAxNS43MTM4IDMyLjQyOTIgMTFDMzIuNDI5MiA2LjI4NDAxIDMzLjIyOCAyLjQ2MTI2IDM0LjIxNTcgMi40NjEyNkMzNS4yMDEyIDIuNDYxMjYgMzYgNi4yODQwMSAzNiAxMVoiIGZpbGw9IndoaXRlIi8+DQo8L3N2Zz4NCg=="

/***/ }),

/***/ 495:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/playstore.30d85aa.svg";

/***/ }),

/***/ 496:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMjciIHZpZXdCb3g9IjAgMCAzMiAyNyIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0yOS4wNjUgMC40ODE3NjNDMjkuMDY1IDAuNDgxNzYzIDMxLjk3ODcgLTAuNjU0NDg3IDMxLjczNSAyLjEwNDc2QzMxLjY1NDcgMy4yNDEwMSAzMC45MjY1IDcuMjE4MjYgMzAuMzU5NSAxMS41MTk1TDI4LjQxNyAyNC4yNjJDMjguNDE3IDI0LjI2MiAyOC4yNTUgMjYuMTI4OCAyNi43OTc3IDI2LjQ1MzVDMjUuMzQxMiAyNi43Nzc1IDIzLjE1NTcgMjUuMzE3MyAyMi43NTA3IDI0Ljk5MjVDMjIuNDI2NyAyNC43NDg4IDE2LjY4MDIgMjEuMDk2MyAxNC42NTY3IDE5LjMxMTNDMTQuMDg5NyAxOC44MjM4IDEzLjQ0MTcgMTcuODUwMyAxNC43Mzc3IDE2LjcxNEwyMy4yMzYgOC41OTc1MUMyNC4yMDcyIDcuNjI0MDEgMjUuMTc4NSA1LjM1MTUxIDIxLjEzMTUgOC4xMTA3Nkw5Ljc5OSAxNS44MjA4QzkuNzk5IDE1LjgyMDggOC41MDM3NSAxNi42MzMgNi4wNzU5OSAxNS45MDI1TDAuODEzOTk0IDE0LjI3ODhDMC44MTM5OTQgMTQuMjc4OCAtMS4xMjg1MSAxMy4wNjE1IDIuMTkwMjQgMTEuODQ0M0MxMC4yODUgOC4wMjk3NiAyMC4yNDEyIDQuMTM0MjYgMjkuMDYzNSAwLjQ4MTc2M0gyOS4wNjVaIiBmaWxsPSJ3aGl0ZSIvPg0KPC9zdmc+DQo="

/***/ }),

/***/ 497:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNMTMuMTg1NSAyLjk1MzA2QzEzLjkxMDggMi42NDc2OCAxNC42ODgzIDMuMjYwOTcgMTQuNTYwMiA0LjAzNzQzTDEzLjA0NzYgMTMuMjA4NkMxMi45MDE4IDE0LjA5MjggMTEuOTMwNiAxNC42MDAyIDExLjExOTMgMTQuMTU5NkMxMC40NDA0IDEzLjc5MDggOS40MzMyNSAxMy4yMjMzIDguNTI1NTEgMTIuNjMwMkM4LjA3MjI1IDEyLjMzNCA2LjY4NDMxIDExLjM4NDIgNi44NTQ5MSAxMC43MDgyQzcuMDAwNzggMTAuMTMwMSA5LjMzNDA1IDcuOTU4MTcgMTAuNjY3NCA2LjY2NjVDMTEuMTkxMSA2LjE1OTEyIDEwLjk1MjYgNS44NjYwMSAxMC4zMzQgNi4zMzMxN0M4Ljc5OTY1IDcuNDkyMDQgNi4zMzYxOSA5LjI1Mzk3IDUuNTIxNTUgOS43NDk4NEM0LjgwMjggMTAuMTg3MyA0LjQyNzUyIDEwLjI2MiAzLjk3OTg5IDEwLjE4NzNDMy4xNjI0NyAxMC4wNTExIDIuNDA0NjIgOS44NDAxNyAxLjc4NTkgOS41ODM3QzAuOTQ5NjU1IDkuMjM3MDQgMC45OTAzODggOC4wODc4NCAxLjc4NTMzIDcuNzUzMTdMMTMuMTg1NSAyLjk1MzA2WiIgZmlsbD0id2hpdGUiLz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 498:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzMiIGhlaWdodD0iMjYiIHZpZXdCb3g9IjAgMCAzMyAyNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0zMi4xOTAxIDNDMzEuMDM1MSAzLjUyNSAyOS43OTAxIDMuODcgMjguNTAwMSA0LjAzNUMyOS44MjAxIDMuMjQgMzAuODQwMSAxLjk4IDMxLjMyMDEgMC40NjVDMzAuMDc1MSAxLjIxNSAyOC42OTUxIDEuNzQgMjcuMjQwMSAyLjA0QzI2LjA1NTEgMC43NSAyNC4zOTAxIDAgMjIuNTAwMSAwQzE4Ljk3NTEgMCAxNi4wOTUxIDIuODggMTYuMDk1MSA2LjQzNUMxNi4wOTUxIDYuOTQ1IDE2LjE1NTEgNy40NCAxNi4yNjAxIDcuOTA1QzEwLjkyMDEgNy42MzUgNi4xNjUwNiA1LjA3IDMuMDAwMDYgMS4xODVDMi40NDUwNiAyLjEzIDIuMTMwMDYgMy4yNCAyLjEzMDA2IDQuNDFDMi4xMzAwNiA2LjY0NSAzLjI1NTA2IDguNjI1IDQuOTk1MDYgOS43NUMzLjkzMDA2IDkuNzUgMi45NDAwNiA5LjQ1IDIuMDcwMDYgOVY5LjA0NUMyLjA3MDA2IDEyLjE2NSA0LjI5MDA2IDE0Ljc3NSA3LjIzMDA2IDE1LjM2QzYuMjg2MTUgMTUuNjE4MyA1LjI5NTIgMTUuNjU0MyA0LjMzNTA2IDE1LjQ2NUM0Ljc0MjQ3IDE2Ljc0MzcgNS41NDAzNiAxNy44NjI2IDYuNjE2NTggMTguNjY0NEM3LjY5MjggMTkuNDY2MiA4Ljk5MzIzIDE5LjkxMDUgMTAuMzM1MSAxOS45MzVDOC4wNjA1IDIxLjczNTcgNS4yNDEwNSAyMi43MDkgMi4zNDAwNiAyMi42OTVDMS44MzAwNiAyMi42OTUgMS4zMjAwNiAyMi42NjUgMC44MTAwNTkgMjIuNjA1QzMuNjYwMDYgMjQuNDM1IDcuMDUwMDYgMjUuNSAxMC42ODAxIDI1LjVDMjIuNTAwMSAyNS41IDI4Ljk5NTEgMTUuNjkgMjguOTk1MSA3LjE4NUMyOC45OTUxIDYuOSAyOC45OTUxIDYuNjMgMjguOTgwMSA2LjM0NUMzMC4yNDAxIDUuNDQ1IDMxLjMyMDEgNC4zMDUgMzIuMTkwMSAzWiIgZmlsbD0id2hpdGUiLz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 499:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/twitter.384e9c6.svg";

/***/ }),

/***/ 665:
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./app-store-group.svg": 486,
	"./app-store.svg": 487,
	"./chevron-down.svg": 488,
	"./discord.svg": 489,
	"./facebook.svg": 490,
	"./google-play-group.svg": 491,
	"./instagram.svg": 492,
	"./linkedin.svg": 493,
	"./medium-footer.svg": 494,
	"./playstore.svg": 495,
	"./telegram-footer.svg": 496,
	"./telegram.svg": 497,
	"./twitter-footer.svg": 498,
	"./twitter.svg": 499
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 665;

/***/ }),

/***/ 916:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1147);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("b191f1dc", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=10.js.map
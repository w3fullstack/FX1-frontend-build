exports.ids = [120];
exports.modules = {

/***/ 1152:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_MyLocation_vue_vue_type_style_index_0_id_00ff4058_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(919);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_MyLocation_vue_vue_type_style_index_0_id_00ff4058_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_MyLocation_vue_vue_type_style_index_0_id_00ff4058_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_MyLocation_vue_vue_type_style_index_0_id_00ff4058_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_MyLocation_vue_vue_type_style_index_0_id_00ff4058_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1153:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xa-my-location[data-v-00ff4058] .error-input{border:1px solid #f85454!important}.xa-my-location[data-v-00ff4058] .desktop{display:flex;align-items:center;padding-right:30px;white-space:nowrap;cursor:pointer}.xa-my-location[data-v-00ff4058] .desktop i{padding-right:10px;color:#fff}@media screen and (max-width:1260px){.xa-my-location[data-v-00ff4058] .desktop{display:none}}.xa-my-location[data-v-00ff4058] .in-mobile-menu{display:flex;align-items:center;padding-right:30px;white-space:nowrap;cursor:pointer}.xa-my-location[data-v-00ff4058] .in-mobile-menu i{padding-right:10px;color:#fff}.xa-my-location[data-v-00ff4058] .tablet{position:relative;display:none;align-items:center;padding-right:10px;white-space:nowrap;cursor:pointer}@media screen and (max-width:1260px){.xa-my-location[data-v-00ff4058] .tablet{display:flex}}.xa-my-location[data-v-00ff4058] .tablet i{padding-right:10px;color:#94a6aa}.xa-my-location[data-v-00ff4058] .save-button-desktop{background-color:transparent;color:#fff!important}.xa-my-location[data-v-00ff4058] .save-button-desktop,.xa-my-location[data-v-00ff4058] .save-button-tablet{border:1px solid #94a6aa!important;width:125px!important;height:42px!important;line-height:.5!important}.xa-my-location[data-v-00ff4058] .save-button-tablet{color:#2a4e55!important}.xa-my-location[data-v-00ff4058] .error-msg-desktop,.xa-my-location[data-v-00ff4058] .error-msg-in-mobile,.xa-my-location[data-v-00ff4058] .error-msg-tablet{position:relative}.xa-my-location[data-v-00ff4058] .error-msg-desktop p,.xa-my-location[data-v-00ff4058] .error-msg-in-mobile p,.xa-my-location[data-v-00ff4058] .error-msg-tablet p{color:#f85454!important;font-size:10px}@media screen and (max-width:1260px){.xa-my-location[data-v-00ff4058] .error-msg-desktop{display:none}}@media screen and (max-width:1260px){.xa-my-location[data-v-00ff4058] .error-msg-tablet{display:block}}.xa-my-location[data-v-00ff4058] .floating-board{position:absolute;padding:10px 15px;right:-70%;top:100%;margin-top:60%;z-index:1;background-color:#fff;border-radius:5px;box-shadow:0 4px 10px rgba(10,39,46,.15)}.xa-my-location[data-v-00ff4058] .floating-board p{color:#000}.xa-my-location[data-v-00ff4058] .floating-board input{color:#000!important}.xa-my-location[data-v-00ff4058] .floating-board .button{height:100%;min-height:40px;margin-left:10px;width:100%}.xa-my-location[data-v-00ff4058] .edit,.xa-my-location[data-v-00ff4058] .editText,.xa-my-location[data-v-00ff4058] .set-location{display:flex}.xa-my-location[data-v-00ff4058] .notInLine{display:block;text-align:left}.xa-my-location[data-v-00ff4058] .inLine{display:flex;align-items:center}.xa-my-location[data-v-00ff4058] .inLine .mdi-24px.mdi:before{font-size:15px!important}.xa-my-location[data-v-00ff4058] .marginR{margin-right:10px}.xa-my-location[data-v-00ff4058] input{background-color:transparent;width:100%;height:100%;max-height:40px;min-width:210px;border:1px solid #94a6aa!important;color:#fff!important;line-height:.5!important}.xa-my-location[data-v-00ff4058] .smaller-text{font-size:12px}.xa-my-location[data-v-00ff4058] .button{height:100%;min-height:40px;margin-left:10px}.xa-my-location[data-v-00ff4058] ::-moz-placeholder{color:#94a6aa!important;opacity:1}.xa-my-location[data-v-00ff4058] ::placeholder{color:#94a6aa!important;opacity:1}.xa-my-location[data-v-00ff4058] :-ms-input-placeholder{color:#94a6aa!important}.xa-my-location[data-v-00ff4058] ::-ms-input-placeholder{color:#94a6aa!important}.xa-my-location[data-v-00ff4058] p.muted-text{color:#94a6aa}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1431:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/atoms/MyLocation.vue?vue&type=template&id=00ff4058&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xa-my-location"},[(_vm.inMobileMenu)?_vm._ssrNode("<div class=\"in-mobile-menu\" data-v-00ff4058>","</div>",[(!_vm.userLocationEditFlag)?_vm._ssrNode("<span class=\"edit\" data-v-00ff4058>","</span>",[_c('b-icon',{attrs:{"icon":"map-marker"}}),_vm._ssrNode(((!_vm.myLocation)?("<p data-v-00ff4058>Click to set your location</p>"):"<!---->")),(_vm.myLocation)?_vm._ssrNode("<div class=\"notInLine\" data-v-00ff4058>","</div>",[_vm._ssrNode("<div class=\"inLine\" data-v-00ff4058><p class=\"muted-text smaller-text\" data-v-00ff4058>Your location is</p></div>"),_vm._ssrNode("<div class=\"inLine\" data-v-00ff4058>","</div>",[_vm._ssrNode("<p class=\"marginR\" data-v-00ff4058>"+_vm._ssrEscape(_vm._s(_vm.myLocation))+"</p>"),_c('b-icon',{attrs:{"icon":"pencil"}})],2)],2):_vm._e()],2):_vm._e(),(_vm.userLocationEditFlag)?_vm._ssrNode("<span class=\"editText\" data-v-00ff4058>","</span>",[_c('XAFormsInput',{attrs:{"placeholder":"Enter your Zip Code","iconOnRight":"map-marker","error":_vm.errorMsg},model:{value:(_vm.zipCode),callback:function ($$v) {_vm.zipCode=$$v},expression:"zipCode"}}),_c('b-button',{attrs:{"type":"save-button-desktop"},on:{"click":function($event){$event.preventDefault();return _vm.saveLocation()}}},[_vm._v("Save")])],1):_vm._e()]):_vm._e(),(!_vm.inMobileMenu)?_vm._ssrNode("<div class=\"desktop\" data-v-00ff4058>","</div>",[(!_vm.userLocationEditFlag)?_vm._ssrNode("<span class=\"edit\" data-v-00ff4058>","</span>",[_c('b-icon',{attrs:{"icon":"map-marker"}}),_vm._ssrNode(((!_vm.myLocation)?("<p data-v-00ff4058>Click to set your location</p>"):"<!---->")),(_vm.myLocation)?_vm._ssrNode("<div class=\"notInLine\" data-v-00ff4058>","</div>",[_vm._ssrNode("<div class=\"inLine\" data-v-00ff4058><p class=\"muted-text smaller-text\" data-v-00ff4058>Your location is</p></div>"),_vm._ssrNode("<div class=\"inLine\" data-v-00ff4058>","</div>",[_vm._ssrNode("<p class=\"marginR\" data-v-00ff4058>"+_vm._ssrEscape(_vm._s(_vm.myLocation))+"</p>"),_c('b-icon',{attrs:{"icon":"pencil"}})],2)],2):_vm._e()],2):_vm._e(),(_vm.userLocationEditFlag)?_vm._ssrNode("<span class=\"editText\" data-v-00ff4058>","</span>",[_c('XAFormsInput',{attrs:{"placeholder":"Enter your Zip Code","iconOnRight":"map-marker","error":_vm.errorMsg},model:{value:(_vm.zipCode),callback:function ($$v) {_vm.zipCode=$$v},expression:"zipCode"}}),_c('b-button',{attrs:{"type":"save-button-desktop"},on:{"click":function($event){$event.preventDefault();return _vm.saveLocation()}}},[_vm._v("Save")])],1):_vm._e()]):_vm._e(),(!_vm.inMobileMenu)?_vm._ssrNode("<div class=\"tablet\" data-v-00ff4058>","</div>",[_vm._ssrNode("<span class=\"edit\" data-v-00ff4058>","</span>",[(_vm.showFloatingLocationBoard)?_c('b-icon',{attrs:{"icon":"map-marker"}}):_vm._e(),(!_vm.showFloatingLocationBoard)?_c('b-icon',{attrs:{"icon":"map-marker"}}):_vm._e()],1),(_vm.showFloatingLocationBoard)?_vm._ssrNode("<div class=\"floating-board\" data-v-00ff4058>","</div>",[(!_vm.userLocationEditFlag && !_vm.myLocation)?_vm._ssrNode("<div class=\"set-location\" data-v-00ff4058>","</div>",[_vm._ssrNode("<div class=\"inLine\" data-v-00ff4058>","</div>",[_c('b-icon',{attrs:{"icon":"map-marker"}}),_vm._ssrNode("<p data-v-00ff4058>Click to set your location</p>")],2)]):_vm._e(),(_vm.myLocation && !_vm.userLocationEditFlag)?_vm._ssrNode("<div class=\"notInLine\" data-v-00ff4058>","</div>",[_vm._ssrNode("<div class=\"inLine\" data-v-00ff4058>","</div>",[_c('b-icon',{attrs:{"icon":"map-marker"}}),_vm._ssrNode("<p class=\"muted-text smaller-text\" data-v-00ff4058>Your location is</p>")],2),_vm._ssrNode("<div class=\"inLine\" data-v-00ff4058>","</div>",[_vm._ssrNode("<p class=\"marginR\" data-v-00ff4058>"+_vm._ssrEscape(_vm._s(_vm.myLocation))+"</p>"),_c('b-icon',{attrs:{"icon":"pencil"}})],2)]):_vm._e(),(_vm.userLocationEditFlag)?_vm._ssrNode("<span class=\"editText\" data-v-00ff4058>","</span>",[_c('XAFormsInput',{attrs:{"placeholder":"Enter your Zip Code","iconOnRight":"map-marker","error":_vm.errorMsg},model:{value:(_vm.zipCode),callback:function ($$v) {_vm.zipCode=$$v},expression:"zipCode"}}),_c('b-button',{attrs:{"type":"save-button-tablet"},on:{"click":function($event){$event.preventDefault();return _vm.saveLocation()}}},[_vm._v("Save")])],1):_vm._e()]):_vm._e()]):_vm._e()])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/atoms/MyLocation.vue?vue&type=template&id=00ff4058&scoped=true&lang=pug&

// EXTERNAL MODULE: external "vuex-map-fields"
var external_vuex_map_fields_ = __webpack_require__(2);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/atoms/MyLocation.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var MyLocationvue_type_script_lang_js_ = ({
  name: 'XAMyLocation',
  components: {
    XAFormsInput: () => __webpack_require__.e(/* import() */ 0).then(__webpack_require__.bind(null, 991))
  },
  props: {
    inMobileMenu: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      userNameDefault: null,
      userAvatarDefault: null,
      userLocationEditFlag: false,
      showFloatingLocationBoard: false,
      myLocation: null,
      zipCode: null,
      errorMsg: null
    };
  },
  computed: {
    ...Object(external_vuex_map_fields_["mapFields"])('user', ['userName', 'userAvatar']),
    name() {
      return this.userName || this.$store.state.auth.displayName || null;
    },
    avatarURL() {
      return this.userAvatar || null;
    }
  },
  watch: {
    '$store.state.auth.token': {
      deep: true,
      handler() {
        this.userNameDefault = this.userName;
        this.userAvatarDefault = this.userAvatar;
      }
    },
    zipCode() {
      this.errorMsg = null;
    }
  },
  async created() {
    await this.getLocation();
  },
  methods: {
    async saveLocation() {
      try {
        await this.$api.addZipCode({
          zipCode: this.zipCode
        }).then(res => {
          if (res) {
            this.myLocation = '' + res.addZipCode.city + ' ' + res.addZipCode.state + ' ' + res.addZipCode.zip;
          }
        });
        this.userLocationEditFlag = false;
        this.showFloatingLocationBoard = false;
        localStorage.setItem('user-zipcode-fx1', this.myLocation);
      } catch (error) {
        this.errorMsg = 'Please enter a valid US zip code';
      }
    },
    async getLocation() {
      if (!this.isLoggedIn) {
        this.myLocation = localStorage.getItem('user-zipcode-fx1');
      } else {
        try {
          const userLocationData = await this.$api.getMyLocation();
          if (userLocationData.Me.zipCode) {
            this.myLocation = '' + userLocationData.Me.ZipCode.city + ' ' + userLocationData.Me.ZipCode.state + ' ' + userLocationData.Me.ZipCode.zip;
            this.zipCode = userLocationData.Me.ZipCode.zip;
            localStorage.setItem('user-zipcode-fx1', this.myLocation);
          }
        } catch (error) {
          var _error$response;
          error === null || error === void 0 ? void 0 : (_error$response = error.response) === null || _error$response === void 0 ? void 0 : _error$response.errors.forEach(error => {
            this.$toast.success(error.message, {
              duration: 5000,
              position: 'bottom-left',
              className: 'fx1-success',
              iconPack: 'mdi',
              icon: 'alert-circle-outline'
            });
          });
        }
      }
    }
  }
});
// CONCATENATED MODULE: ./components/atoms/MyLocation.vue?vue&type=script&lang=js&
 /* harmony default export */ var atoms_MyLocationvue_type_script_lang_js_ = (MyLocationvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/atoms/MyLocation.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1152)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  atoms_MyLocationvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "00ff4058",
  "2dae98c5"
  
)

/* harmony default export */ var MyLocation = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 919:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1153);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("6736802b", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=120.js.map
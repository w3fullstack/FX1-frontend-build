exports.ids = [148];
exports.modules = {

/***/ 1111:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Policy_vue_vue_type_style_index_0_id_d8f1fe10_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(899);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Policy_vue_vue_type_style_index_0_id_d8f1fe10_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Policy_vue_vue_type_style_index_0_id_d8f1fe10_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Policy_vue_vue_type_style_index_0_id_d8f1fe10_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Policy_vue_vue_type_style_index_0_id_d8f1fe10_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1112:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".privacy-content[data-v-d8f1fe10]{min-height:calc(100vh - 406px);border-bottom:1px solid #1c3e45;background-color:#0c353e;padding:50px}.privacy-content[data-v-d8f1fe10] .text-font-bold{font-weight:700;margin-top:30px}.privacy-content[data-v-d8f1fe10] a{color:#fff;text-decoration:underline}.privacy-content[data-v-d8f1fe10] .bottom-border{border-bottom:2px solid #fff}.privacy-content[data-v-d8f1fe10] h1{font-size:3rem;line-height:1.2;margin-bottom:30px;letter-spacing:0}.privacy-content[data-v-d8f1fe10] h2{font-size:1.5714rem;font-weight:500;margin-bottom:.75rem}.privacy-content[data-v-d8f1fe10] h3{font-size:1.5714rem;line-height:1.2;margin:40px 0 20px;border-bottom:1px solid #fff;padding-bottom:10px}.privacy-content[data-v-d8f1fe10] p{font-size:1.1429rem;font-weight:300;margin-bottom:20px}.privacy-content[data-v-d8f1fe10] ul{margin-bottom:20px}.privacy-content[data-v-d8f1fe10] ul li{list-style-type:disc;font-size:1.1429rem;font-weight:300;margin-bottom:20px;margin-left:15px}.privacy-content[data-v-d8f1fe10] ul li ul{margin-top:20px;margin-left:20px;margin-bottom:0}.privacy-content[data-v-d8f1fe10] ul li ul li{list-style-type:none}.privacy-content[data-v-d8f1fe10] pre{display:block;padding:.7143rem;word-break:break-all;background-color:#f5f5f5;border:1px solid #ccc;border-radius:5px;font-size:12px;white-space:pre-line;margin-bottom:.7143rem}.privacy-content[data-v-d8f1fe10] pre span{display:block}.privacy-content[data-v-d8f1fe10] strong{color:#fff}.privacy-content[data-v-d8f1fe10] .privacy-container{position:relative}.privacy-content[data-v-d8f1fe10] .privacy-container #privacy{position:absolute;top:-110px}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1348:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/Policy.vue?vue&type=template&id=d8f1fe10&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"privacy-content"},[_vm._ssrNode("<div class=\"container is-max-desktop\" data-v-d8f1fe10>","</div>",[_vm._ssrNode("<h1 data-v-d8f1fe10>Privacy Policy</h1><h3 data-v-d8f1fe10>Introduction</h3><p data-v-d8f1fe10><b data-v-d8f1fe10>FX1 Pty Ltd</b> ACN 637 528 851 (<b data-v-d8f1fe10>FX1, we, us, our</b>) is committed to complying with applicable privacy laws in relation tothe personal information that we collect in the course of running our business. Where applicable privacy laws provide\nfor exceptions or exemptions, we may rely on those exceptions or exemptions in our information handling practices.</p><p data-v-d8f1fe10>Please take a moment to read our Privacy Policy as it explains how we manage personal information including ourobligations and your rights in respect of our dealings with your personal information.</p><p data-v-d8f1fe10>This Privacy Policy (other than section 11) explains how we manage personal information about individuals other thanemployees. Section 11 explains the position of employees.</p><h3 data-v-d8f1fe10>Key definitions</h3><p data-v-d8f1fe10>In this document:</p>"),_vm._ssrNode("<ul data-v-d8f1fe10>","</ul>",[_vm._ssrNode("<li data-v-d8f1fe10><b data-v-d8f1fe10>&quot;APPs&quot;</b> means the Australia Privacy Principles set out in the Privacy Act;</li><li data-v-d8f1fe10><b data-v-d8f1fe10>&quot;personal information&quot;</b> has the meaning set out in the Privacy Act, and (in summary) means information oran opinion about an identified individual or an individual who is reasonably identifiable, whether true or\notherwise;</li><li data-v-d8f1fe10><b data-v-d8f1fe10>&quot;Privacy Act&quot;</b> means the Privacy Act 1988 (Cth);</li><li data-v-d8f1fe10><b data-v-d8f1fe10>&quot;sensitive information&quot;</b> has the meaning set out in the Privacy Act, and includes certain specific types ofpersonal information such as health information, and information about a person's racial or ethnic origin,\nsexual orientation, religious beliefs or affiliations and criminal record; and</li>"),_vm._ssrNode("<li data-v-d8f1fe10>","</li>",[_vm._ssrNode("<b data-v-d8f1fe10>&quot;Subscribers&quot;</b> means natural persons or entities running a business, and who have subscribed to the Websiteon behalf of that business and created a Subscriber account, as per the "),_c('nuxt-link',{attrs:{"to":"/terms-conditions"}},[_c('strong',[_vm._v("Website Terms of Use")])])],2)],2),_vm._ssrNode("<h3 data-v-d8f1fe10>1. How we collect your personal information</h3><p data-v-d8f1fe10>We will collect and hold your personal information in a fair and lawful manner, and not in an intrusive way.Where it is reasonably practical to do so, we will collect your personal information directly from you. We may\ncollect the personal information you directly give us through some of the following means:</p><ul data-v-d8f1fe10><li data-v-d8f1fe10>when you create an account or profile on our website located at <b data-v-d8f1fe10>fx1.io</b> (the <b data-v-d8f1fe10>Website</b>);</li><li data-v-d8f1fe10>when you create or are allocated login credentials to an account on our Website;</li><li data-v-d8f1fe10>when you make an inquiry or order in relation to our goods or services or those of Subscribers,including through our Website;</li><li data-v-d8f1fe10>when you upload content to or interact (in an identifiable manner) with our Website or our socialmedia pages;</li><li data-v-d8f1fe10>in administering and performing any contracts with service providers;</li><li data-v-d8f1fe10>in administering and performing any contracts with you or a business you represent;</li><li data-v-d8f1fe10>when you contact us via telephone or other means;</li><li data-v-d8f1fe10>from correspondence (whether in writing or electronically);</li><li data-v-d8f1fe10>through any mobile applications provided by our organisation;</li><li data-v-d8f1fe10>while conducting customer satisfaction and market research surveys;</li><li data-v-d8f1fe10>when administering any of our services; and</li></ul><p data-v-d8f1fe10>However, in certain cases we may collect personal information from publicly available sources and thirdparties, such as suppliers, recruitment agencies, your employers, contractors, our clients, business partners.</p><p data-v-d8f1fe10>If we collect personal information about you from a third party we will, where appropriate, request that the thirdparty inform you that we are holding such information, how we will use and disclose it, and that you may\ncontact us to gain access to and correct and update the information.</p><h3 data-v-d8f1fe10>2. Types of personal information we collect</h3><p data-v-d8f1fe10>The types of personal information we collect about you depends on the circumstances in which the informationis collected. The type of personal information we may collect can include (but is not limited to) your full name,\nemail address, phone numbers, gender, date of birth, information related directly about your sporting\ncommunities, credit card/payment details, and billing information.</p><p data-v-d8f1fe10>With regard to users of the Website, we may also collect information you provide in your profile and in yourinteractions with the Website and our messaging pages, such as the content you post, upload or view, the\nadvertisements and advertisers you interact with, the searches you conduct on the Website, your personal\npreferences, and the people and businesses you connect with</p><p data-v-d8f1fe10>If you are an individual contractor to us, we may also collect information relevant to your engagement with usincluding qualifications, length of engagement, resume, current and former employment details, pay rate and\nsalary, bank details, feedback from supervisors, training records and logs of your usage of our equipment (e.g.\nphones, computers and vehicles).</p><p data-v-d8f1fe10>If we have or in the future make available any mobile applications for you to download and use, we may:</p><ul data-v-d8f1fe10><li data-v-d8f1fe10>record details of your device details and operating systems; and</li><li data-v-d8f1fe10>if you have provided us with permission to access your device location when using our app, we maycollect information about your geographical location.</li></ul><p data-v-d8f1fe10>We only collect sensitive information about you with your consent, or otherwise in accordance with the PrivacyAct. If you do provide sensitive information to us for any reason (for example, if you provide us with\ninformation about a disability you have), you consent to us collecting that information and to us using and\ndisclosing that information for the purpose for which you disclosed it to us and as permitted by the Privacy Act\nand other relevant laws.</p><p data-v-d8f1fe10>In addition to the types of personal information identified above, we may collect personal information asotherwise permitted or required by law.</p><p data-v-d8f1fe10>Where you do not wish to provide us with your personal information, we may not be able to provide you withrequested goods or services.</p><h3 data-v-d8f1fe10>3. Our purposes for handling your personal information</h3><p data-v-d8f1fe10>As a general rule, we only process personal information for purposes that would be considered relevant andreasonable in the circumstances. The purposes for which we use and disclose your personal information will\ndepend on the circumstances in which we collect it. Whenever practical we endeavor to inform you why we\nare collecting your personal information, how we intend to use that information and to whom we intend to\ndisclose it at the time we collect your personal information.</p><p data-v-d8f1fe10>We may use or disclose your personal information:</p><ul data-v-d8f1fe10><li data-v-d8f1fe10>for the purposes for which we collected it (and related purposes which would be reasonably expected by you);</li><li data-v-d8f1fe10>for other purposes to which you have consented; and</li><li data-v-d8f1fe10>as otherwise authorised or required by law.</li></ul><p data-v-d8f1fe10>In general, we collect, use and disclose your personal information so that we can do business together and forpurposes connected with our business operations.</p><p data-v-d8f1fe10>Some of the specific purposes for which we collect, hold, use and disclose personal information are as follows:</p><ul data-v-d8f1fe10><li data-v-d8f1fe10>to operate the Website, which allows users to connect with each other and (among other things)share information via direct messaging and post information to open forums on the platform;</li><li data-v-d8f1fe10>we may send you push notifications and other electronic communications (including SMS) forpurposes including promoting the goods or services of our Subscribers and notifying you of content\nthat may be relevant to you based on your profile and activity on the Website;</li><li data-v-d8f1fe10>where you have provided us with access to your geographical location via any of our mobileapplications, we may send you push notifications and other electronic communications (including\nSMS) relevant to your location for purposes including promoting the goods or services of our\nSubscribers and notifying you of content that may be of interest to you based on your profile and\nactivity on the Website;</li><li data-v-d8f1fe10>to offer and provide our goods or services to you or to receive goods or services from you;</li><li data-v-d8f1fe10>to advertise and promote the goods or services of our Subscribers and allow you to contact themdirectly;</li><li data-v-d8f1fe10>to provide you with tax invoices for our goods and services;</li><li data-v-d8f1fe10>to confirm your identity;</li><li data-v-d8f1fe10>to operate our Website;</li><li data-v-d8f1fe10>to facilitate your entry and participation in a competition or trade promotion;</li><li data-v-d8f1fe10>to consider you for a job (whether as an employee or contractor) or other relationships with us;</li><li data-v-d8f1fe10>to optimise and customise the user experience (including content and advertising) for users of theWebsite and our other websites, social media pages, mobile applications and services;</li><li data-v-d8f1fe10>to protect the security and integrity of the Website and our other websites, mobile applications andservices;</li><li data-v-d8f1fe10>to develop and improve our Website and our goods and services;</li><li data-v-d8f1fe10>to contact you (directly or through our service providers and marketing research agencies) to obtainyour feedback and to find out your level of satisfaction with our goods and services;</li><li data-v-d8f1fe10>to comply with our legal and regulatory obligations;</li><li data-v-d8f1fe10>to monitor your compliance with our Website Terms of Use, including the Community Guidelines, andaddress any issues or complaints that we or you have regarding our relationship or relating to the\nWebsite; and</li><li data-v-d8f1fe10>to contact you regarding the above, including via electronic messaging such as SMS and email, bymail, by phone or in any other lawful manner.</li></ul><h3 data-v-d8f1fe10>4. Who we disclose your personal information to</h3><p data-v-d8f1fe10>We may disclose your personal information to third parties in connection with the purposes described insection 3 of this Privacy Policy. This may include disclosing your personal information to the following types of\nthird parties:</p><ul data-v-d8f1fe10><li data-v-d8f1fe10>our suppliers, contractors and organisations that provide us with technical and support services;</li><li data-v-d8f1fe10>our related entities (who may use and disclose the information in the same manner we can);</li><li data-v-d8f1fe10>our accountants, insurers, lawyers, auditors and other professional advisers;</li><li data-v-d8f1fe10>any third parties to whom you have directed or permitted us to disclose your personal information (e.g. referees);</li><li data-v-d8f1fe10>any Subscribers or other advertisers to whom you have directed or permitted us to disclose yourpersonal information, for example, to allow them to contact you via the Website; and</li><li data-v-d8f1fe10>in the unlikely event that we or our assets may be acquired or considered for acquisition by a thirdparty, that third party and its advisors.</li></ul><p data-v-d8f1fe10>We may also disclose your personal information in accordance with any consent you give or where disclosureis authorised, compelled or permitted by law.</p><p data-v-d8f1fe10>If we disclose information to a third party, we generally require that the third party protect your information tothe same extent that we do.</p><p data-v-d8f1fe10>If you post information to certain public parts of our Website or to our messaging pages, you acknowledge thatsuch information may be available to be viewed by the public. You should use discretion in deciding what\ninformation you upload to such sites.</p><h3 data-v-d8f1fe10>5. Protection of personal information</h3><p data-v-d8f1fe10>We will hold personal information as either secure physical records, electronically on our intranet system, incloud storage, and in some cases, records on third party servers, which may be located overseas. We use a\nrange of security measures to protect the personal information we hold, including by implementing IT security\ntools to protect our electronic databases.</p><p data-v-d8f1fe10>We will destroy or de-identify personal information once it is no longer needed for a valid purpose or required to be kept by law.</p><h3 data-v-d8f1fe10>6. Direct marketing</h3><p data-v-d8f1fe10>Like most businesses, marketing is important to our continued success. We therefore like to stay in touch withcustomers and let them know about new offers and opportunities. We may provide you with information about\nproducts, services and promotions either from us, or from third parties which may be of interest to you, where:</p><ul class=\"ml-5\" data-v-d8f1fe10><li data-v-d8f1fe10>you have consented to us doing so; or</li><li data-v-d8f1fe10>it is otherwise permitted by law.</li></ul><p data-v-d8f1fe10>You may opt out at any time if you no longer wish to receive direct marketing messages from us. You canmake this request by contacting our Privacy Officer, or by following the unsubscribe directions in a marketing\nmessage you receive.</p><h3 data-v-d8f1fe10>7. Cookies</h3><p data-v-d8f1fe10>A cookie is a small text file stored in your computer’s memory or on your hard disk for a pre-defined period oftime. We use cookies to identify specific machines in order to collect aggregate information on how visitors\nare experiencing the Website. This information will help to better adapt the Website to suit personal\nrequirements. While cookies allow a computer to be identified, they do not permit any reference to a specific\nindividual. For information on cookie settings of your internet browser, please refer to your browser’s manual.</p><p data-v-d8f1fe10>We may use third party vendors to show our ads on sites on the Internet and serve these ads based on auser’s prior visits to our Website. We may also use analytics data supplied by these vendors to inform and\noptimise our ad campaigns based on your prior visits to our Website.</p><h3 data-v-d8f1fe10>8. Data Analytics</h3><p data-v-d8f1fe10>We share aggregated information regarding our users to certain Subscribers and other partners, sometimes for a fee.</p><p class=\"ml-5\" data-v-d8f1fe10>The information we share will not personally identify you unless you give us permission. This information may include:</p><ul class=\"ml-5 pl-5\" data-v-d8f1fe10><li data-v-d8f1fe10>providing a Subscriber or advertiser with information how users are engaging with their messages and content on the Website;</li><li data-v-d8f1fe10>providing a User with information directly related to their own engagement and behaviors on the Website;</li></ul><ul data-v-d8f1fe10><li data-v-d8f1fe10>providing general market data regarding the users of our Website such as general demographic, size andvolume of certain interested products and services, and broader user trends and behaviors.</li><li data-v-d8f1fe10>We may engage third parties to aggregate and analyze the data and provide the reports.</li></ul><h3 data-v-d8f1fe10>9. Accessing and correcting your personal information</h3><p data-v-d8f1fe10>You may contact our Privacy Officer (see section 13) to request access to the personal information that wehold about you and/or to make corrections to that information, at any time. On the rare occasions when we\nrefuse access, we will provide you with a written notice stating our reasons for refusing access. We may seek\nto recover from you reasonable costs incurred for providing you with access to the personal information we\nhold about you.</p><p data-v-d8f1fe10>We are not obliged to correct any of your personal information if we do not agree that it requires correctionand may refuse to do so. If we refuse a correction request, we will provide you with a written notice stating our\nreasons for refusing.</p><p data-v-d8f1fe10>We will respond to all requests for access to or correction of personal information within a reasonable time.</p><h3 data-v-d8f1fe10>10. Overseas transfers of personal information</h3><p data-v-d8f1fe10>Some of the third parties to whom we disclose personal information may be located outside Australia. Thecountries in which such third-party recipients are located depend on the circumstances. In the ordinary course\nof business, we commonly disclose personal information to recipients located in UK, Europe, North America,\nAsia, New Zealand, South Africa, Canada. Our Subscribers and advertisers may also be located overseas.</p><p data-v-d8f1fe10>From time to time we may also engage an overseas recipient to provide services to us, such as cloud-basedstorage solutions. Please note that the use of overseas service providers to store personal information will not\nalways involve a disclosure of personal information to that overseas provider.</p><p data-v-d8f1fe10>By providing your personal information to us, you consent to us disclosing your personal information to anysuch overseas recipients for purposes necessary or useful in the course of operating our business and agree\nthat APP 8.1 will not apply to such disclosures. For the avoidance of doubt, in the event that an overseas\nrecipient breaches the Australian Privacy Principles, that entity will not be bound by, and you will not be able\nto seek redress under, the Privacy Act.</p><h3 data-v-d8f1fe10>11. Employees</h3><p data-v-d8f1fe10>We collect information in relation to employees as part of their application and during the course of theiremployment, either from them or in some cases from third parties such as recruitment agencies. Such\ninformation may include contact details, qualifications, resume, current and former employment details, pay\nrate and salary, bank details, feedback from supervisors, training records and logs of your usage of our\nequipment (e.g. phones, computers and vehicles).</p><p data-v-d8f1fe10>Under the Privacy Act, personal information about a current or former employee may be held, used ordisclosed in any way that is directly connected to the employment relationship. We handle employee\ninformation in accordance with legal requirements and our applicable policies in force from time to time.</p><h3 data-v-d8f1fe10>12. Resolving personal information concerns</h3><p data-v-d8f1fe10>If you have any questions, concerns or complaints about this Privacy Policy, or how we handle your personalinformation, please contact our Privacy Officer (see section 13).</p><p data-v-d8f1fe10>When contacting us please provide as much detail as possible in relation to your question, concern or complaint.</p><p data-v-d8f1fe10>We take all complaints seriously and will respond to your complaint within a reasonable period. We requestthat you cooperate with us during this process and provide us with any relevant information that we may need.</p><p data-v-d8f1fe10>If you are dissatisfied with the handling of your complaint, you may contact the Office of the AustralianInformation Commissioner:</p><div class=\"ml-5 pl-5\" data-v-d8f1fe10><p data-v-d8f1fe10>Office of the Australian Information Commissioner</p><p data-v-d8f1fe10>GPO Box 5218, Sydney NSW 2001</p><p data-v-d8f1fe10>Telephone: 1300 363 992</p><p data-v-d8f1fe10>Email: enquiries@oaic.gov.au</p></div><h3 data-v-d8f1fe10>13. Contact details of Privacy Officer</h3><p data-v-d8f1fe10>The contact details for our Privacy Officer are as follows:</p><div class=\"ml-5 pl-5\" data-v-d8f1fe10><p data-v-d8f1fe10>Postal address: 51A Sheahans Road, Bulleen, 3105, Victoria</p><p data-v-d8f1fe10>Email: hello@fx1.com</p></div><h3 data-v-d8f1fe10>14. Links</h3><p data-v-d8f1fe10>Our Website may contain links to other websites operated by third parties. We make no representations orwarranties in relation to privacy practices of any third-party website and we are not responsible for the privacy\npolicies or the content of any third-party website. Third party websites are responsible for informing you about\ntheir own privacy practices and procedures.</p><h3 data-v-d8f1fe10>15. Changes</h3><p data-v-d8f1fe10>We reserve the right to change the terms of this Privacy Policy from time to time, without notice to you. An up-to-date copy of our Privacy Policy is available on our Website.</p>")],2)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/pages/Policy.vue?vue&type=template&id=d8f1fe10&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/Policy.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Policyvue_type_script_lang_js_ = ({
  name: 'XPPolicy'
});
// CONCATENATED MODULE: ./components/pages/Policy.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_Policyvue_type_script_lang_js_ = (Policyvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/pages/Policy.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1111)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pages_Policyvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "d8f1fe10",
  "7dd92b98"
  
)

/* harmony default export */ var Policy = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 899:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1112);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("45741c27", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=148.js.map
exports.ids = [86];
exports.modules = {

/***/ 1232:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_HowToBuySection_vue_vue_type_style_index_0_id_d879ff62_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(959);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_HowToBuySection_vue_vue_type_style_index_0_id_d879ff62_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_HowToBuySection_vue_vue_type_style_index_0_id_d879ff62_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_HowToBuySection_vue_vue_type_style_index_0_id_d879ff62_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_HowToBuySection_vue_vue_type_style_index_0_id_d879ff62_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1233:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(24);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(563);
var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(565);
var ___CSS_LOADER_URL_IMPORT_2___ = __webpack_require__(564);
var ___CSS_LOADER_URL_IMPORT_3___ = __webpack_require__(562);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
var ___CSS_LOADER_URL_REPLACEMENT_2___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_2___);
var ___CSS_LOADER_URL_REPLACEMENT_3___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_3___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".token-howtobuy-section[data-v-d879ff62]{width:auto;position:relative;overflow:hidden;z-index:2}.token-howtobuy-section[data-v-d879ff62] .top-margin-a{margin-top:80px}.token-howtobuy-section[data-v-d879ff62] .top-margin-b{margin-top:40px}.token-howtobuy-section[data-v-d879ff62] .actions{margin:12px 12px 25px}.token-howtobuy-section[data-v-d879ff62] .btn-left a,.token-howtobuy-section[data-v-d879ff62] .btn-right a{width:200px;height:60px;border-radius:8px}.token-howtobuy-section[data-v-d879ff62] .btn-right a{background-color:transparent;outline:1px solid #fff}.token-howtobuy-section[data-v-d879ff62] .boxes .col{background-color:#0c353e;height:344px;background-position:100% 100%;background-repeat:no-repeat;margin:12px;border-radius:10px;position:relative}.token-howtobuy-section[data-v-d879ff62] .boxes .col .top-layer{position:absolute;top:18%;left:11%}.token-howtobuy-section[data-v-d879ff62] .boxes .col .middle-layer{width:48%;position:absolute;top:48%;left:11%}.token-howtobuy-section[data-v-d879ff62] .boxes .col .bottom-layer{width:65%;position:absolute;left:11%;top:65%}.token-howtobuy-section[data-v-d879ff62] .boxes .col .bottom-layer .youtube{color:#886bf2}@media screen and (max-width:1800px){.token-howtobuy-section[data-v-d879ff62] .boxes .col .top-layer{top:13%}.token-howtobuy-section[data-v-d879ff62] .boxes .col .middle-layer{top:43%}.token-howtobuy-section[data-v-d879ff62] .boxes .col .bottom-layer{top:58%}}@media screen and (max-width:1650px){.token-howtobuy-section[data-v-d879ff62] .boxes .col .middle-layer{width:65%}.token-howtobuy-section[data-v-d879ff62] .boxes .col .bottom-layer{width:75%}}.token-howtobuy-section[data-v-d879ff62] .boxes .box-one{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ")}.token-howtobuy-section[data-v-d879ff62] .boxes .box-two{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ")}.token-howtobuy-section[data-v-d879ff62] .boxes .box-three{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ")}.token-howtobuy-section[data-v-d879ff62] .boxes .box-four{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ")}@media screen and (max-width:1021px){.token-howtobuy-section[data-v-d879ff62] .col{width:100%!important;margin:0 0 20px!important;background-size:100%}.token-howtobuy-section[data-v-d879ff62] .box-one,.token-howtobuy-section[data-v-d879ff62] .box-three{margin-right:15px!important}.token-howtobuy-section[data-v-d879ff62] .box-four,.token-howtobuy-section[data-v-d879ff62] .box-two{margin-left:15px!important}.token-howtobuy-section[data-v-d879ff62] .actions.text-left,.token-howtobuy-section[data-v-d879ff62] .actions.text-right{text-align:center!important}.token-howtobuy-section[data-v-d879ff62] .btn-left,.token-howtobuy-section[data-v-d879ff62] .btn-right{max-width:30%!important;height:60px!important}.token-howtobuy-section[data-v-d879ff62] .btn-left a,.token-howtobuy-section[data-v-d879ff62] .btn-right a{margin:0!important;width:100%!important;height:60px!important}.token-howtobuy-section[data-v-d879ff62] .btn-right{margin-right:20%!important;margin-left:0!important}.token-howtobuy-section[data-v-d879ff62] .btn-left{margin-left:20%!important;margin-right:3%!important}}@media screen and (max-width:500px){.token-howtobuy-section[data-v-d879ff62] .col{flex:none;width:100%!important;display:block;max-height:215px;margin:0 0 20px!important;background-size:100%}.token-howtobuy-section[data-v-d879ff62] .top-margin-a{margin-top:25px}.token-howtobuy-section[data-v-d879ff62] .actions.text-left,.token-howtobuy-section[data-v-d879ff62] .actions.text-right{text-align:center!important}.token-howtobuy-section[data-v-d879ff62] .btn-left,.token-howtobuy-section[data-v-d879ff62] .btn-right{max-width:48%!important;height:60px!important}.token-howtobuy-section[data-v-d879ff62] .btn-left a,.token-howtobuy-section[data-v-d879ff62] .btn-right a{margin:0!important;width:100%!important;height:60px!important}.token-howtobuy-section[data-v-d879ff62] .btn-right{margin-left:2%!important}.token-howtobuy-section[data-v-d879ff62] .btn-left{margin-right:2%!important}.token-howtobuy-section[data-v-d879ff62] .top-margin-b{margin-top:30px}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1406:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/HowToBuySection.vue?vue&type=template&id=d879ff62&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"token-howtobuy-section row",attrs:{"id":"howtobuy"}},[_vm._ssrNode("<div class=\"container token-container-howToBuy text-center\" data-v-d879ff62><h1 data-v-d879ff62>How to Buy $FX1</h1><div class=\"top-margin-a\" data-v-d879ff62></div><div class=\"row boxes\" data-v-d879ff62><div class=\"col box-one text-left\" data-v-d879ff62><h2 class=\"token-h2 top-layer\" data-v-d879ff62>Go to<br data-v-d879ff62>Uniswap</h2><p class=\"token-p middle-layer\" data-v-d879ff62>and connect up your wallet</p><p class=\"token-p bottom-layer\" data-v-d879ff62>For anyone new to Uniswap, the below video is a great tutorial to follow:<span class=\"youtube\" data-v-d879ff62>Youtube</span></p></div><div class=\"col box-two text-left\" data-v-d879ff62><h2 class=\"token-h2 top-layer\" data-v-d879ff62>From the<br data-v-d879ff62>Swap form,</h2><p class=\"token-p middle-layer\" data-v-d879ff62>choose FX1 as the “To” token you’re buying</p></div></div><div class=\"row boxes\" data-v-d879ff62><div class=\"col box-three text-left\" data-v-d879ff62><h2 class=\"token-h2 top-layer\" data-v-d879ff62>Choose<br data-v-d879ff62>the amount</h2><p class=\"token-p middle-layer\" data-v-d879ff62>of Ether you wish to swap for FX1</p></div><div class=\"col box-four text-left\" data-v-d879ff62><h2 class=\"token-h2 top-layer\" data-v-d879ff62>Check<br data-v-d879ff62>conversion</h2><p class=\"token-p middle-layer\" data-v-d879ff62>and hit the SWAP button</p></div></div><div class=\"top-margin-b\" data-v-d879ff62></div><div class=\"row\" data-v-d879ff62><div class=\"col actions text-right btn-left\" data-v-d879ff62><a href=\"https://app.uniswap.org/#/swap?outputCurrency=0x610C584F1275f0f7c982Af0aC7883Ff4Dba661Bd\" target=\"_blank\" class=\"button is-primary\" data-v-d879ff62>Buy $FX1</a></div><div class=\"col actions text-left btn-right\" data-v-d879ff62><a href=\"https://www.dextools.io/app/en/ether/pair-explorer/0x87B958067FD665f3937de4439450B4950Eb68e15\" target=\"_blank\" class=\"button is-primary\" data-v-d879ff62>View Chart</a></div></div><span class=\"address\" data-v-d879ff62>Contract Address:<span data-v-d879ff62>0x610C584F1275f0f7c982Af0aC7883Ff4Dba661Bd</span></span></div>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Token/HowToBuySection.vue?vue&type=template&id=d879ff62&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/HowToBuySection.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var HowToBuySectionvue_type_script_lang_js_ = ({
  name: 'HowToBuySection',
  methods: {
    showAlertMessage() {
      this.$toast.success('$FX1 available to purchase mid to late April', {
        duration: 5000,
        position: 'bottom-left',
        className: 'fx1-success'
      });
    }
  }
});
// CONCATENATED MODULE: ./components/molecules/Token/HowToBuySection.vue?vue&type=script&lang=js&
 /* harmony default export */ var Token_HowToBuySectionvue_type_script_lang_js_ = (HowToBuySectionvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/Token/HowToBuySection.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1232)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Token_HowToBuySectionvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "d879ff62",
  "251c97de"
  
)

/* harmony default export */ var HowToBuySection = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 562:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTE2IiBoZWlnaHQ9IjMzNiIgdmlld0JveD0iMCAwIDUxNiAzMzYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+DQo8ZyBjbGlwLXBhdGg9InVybCgjY2xpcDBfMjY5Xzg1KSI+DQo8cmVjdCB3aWR0aD0iNTE2IiBoZWlnaHQ9IjMzNiIgcng9IjEwIiBmaWxsPSIjMEMzNTNFIi8+DQo8ZyBzdHlsZT0ibWl4LWJsZW5kLW1vZGU6b3ZlcmxheSI+DQo8cGF0aCBkPSJNMzQ5LjMgMjYwLjc5OVYyOTkuMDVINDk3LjgwMVYzNzZINTU0Ljk1MVYyOTkuMDVINTk2LjM1MVYyNDYuMzk5SDU1NC45NTFWNTYuNDk4NUg0ODIuOTUxTDM0OS4zIDI2MC43OTlaTTQ5OC4yNTEgMTI2LjY5OUw0OTguNzAxIDI0Ny4yOTlINDE5Ljk1TDQ5OC4yNTEgMTI2LjY5OVoiIGZpbGw9IndoaXRlIi8+DQo8L2c+DQo8L2c+DQo8ZGVmcz4NCjxjbGlwUGF0aCBpZD0iY2xpcDBfMjY5Xzg1Ij4NCjxyZWN0IHdpZHRoPSI1MTYiIGhlaWdodD0iMzM2IiBmaWxsPSJ3aGl0ZSIvPg0KPC9jbGlwUGF0aD4NCjwvZGVmcz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 563:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTE2IiBoZWlnaHQ9IjMzNiIgdmlld0JveD0iMCAwIDUxNiAzMzYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+DQo8ZyBjbGlwLXBhdGg9InVybCgjY2xpcDBfMjY5Xzc1KSI+DQo8cmVjdCB3aWR0aD0iNTE2IiBoZWlnaHQ9IjMzNiIgcng9IjEwIiBmaWxsPSIjMEMzNTNFIi8+DQo8ZyBzdHlsZT0ibWl4LWJsZW5kLW1vZGU6b3ZlcmxheSI+DQo8cGF0aCBkPSJNNDM3Ljk1IDMyMi40NUgzNjUuOTVWMzc2SDU2Ny41NTFWMzIyLjQ1SDQ5Ny4zNTFWNTYuNDk4NUg0NTAuNTUxQzQzMi4xIDg1Ljc0ODYgNDAxLjk1IDEwMS4wNDkgMzYxIDEwMi44NDlWMTU1Ljk0OUM0MDAuMTUgMTU1Ljk0OSA0MjIuMiAxNDYuNDk5IDQzNy45NSAxMzIuNTQ5VjMyMi40NVoiIGZpbGw9IndoaXRlIi8+DQo8L2c+DQo8L2c+DQo8ZGVmcz4NCjxjbGlwUGF0aCBpZD0iY2xpcDBfMjY5Xzc1Ij4NCjxyZWN0IHdpZHRoPSI1MTYiIGhlaWdodD0iMzM2IiBmaWxsPSJ3aGl0ZSIvPg0KPC9jbGlwUGF0aD4NCjwvZGVmcz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 564:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTE2IiBoZWlnaHQ9IjMzNiIgdmlld0JveD0iMCAwIDUxNiAzMzYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+DQo8ZyBjbGlwLXBhdGg9InVybCgjY2xpcDBfMjY5XzExMikiPg0KPHJlY3Qgd2lkdGg9IjUxNiIgaGVpZ2h0PSIzMzYiIHJ4PSIxMCIgZmlsbD0iIzBDMzUzRSIvPg0KPGcgc3R5bGU9Im1peC1ibGVuZC1tb2RlOm92ZXJsYXkiPg0KPHBhdGggZD0iTTM1My4zNSAzMTguODVDMzc0LjUgMzU3LjEgNDEyLjMgMzgxLjQgNDYwLjkwMSAzODEuNEM1MjcuOTUxIDM4MS40IDU3Ni41NTEgMzM4LjIgNTc2LjU1MSAyNzYuNTVDNTc2LjU1MSAyMjQuNzk5IDUzOC4zMDEgMTg3LjQ0OSA0ODYuNTUxIDE4Mi40OTlMNTY2LjIwMSA5Ni4wOTg3VjU2Ljk0ODVIMzcwVjExMC4wNDlINDg4LjgwMUw0MTIuNzUgMTk0LjE5OVYyMjguODQ5QzQyMS43NSAyMjYuNTk5IDQzNC4zNSAyMjUuNjk5IDQ0OC43NTEgMjI1LjY5OUM0OTEuNTAxIDIyNS42OTkgNTE2LjcwMSAyNDUuMDQ5IDUxNi43MDEgMjc4LjhDNTE2LjcwMSAzMDYuMjUgNDkzLjMwMSAzMjYuMDUgNDYwLjkwMSAzMjYuMDVDNDM0LjM1IDMyNi4wNSA0MTEuODUgMzExLjY1IDM5OC44IDI4NS4xTDM1My4zNSAzMTguODVaIiBmaWxsPSJ3aGl0ZSIvPg0KPC9nPg0KPC9nPg0KPGRlZnM+DQo8Y2xpcFBhdGggaWQ9ImNsaXAwXzI2OV8xMTIiPg0KPHJlY3Qgd2lkdGg9IjUxNiIgaGVpZ2h0PSIzMzYiIGZpbGw9IndoaXRlIi8+DQo8L2NsaXBQYXRoPg0KPC9kZWZzPg0KPC9zdmc+DQo="

/***/ }),

/***/ 565:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTE2IiBoZWlnaHQ9IjMzNiIgdmlld0JveD0iMCAwIDUxNiAzMzYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+DQo8ZyBjbGlwLXBhdGg9InVybCgjY2xpcDBfMjY5XzM2KSI+DQo8cmVjdCB3aWR0aD0iNTE2IiBoZWlnaHQ9IjMzNiIgcng9IjEwIiBmaWxsPSIjMEMzNTNFIi8+DQo8ZyBzdHlsZT0ibWl4LWJsZW5kLW1vZGU6b3ZlcmxheSI+DQo8cGF0aCBkPSJNNDY3LjY1MSAxMDcuMzQ5QzQ5Ni4wMDEgMTA3LjM0OSA1MTUuMzUxIDEyNC40NDkgNTE1LjM1MSAxNDkuNjQ5QzUxNS4zNTEgMjEzLjA5OSAzNjAuMSAyMzIuNDQ5IDM2MC4xIDM0My42QzM2MC4xIDM1Ni4yIDM2MS40NSAzNjcgMzYyLjggMzc2SDU3My44NTFWMzIzLjM1SDQyOC4wNUM0MjkuODUgMjY1Ljc0OSA1NzUuNjUxIDI0NS4wNDkgNTc1LjY1MSAxNDUuNTk5QzU3NS42NTEgODUuNzQ4NiA1MjUuNzAxIDUxLjA5ODUgNDY5LjkwMSA1MS4wOTg1QzQyMS43NSA1MS4wOTg1IDM4MC4zNSA3NC45NDg2IDM2MC4xIDExNS44OTlMNDA1LjU1IDE0Ni45NDlDNDE3LjcgMTIzLjA5OSA0NDAuNjUgMTA3LjM0OSA0NjcuNjUxIDEwNy4zNDlaIiBmaWxsPSJ3aGl0ZSIvPg0KPC9nPg0KPC9nPg0KPGRlZnM+DQo8Y2xpcFBhdGggaWQ9ImNsaXAwXzI2OV8zNiI+DQo8cmVjdCB3aWR0aD0iNTE2IiBoZWlnaHQ9IjMzNiIgZmlsbD0id2hpdGUiLz4NCjwvY2xpcFBhdGg+DQo8L2RlZnM+DQo8L3N2Zz4NCg=="

/***/ }),

/***/ 959:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1233);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("64024cb3", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=86.js.map
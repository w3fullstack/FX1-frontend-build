exports.ids = [6];
exports.modules = {

/***/ 1150:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_GetApp_vue_vue_type_style_index_0_id_4ef01d40_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(918);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_GetApp_vue_vue_type_style_index_0_id_4ef01d40_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_GetApp_vue_vue_type_style_index_0_id_4ef01d40_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_GetApp_vue_vue_type_style_index_0_id_4ef01d40_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_GetApp_vue_vue_type_style_index_0_id_4ef01d40_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1151:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xo-default-footer-get-app[data-v-4ef01d40]{grid-gap:34px;gap:34px}.xo-default-footer-get-app[data-v-4ef01d40] .app-logo{flex-flow:row;grid-gap:32px;gap:32px}.xo-default-footer-get-app[data-v-4ef01d40] .app-logo img{max-width:159px;max-height:46px}@media screen and (max-width:767px){.xo-default-footer-get-app[data-v-4ef01d40] .app-logo img{max-width:150px}}@media screen and (max-width:1439px){.xo-default-footer-get-app[data-v-4ef01d40]{grid-gap:22px;gap:22px}.xo-default-footer-get-app[data-v-4ef01d40] .app-logo{flex-flow:column;grid-gap:24px;gap:24px}.xo-default-footer-get-app[data-v-4ef01d40] .app-logo img{width:150px;height:43px}}@media screen and (max-width:1023px){.xo-default-footer-get-app[data-v-4ef01d40]{flex-flow:row;justify-content:space-between}.xo-default-footer-get-app[data-v-4ef01d40] .app-logo{flex-flow:row}}@media screen and (max-width:767px){.xo-default-footer-get-app[data-v-4ef01d40]{flex-flow:column;align-items:center;justify-content:flex-start;grid-gap:30px;gap:30px}.xo-default-footer-get-app[data-v-4ef01d40] .app-logo{justify-content:space-around}.xo-default-footer-get-app[data-v-4ef01d40] .app-logo img{width:166px;height:43px}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1362:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/Default/Footer/GetApp.vue?vue&type=template&id=4ef01d40&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xo-default-footer-get-app flex-column"},[_vm._ssrNode("<div class=\"logo\" data-v-4ef01d40><img"+(_vm._ssrAttr("src",__webpack_require__(89)))+" width=\"100\" height=\"43\" alt=\"FX1\" data-v-4ef01d40></div><div class=\"app-logo row\" data-v-4ef01d40><a href=\"https://apps.apple.com/us/app/fx1/id1626034650\" target=\"_blank\" class=\"app-store\" data-v-4ef01d40><img"+(_vm._ssrAttr("src",__webpack_require__(451)))+" alt=\"App Store\" data-v-4ef01d40></a><a href=\"https://play.google.com/store/apps/details?id=io.fx1.sports\" target=\"_blank\" class=\"playstore\" data-v-4ef01d40><img"+(_vm._ssrAttr("src",__webpack_require__(452)))+" alt=\"Playstore\" data-v-4ef01d40></a></div>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/Default/Footer/GetApp.vue?vue&type=template&id=4ef01d40&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/Default/Footer/GetApp.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var GetAppvue_type_script_lang_js_ = ({
  name: 'XODefaultFooterGetApp'
});
// CONCATENATED MODULE: ./components/organisms/Default/Footer/GetApp.vue?vue&type=script&lang=js&
 /* harmony default export */ var Footer_GetAppvue_type_script_lang_js_ = (GetAppvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/organisms/Default/Footer/GetApp.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1150)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Footer_GetAppvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "4ef01d40",
  "61679c3c"
  
)

/* harmony default export */ var GetApp = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 451:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/appstore.2854c99.svg";

/***/ }),

/***/ 452:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/googleplay.9921262.svg";

/***/ }),

/***/ 918:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1151);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("c2b5b256", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=6.js.map
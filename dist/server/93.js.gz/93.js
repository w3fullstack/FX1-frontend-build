exports.ids = [93];
exports.modules = {

/***/ 1224:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ConsumerSection_vue_vue_type_style_index_0_id_0f817847_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(955);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ConsumerSection_vue_vue_type_style_index_0_id_0f817847_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ConsumerSection_vue_vue_type_style_index_0_id_0f817847_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ConsumerSection_vue_vue_type_style_index_0_id_0f817847_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ConsumerSection_vue_vue_type_style_index_0_id_0f817847_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1225:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(24);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(614);
var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(618);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".consumer-section[data-v-0f817847]{position:relative;z-index:99}.consumer-section .token-p[data-v-0f817847]{margin-top:11%}.consumer-section .token-h2[data-v-0f817847]{font-weight:300;color:#fff;font-size:30px}.consumer-section .row[data-v-0f817847]{align-items:center}@media screen and (max-width:500px){.consumer-section .row[data-v-0f817847]{flex-direction:column}}.consumer-section .consumer-option[data-v-0f817847],.consumer-section .consumer-option-b[data-v-0f817847]{margin-left:auto;margin-right:auto;max-width:98%!important;height:200px;padding:40px 0 40px 25%;border-radius:20px;border:1px solid #fff;box-shadow:inset 0 98px 100px -48px rgba(170,188,204,.2);background-color:#08252c}.consumer-section .consumer-option-b[data-v-0f817847]{padding:32px 24px;text-align:center;position:relative}.consumer-section .left[data-v-0f817847]{float:left!important;max-width:49%!important}.consumer-section .right[data-v-0f817847]{float:right!important;max-width:49%!important}.consumer-section .coins[data-v-0f817847],.consumer-section .coins-b[data-v-0f817847],.consumer-section .tickets[data-v-0f817847]{position:absolute;background-position:50%;background-repeat:no-repeat;width:100%;overflow:hidden;z-index:999}.consumer-section .coins[data-v-0f817847]{top:-15%;left:-15%;zoom:1.2}.consumer-section .coins[data-v-0f817847],.consumer-section .coins-b[data-v-0f817847]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");height:160%}.consumer-section .coins-b[data-v-0f817847]{top:0;left:0;width:100%;zoom:.9}.consumer-section .tickets[data-v-0f817847]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ");height:154%;top:-22%;left:11%;zoom:1.1}.consumer-section[data-v-0f817847] .tablet{display:none}@media screen and (max-width:1600px){.consumer-section[data-v-0f817847] .consumer-option{padding-left:28%}.consumer-section[data-v-0f817847] .coins{zoom:1}}@media screen and (max-width:1400px){.consumer-section[data-v-0f817847] .consumer-option{padding-left:26%}}@media screen and (max-width:1200px){.consumer-section[data-v-0f817847] .tablet{display:block}.consumer-section[data-v-0f817847] .all-other{display:none}.consumer-section[data-v-0f817847] .token-p{margin-top:15px}.consumer-section[data-v-0f817847] .consumer-option-b{height:260px}}@media screen and (max-width:767px){.consumer-section[data-v-0f817847] .row{align-items:unset}.consumer-section[data-v-0f817847] .consumer-option-b{max-width:60%!important}}@media screen and (max-width:539px){.consumer-section[data-v-0f817847] .tablet{display:none}.consumer-section[data-v-0f817847] .all-other{display:block}.consumer-section[data-v-0f817847] .consumer-option{max-width:100%!important;padding:24px 16px 24px 50%;height:108px}.consumer-section[data-v-0f817847] .coins{top:-15%;left:-25%;zoom:.6}}@media screen and (max-width:430px){.consumer-section[data-v-0f817847] .consumer-option{padding:24px 16px 24px 45%}.consumer-section[data-v-0f817847] .coins{top:-15%;left:-29%;zoom:.5}}@media screen and (max-width:355px){.consumer-section[data-v-0f817847] .token-h2{font-size:16px!important}.consumer-section[data-v-0f817847] .token-p{font-size:12px!important}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1403:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Jackpot/ConsumerSection.vue?vue&type=template&id=0f817847&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"consumer-section row"},[_vm._ssrNode("<div class=\"container token-container\" data-v-0f817847><div class=\"row justify-between\" data-v-0f817847><div class=\"col consumer-option left all-other\" data-v-0f817847><div class=\"coins\" data-v-0f817847></div><div class=\"token-h2\" data-v-0f817847>2,000,000 $FXI</div><h2 class=\"token-p grey-text\" data-v-0f817847>Shared between 5 winners</h2></div><div class=\"col consumer-option-b left tablet\" data-v-0f817847><div class=\"token-h2\" data-v-0f817847>2,000,000 $FXI</div><h2 class=\"token-p grey-text\" data-v-0f817847>Shared between 5 winners</h2><div class=\"coins-b\" data-v-0f817847></div></div></div></div>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Jackpot/ConsumerSection.vue?vue&type=template&id=0f817847&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Jackpot/ConsumerSection.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var ConsumerSectionvue_type_script_lang_js_ = ({
  name: 'XTDefaultJackpotFooter'
});
// CONCATENATED MODULE: ./components/molecules/Jackpot/ConsumerSection.vue?vue&type=script&lang=js&
 /* harmony default export */ var Jackpot_ConsumerSectionvue_type_script_lang_js_ = (ConsumerSectionvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/Jackpot/ConsumerSection.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1224)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Jackpot_ConsumerSectionvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "0f817847",
  "0253c880"
  
)

/* harmony default export */ var ConsumerSection = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 614:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/coins.c72fa9b.png";

/***/ }),

/***/ 618:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/tickets.80740f3.png";

/***/ }),

/***/ 955:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1225);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("2c09c219", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=93.js.map
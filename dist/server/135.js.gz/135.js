exports.ids = [135];
exports.modules = {

/***/ 1270:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WinPrizes_vue_vue_type_style_index_0_id_5773690f_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(978);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WinPrizes_vue_vue_type_style_index_0_id_5773690f_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WinPrizes_vue_vue_type_style_index_0_id_5773690f_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WinPrizes_vue_vue_type_style_index_0_id_5773690f_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WinPrizes_vue_vue_type_style_index_0_id_5773690f_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1271:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xm-home-catalogs-win-prizes[data-v-5773690f]{position:relative;min-height:270px}.xm-home-catalogs-win-prizes[data-v-5773690f] .img{height:auto;max-width:100%;border-radius:6%}.xm-home-catalogs-win-prizes[data-v-5773690f] .fight{position:absolute;z-index:2;bottom:10%;left:-10%}.xm-home-catalogs-win-prizes[data-v-5773690f] .fight img{border-radius:12px;width:238px}.xm-home-catalogs-win-prizes[data-v-5773690f] .stage{z-index:1;display:flex;justify-content:flex-end;align-items:flex-start;margin-right:-50px}.xm-home-catalogs-win-prizes[data-v-5773690f] .stage img{border-radius:12px}.xm-home-catalogs-win-prizes[data-v-5773690f] .winner{position:absolute;z-index:3;bottom:-32%;left:43%;overflow:hidden;border-radius:50%}.xm-home-catalogs-win-prizes[data-v-5773690f] .winner img{width:221px;height:221px}.xm-home-catalogs-win-prizes[data-v-5773690f] ._icon{background-color:#000;border-radius:10px;box-shadow:0 6px 20px rgba(0,0,0,.13);position:absolute;z-index:4}.xm-home-catalogs-win-prizes[data-v-5773690f] .microphone{top:22%;left:-20%}.xm-home-catalogs-win-prizes[data-v-5773690f] .battle{bottom:-10%;right:-6%}.xm-home-catalogs-win-prizes[data-v-5773690f] .online-text{flex-flow:row;grid-gap:8px;gap:8px;box-shadow:0 6px 20px rgba(0,0,0,.13);background-color:#f85454;position:absolute;border-radius:12px;z-index:2;height:40px;width:134px;top:10%;right:-30%}.xm-home-catalogs-win-prizes[data-v-5773690f] .online-text .row img{width:24px}.xm-home-catalogs-win-prizes[data-v-5773690f] .online-text p{color:#fff;font-weight:300;font-size:1rem}.xm-home-catalogs-win-prizes[data-v-5773690f] .level-up{flex-flow:row;grid-gap:10px;gap:10px;background-color:hsla(0,0%,100%,.8);width:183px;height:64px;border-radius:6px;border:1px solid #fff;box-shadow:0 6px 20px rgba(0,0,0,.13);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);z-index:4;position:absolute;bottom:-27%;left:6%}.xm-home-catalogs-win-prizes[data-v-5773690f] .level-up .value{color:#08252c}.xm-home-catalogs-win-prizes[data-v-5773690f] .level-up .value p.text-weight-bold{font-size:14px}.xm-home-catalogs-win-prizes[data-v-5773690f] .level-up .value p.text-weight-light{font-size:10px}.xm-home-catalogs-win-prizes[data-v-5773690f] .text-contents{position:absolute;bottom:40px;right:-30px;width:100%}.xm-home-catalogs-win-prizes[data-v-5773690f] .text-contents div{background-color:#fff;color:#0c353e;font-weight:300;padding:12px 20px;max-width:-moz-max-content;max-width:max-content;border-radius:5px;margin-top:10px}@media screen and (max-width:1439px){.xm-home-catalogs-win-prizes[data-v-5773690f] .winner{bottom:1%;left:60%}.xm-home-catalogs-win-prizes[data-v-5773690f] .winner img{max-width:170px;max-height:170px}.xm-home-catalogs-win-prizes[data-v-5773690f] .stage{margin-right:0}.xm-home-catalogs-win-prizes[data-v-5773690f] .stage img{width:226px}.xm-home-catalogs-win-prizes[data-v-5773690f] .fight{bottom:33%;left:24%}.xm-home-catalogs-win-prizes[data-v-5773690f] .fight img{width:182px}.xm-home-catalogs-win-prizes[data-v-5773690f] .online-text{right:-12%;width:103px;height:30px;grid-gap:5px;gap:5px;top:7%}.xm-home-catalogs-win-prizes[data-v-5773690f] .online-text .row img{width:18px}.xm-home-catalogs-win-prizes[data-v-5773690f] .online-text p{font-size:.85rem}.xm-home-catalogs-win-prizes[data-v-5773690f] .battle{right:-3%;bottom:17%}.xm-home-catalogs-win-prizes[data-v-5773690f] .battle img{width:46px;height:46px}.xm-home-catalogs-win-prizes[data-v-5773690f] .microphone{left:18%;top:15%}.xm-home-catalogs-win-prizes[data-v-5773690f] .microphone img{width:46px;height:46px}.xm-home-catalogs-win-prizes[data-v-5773690f] .level-up{bottom:5%;left:35%;width:140px;height:50px}.xm-home-catalogs-win-prizes[data-v-5773690f] .level-up .row img{width:24px}.xm-home-catalogs-win-prizes[data-v-5773690f] .level-up .value p.text-weight-bold{font-size:12px}.xm-home-catalogs-win-prizes[data-v-5773690f] .level-up .value p.text-weight-light{font-size:9px}}@media screen and (max-width:1215px){.xm-home-catalogs-win-prizes[data-v-5773690f] .battle{right:-15%}.xm-home-catalogs-win-prizes[data-v-5773690f] .level-up{left:29%}}@media screen and (max-width:1023px){.xm-home-catalogs-win-prizes[data-v-5773690f] .winner{bottom:13%;left:57%}.xm-home-catalogs-win-prizes[data-v-5773690f] .winner img{max-width:150px;max-height:150px}.xm-home-catalogs-win-prizes[data-v-5773690f] .stage img{width:200px}.xm-home-catalogs-win-prizes[data-v-5773690f] .online-text{right:-22px;width:90px;height:26px;grid-gap:5px;gap:5px}.xm-home-catalogs-win-prizes[data-v-5773690f] .online-text .row img{width:16px}.xm-home-catalogs-win-prizes[data-v-5773690f] .online-text p{font-size:.75rem}.xm-home-catalogs-win-prizes[data-v-5773690f] .fight{bottom:41%;left:22%}.xm-home-catalogs-win-prizes[data-v-5773690f] .fight img{width:160px}.xm-home-catalogs-win-prizes[data-v-5773690f] .battle{bottom:28%;right:-2px}.xm-home-catalogs-win-prizes[data-v-5773690f] .battle img{width:41px;height:41px}.xm-home-catalogs-win-prizes[data-v-5773690f] .microphone{left:15%;top:13%}.xm-home-catalogs-win-prizes[data-v-5773690f] .microphone img{width:41px;height:41px}.xm-home-catalogs-win-prizes[data-v-5773690f] .level-up{bottom:22%;left:33%;width:123px;height:43px;grid-gap:5px;gap:5px}.xm-home-catalogs-win-prizes[data-v-5773690f] .level-up .row img{width:20px}.xm-home-catalogs-win-prizes[data-v-5773690f] .level-up .value p.text-weight-bold{font-size:10px}.xm-home-catalogs-win-prizes[data-v-5773690f] .level-up .value p.text-weight-light{font-size:8px}}@media screen and (min-width:768px)and (max-width:960px){.xm-home-catalogs-win-prizes[data-v-5773690f] .battle{right:-18px}}@media screen and (max-width:767px){.xm-home-catalogs-win-prizes[data-v-5773690f]{margin-right:-95px}.xm-home-catalogs-win-prizes[data-v-5773690f] .stage img{width:199px}.xm-home-catalogs-win-prizes[data-v-5773690f] .online-text{right:-8%;top:37%}.xm-home-catalogs-win-prizes[data-v-5773690f] .fight{bottom:27%;left:-42%}.xm-home-catalogs-win-prizes[data-v-5773690f] .winner{bottom:-6%;left:7%}.xm-home-catalogs-win-prizes[data-v-5773690f] .level-up{bottom:-2%;left:-43%}.xm-home-catalogs-win-prizes[data-v-5773690f] .microphone{left:-53%;top:21%}.xm-home-catalogs-win-prizes[data-v-5773690f] .battle{bottom:11%;right:3%}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1424:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/v2/Home/Catalogs/WinPrizes.vue?vue&type=template&id=5773690f&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xm-home-catalogs-win-prizes"},[_vm._ssrNode("<div class=\"fight\" data-v-5773690f>","</div>",[_c('nuxt-img',{attrs:{"src":"/v2/Home/host-live-fight.png","format":"webp","width":"182","height":"120"}})],1),_vm._ssrNode("<div class=\"stage\" data-v-5773690f>","</div>",[_c('nuxt-img',{attrs:{"src":"/v2/Home/stadium.svg","format":"webp"}})],1),_vm._ssrNode("<div class=\"winner row\" data-v-5773690f>","</div>",[_c('nuxt-img',{attrs:{"src":"/v2/Home/host-live-winner.jpg","format":"webp"}})],1),_vm._ssrNode("<div class=\"microphone _icon row items-center justify-center\" data-v-5773690f>","</div>",[_c('nuxt-img',{attrs:{"src":"/v2/Home/broadcst-1.svg","width":"61","height":"61"}})],1),_vm._ssrNode("<div class=\"battle _icon row items-center justify-center\" data-v-5773690f>","</div>",[_c('nuxt-img',{attrs:{"src":"/v2/Home/broadcst-2.svg","width":"61","height":"61"}})],1),_vm._ssrNode("<div class=\"online-text row items-center justify-center\" data-v-5773690f>","</div>",[_vm._ssrNode("<div class=\"row\" data-v-5773690f>","</div>",[_c('nuxt-img',{attrs:{"src":"/v2/Home/participants-vector.svg","width":"21","height":"21"}})],1),_vm._ssrNode("<p data-v-5773690f>1.4k online</p>")],2),_vm._ssrNode("<div class=\"level-up row items-center justify-center\" data-v-5773690f>","</div>",[_vm._ssrNode("<div class=\"_icon2 row\" data-v-5773690f>","</div>",[_c('nuxt-img',{attrs:{"src":"/v2/Home/medal.svg","width":"32","height":"32"}})],1),_vm._ssrNode("<div class=\"value\" data-v-5773690f><p class=\"text-weight-bold\" data-v-5773690f>Level up!</p><p class=\"text-weight-light\" data-v-5773690f>Your rank is upgraded</p></div>")],2),_vm._ssrNode("<div class=\"level-up-rank row\" data-v-5773690f></div>")],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/v2/Home/Catalogs/WinPrizes.vue?vue&type=template&id=5773690f&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/v2/Home/Catalogs/WinPrizes.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var WinPrizesvue_type_script_lang_js_ = ({
  name: 'XMHomeCatalogsWinPrizes'
});
// CONCATENATED MODULE: ./components/molecules/v2/Home/Catalogs/WinPrizes.vue?vue&type=script&lang=js&
 /* harmony default export */ var Catalogs_WinPrizesvue_type_script_lang_js_ = (WinPrizesvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/v2/Home/Catalogs/WinPrizes.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1270)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Catalogs_WinPrizesvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "5773690f",
  "46496c31"
  
)

/* harmony default export */ var WinPrizes = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 978:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1271);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("3673dca8", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=135.js.map
exports.ids = [101];
exports.modules = {

/***/ 1174:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ShouldCare_vue_vue_type_style_index_0_id_b0bf63e0_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(930);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ShouldCare_vue_vue_type_style_index_0_id_b0bf63e0_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ShouldCare_vue_vue_type_style_index_0_id_b0bf63e0_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ShouldCare_vue_vue_type_style_index_0_id_b0bf63e0_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ShouldCare_vue_vue_type_style_index_0_id_b0bf63e0_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1175:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".should-care-section[data-v-b0bf63e0]{width:100%;position:relative;padding:225px 0 0;z-index:2}@media screen and (max-width:1025px){.should-care-section[data-v-b0bf63e0]{padding:140px 0 0}}@media screen and (max-width:500px){.should-care-section[data-v-b0bf63e0] .token-container .row{flex-direction:column}}.should-care-section[data-v-b0bf63e0] .top-margin-a{margin-top:25px}.should-care-section[data-v-b0bf63e0] .top-margin-b{margin-top:70px}.should-care-section[data-v-b0bf63e0] .circles{width:400%;max-width:unset;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);overflow:hidden;z-index:-1}.should-care-section[data-v-b0bf63e0] .left-side{padding-right:0}.should-care-section[data-v-b0bf63e0] .left-side h2{font-size:60px}@media screen and (max-width:1025px){.should-care-section[data-v-b0bf63e0] .left-side h2{font-size:36px;line-height:40px;font-weight:700}}@media screen and (max-width:500px){.should-care-section[data-v-b0bf63e0] .left-side h2{font-size:28px;line-height:31px}}.should-care-section[data-v-b0bf63e0] .left-side ul.token-u{padding-left:5%;margin-top:50px}@media screen and (max-width:1025px){.should-care-section[data-v-b0bf63e0] .left-side ul.token-u{margin-top:60px}}@media screen and (max-width:500px){.should-care-section[data-v-b0bf63e0] .left-side ul.token-u{margin-top:40px}}.should-care-section[data-v-b0bf63e0] .left-side ul.token-u li.token-p{font-size:24px!important;line-height:32px!important}@media screen and (max-width:1025px){.should-care-section[data-v-b0bf63e0] .left-side ul.token-u li.token-p{font-size:18px!important;line-height:28px!important}}@media screen and (max-width:500){.should-care-section[data-v-b0bf63e0] .left-side ul.token-u li.token-p{font-size:16px!important}}.should-care-section[data-v-b0bf63e0] .left-side ul.token-u li:first-child{max-width:85%}.should-care-section[data-v-b0bf63e0] .left-side ul.token-u li:last-child{max-width:70%}.should-care-section[data-v-b0bf63e0] .right-side{position:relative;display:flex;justify-content:flex-end;align-items:center}@media screen and (max-width:500px){.should-care-section[data-v-b0bf63e0] .right-side{margin-top:70px;justify-content:center}}.should-care-section[data-v-b0bf63e0] .right-side .video-container{position:relative;box-shadow:0 25px 77px -10px hsla(0,0%,100%,.2);max-height:426px}@media screen and (max-width:1025px){.should-care-section[data-v-b0bf63e0] .right-side .video-container{max-height:287px}}.should-care-section[data-v-b0bf63e0] .right-side .video-container .gameboss-video{width:426px}@media screen and (max-width:1025px){.should-care-section[data-v-b0bf63e0] .right-side .video-container .gameboss-video{max-width:287px}}@media screen and (max-width:500px){.should-care-section[data-v-b0bf63e0]{padding:0}.should-care-section[data-v-b0bf63e0] .top-margin-b{margin-top:0!important}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1372:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/BossMembership/ShouldCare.vue?vue&type=template&id=b0bf63e0&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"should-care-section row"},[_vm._ssrNode("<div class=\"container token-container\" data-v-b0bf63e0><div class=\"row\" data-v-b0bf63e0><div class=\"col left-side\" data-v-b0bf63e0><h2 data-v-b0bf63e0>Why should I care?</h2><ul class=\"token-u\" data-v-b0bf63e0><li class=\"token-p\" data-v-b0bf63e0>Because once it sells out, you may never be able get one.</li><div class=\"top-margin-a\" data-v-b0bf63e0></div><li class=\"token-p\" data-v-b0bf63e0>We’re only releasing 100 spots; that’s not a high number.</li></ul></div><div class=\"col right-side text-center\" data-v-b0bf63e0><div class=\"video-container\" data-v-b0bf63e0><video src=\"GameBossMembership.mp4\" controls=\"controls\" class=\"gameboss-video\" data-v-b0bf63e0></video><img"+(_vm._ssrAttr("src",__webpack_require__(600)))+" alt=\"circles\" class=\"circles\" data-v-b0bf63e0></div></div></div></div>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/BossMembership/ShouldCare.vue?vue&type=template&id=b0bf63e0&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/BossMembership/ShouldCare.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var ShouldCarevue_type_script_lang_js_ = ({
  name: 'SouldCare'
});
// CONCATENATED MODULE: ./components/molecules/BossMembership/ShouldCare.vue?vue&type=script&lang=js&
 /* harmony default export */ var BossMembership_ShouldCarevue_type_script_lang_js_ = (ShouldCarevue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/BossMembership/ShouldCare.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1174)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  BossMembership_ShouldCarevue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "b0bf63e0",
  "7c962474"
  
)

/* harmony default export */ var ShouldCare = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 600:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/circle-3.0bf5c96.png";

/***/ }),

/***/ 930:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1175);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("0259929b", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=101.js.map
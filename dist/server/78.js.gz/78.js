exports.ids = [78];
exports.modules = {

/***/ 1057:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_style_index_0_id_760f5ca7_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(872);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_style_index_0_id_760f5ca7_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_style_index_0_id_760f5ca7_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_style_index_0_id_760f5ca7_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_style_index_0_id_760f5ca7_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1058:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xm-account-tabs-list[data-v-760f5ca7]{position:sticky;width:100%;height:-moz-fit-content;height:fit-content;max-width:244px;top:60px;padding:40px 28px}@media screen and (min-width:769px){.xm-account-tabs-list[data-v-760f5ca7]{display:block!important}}@media screen and (max-width:768px){.xm-account-tabs-list[data-v-760f5ca7]{max-width:unset;padding:24px 0}}.xm-account-tabs-list[data-v-760f5ca7] .divider{width:100%;height:1px;background-color:#2a4e55;margin:32px 0}@media screen and (max-width:768px){.xm-account-tabs-list[data-v-760f5ca7] .divider{margin:24px 20px}}.xm-account-tabs-list[data-v-760f5ca7] ul{display:flex;flex-direction:column;grid-gap:20px;gap:20px}.xm-account-tabs-list[data-v-760f5ca7] ul li a{display:inline-block;width:100%;padding:12px 20px;color:#fff}.xm-account-tabs-list[data-v-760f5ca7] ul li a.active{background-color:#2a4e55;border-radius:2px}.xm-account-tabs-list[data-v-760f5ca7] .logout{display:flex;align-items:center;grid-gap:14px;gap:14px;margin:0 20px;cursor:pointer}.xm-account-tabs-list[data-v-760f5ca7] .logout p{color:#f85454;font-size:16px}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1059:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Content_vue_vue_type_style_index_0_id_0cefc6ab_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(873);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Content_vue_vue_type_style_index_0_id_0cefc6ab_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Content_vue_vue_type_style_index_0_id_0cefc6ab_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Content_vue_vue_type_style_index_0_id_0cefc6ab_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Content_vue_vue_type_style_index_0_id_0cefc6ab_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1060:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xm-account-tabs-content[data-v-0cefc6ab]{width:100%;padding:40px 28px}@media screen and (min-width:769px){.xm-account-tabs-content[data-v-0cefc6ab]{border-left:1px solid #2a4e55}}@media screen and (max-width:768px){.xm-account-tabs-content[data-v-0cefc6ab]{padding:24px 20px}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1061:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Breadcrumbs_vue_vue_type_style_index_0_id_0d751b66_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(874);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Breadcrumbs_vue_vue_type_style_index_0_id_0d751b66_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Breadcrumbs_vue_vue_type_style_index_0_id_0d751b66_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Breadcrumbs_vue_vue_type_style_index_0_id_0d751b66_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Breadcrumbs_vue_vue_type_style_index_0_id_0d751b66_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1062:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xt-account-breadcrumbs[data-v-0d751b66]{position:sticky;top:80px;background-color:#2a4e55;border-bottom:1px solid #385960;padding:10px 20px;z-index:1}@media screen and (min-width:769px){.xt-account-breadcrumbs[data-v-0d751b66]{display:none}}@media screen and (max-width:767px){.xt-account-breadcrumbs[data-v-0d751b66]{top:58px}}.xt-account-breadcrumbs[data-v-0d751b66] h2{font-size:22px}.xt-account-breadcrumbs[data-v-0d751b66] .back{margin-right:24px;cursor:pointer}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1063:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Tabs_vue_vue_type_style_index_0_id_6dbe5470_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(875);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Tabs_vue_vue_type_style_index_0_id_6dbe5470_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Tabs_vue_vue_type_style_index_0_id_6dbe5470_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Tabs_vue_vue_type_style_index_0_id_6dbe5470_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Tabs_vue_vue_type_style_index_0_id_6dbe5470_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1064:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xo-tabs[data-v-6dbe5470]{display:flex;width:100%}@media screen and (max-width:768px){.xo-tabs[data-v-6dbe5470]{flex-direction:column}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1065:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Account_vue_vue_type_style_index_0_id_1aea2d3f_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(876);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Account_vue_vue_type_style_index_0_id_1aea2d3f_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Account_vue_vue_type_style_index_0_id_1aea2d3f_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Account_vue_vue_type_style_index_0_id_1aea2d3f_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Account_vue_vue_type_style_index_0_id_1aea2d3f_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1066:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xp-account[data-v-1aea2d3f]{display:flex;flex-grow:1;background-color:#08252c}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1304:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/Account.vue?vue&type=template&id=1aea2d3f&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xp-account"},[_c('XOTabs')],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/pages/Account.vue?vue&type=template&id=1aea2d3f&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/Account/Tabs.vue?vue&type=template&id=6dbe5470&scoped=true&lang=pug&
var Tabsvue_type_template_id_6dbe5470_scoped_true_lang_pug_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xo-tabs"},[_c('XTAccountBreadcrumbs',{attrs:{"getRouterName":_vm.getRouterName}}),_c('XMTabsList',{attrs:{"getRouterName":_vm.getRouterName}}),_c('XMTabsContent')],1)}
var Tabsvue_type_template_id_6dbe5470_scoped_true_lang_pug_staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/Account/Tabs.vue?vue&type=template&id=6dbe5470&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Account/Tabs/List.vue?vue&type=template&id=760f5ca7&scoped=true&lang=pug&
var Listvue_type_template_id_760f5ca7_scoped_true_lang_pug_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{directives:[{name:"show",rawName:"v-show",value:(_vm.isShowList),expression:"isShowList"}],staticClass:"xm-account-tabs-list"},[_vm._ssrNode("<ul data-v-760f5ca7>","</ul>",_vm._l((_vm.routes),function(route){return _vm._ssrNode("<li data-v-760f5ca7>","</li>",[_c('router-link',{attrs:{"to":route.path}},[_vm._v(_vm._s(route.name))])],1)}),0),_vm._ssrNode("<div class=\"divider\" data-v-760f5ca7></div>"),_vm._ssrNode("<ul data-v-760f5ca7>","</ul>",[_vm._ssrNode("<li data-v-760f5ca7>","</li>",[_c('router-link',{attrs:{"to":"/terms-conditions"}},[_vm._v("Terms & Conditions")])],1),_vm._ssrNode("<li data-v-760f5ca7>","</li>",[_c('router-link',{attrs:{"to":"/privacy"}},[_vm._v("Privacy Policy")])],1),_vm._ssrNode("<li data-v-760f5ca7>","</li>",[_c('router-link',{attrs:{"to":"/contact"}},[_vm._v("Contact Us")])],1)]),_vm._ssrNode("<div class=\"divider\" data-v-760f5ca7></div><div class=\"logout\" data-v-760f5ca7><p data-v-760f5ca7>Log out</p><img"+(_vm._ssrAttr("src",__webpack_require__(91)))+" data-v-760f5ca7></div>")],2)}
var Listvue_type_template_id_760f5ca7_scoped_true_lang_pug_staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Account/Tabs/List.vue?vue&type=template&id=760f5ca7&scoped=true&lang=pug&

// EXTERNAL MODULE: external "vuex"
var external_vuex_ = __webpack_require__(4);

// EXTERNAL MODULE: external "lodash/cloneDeep"
var cloneDeep_ = __webpack_require__(232);
var cloneDeep_default = /*#__PURE__*/__webpack_require__.n(cloneDeep_);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Account/Tabs/List.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ var Listvue_type_script_lang_js_ = ({
  name: 'XMAccountTabsList',
  props: {
    getRouterName: {
      type: Function,
      default: null
    }
  },
  computed: {
    isShowList() {
      return this.$route.path === '/account';
    },
    routes() {
      const routes = cloneDeep_default()(this.$router.options.routes);
      return routes.find(r => r.name === 'account').children.map(r => {
        r.path = `/account/${r.path}`;
        r.name = this.getRouterName(r.name) || r.name;
        return r;
      }).reverse();
    }
  },
  methods: {
    ...Object(external_vuex_["mapActions"])({
      authLogOut: 'auth/authLogOut',
      clearAuthDetails: 'auth/clearAuthDetails'
    }),
    async fnLogOut() {
      this.$fireMess.unSubscribeToTopic({
        topicName: this.userID
      });
      await this.authLogOut();
      const disconnect = this.$root.ChatSocket ? this.$root.ChatSocket.disconnect() : null;
      await this.$router.push({
        path: '/'
      });
      await this.clearAuthDetails();
      this.$mixpanel.reset();
      return disconnect;
    }
  }
});
// CONCATENATED MODULE: ./components/molecules/Account/Tabs/List.vue?vue&type=script&lang=js&
 /* harmony default export */ var Tabs_Listvue_type_script_lang_js_ = (Listvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/Account/Tabs/List.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1057)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Tabs_Listvue_type_script_lang_js_,
  Listvue_type_template_id_760f5ca7_scoped_true_lang_pug_render,
  Listvue_type_template_id_760f5ca7_scoped_true_lang_pug_staticRenderFns,
  false,
  injectStyles,
  "760f5ca7",
  "6ff7a638"
  
)

/* harmony default export */ var List = (component.exports);
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Account/Tabs/Content.vue?vue&type=template&id=0cefc6ab&scoped=true&lang=pug&
var Contentvue_type_template_id_0cefc6ab_scoped_true_lang_pug_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return (_vm.isShowContent)?_c('div',{staticClass:"xm-account-tabs-content"},[_c('nuxt-child')],1):_vm._e()}
var Contentvue_type_template_id_0cefc6ab_scoped_true_lang_pug_staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Account/Tabs/Content.vue?vue&type=template&id=0cefc6ab&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Account/Tabs/Content.vue?vue&type=script&lang=js&
//
//
//
//
//

/* harmony default export */ var Contentvue_type_script_lang_js_ = ({
  name: 'XMAccountTabsContent',
  computed: {
    isShowContent() {
      return this.$route.name !== 'account';
    }
  }
});
// CONCATENATED MODULE: ./components/molecules/Account/Tabs/Content.vue?vue&type=script&lang=js&
 /* harmony default export */ var Tabs_Contentvue_type_script_lang_js_ = (Contentvue_type_script_lang_js_); 
// CONCATENATED MODULE: ./components/molecules/Account/Tabs/Content.vue



function Content_injectStyles (context) {
  
  var style0 = __webpack_require__(1059)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var Content_component = Object(componentNormalizer["a" /* default */])(
  Tabs_Contentvue_type_script_lang_js_,
  Contentvue_type_template_id_0cefc6ab_scoped_true_lang_pug_render,
  Contentvue_type_template_id_0cefc6ab_scoped_true_lang_pug_staticRenderFns,
  false,
  Content_injectStyles,
  "0cefc6ab",
  "05e6d323"
  
)

/* harmony default export */ var Content = (Content_component.exports);
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/templates/Account/Breadcrumbs.vue?vue&type=template&id=0d751b66&scoped=true&lang=pug&
var Breadcrumbsvue_type_template_id_0d751b66_scoped_true_lang_pug_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xt-account-breadcrumbs"},[_vm._ssrNode("<div class=\"row items-center\" data-v-0d751b66><div class=\"left-breadcrumbs row items-center\" data-v-0d751b66>"+((_vm.isShowBackArrow)?("<div class=\"back row\" data-v-0d751b66><img"+(_vm._ssrAttr("src",__webpack_require__(88)))+" data-v-0d751b66></div>"):"<!---->")+"<h2 data-v-0d751b66>"+_vm._ssrEscape(_vm._s(_vm.title))+"</h2></div></div>")])}
var Breadcrumbsvue_type_template_id_0d751b66_scoped_true_lang_pug_staticRenderFns = []


// CONCATENATED MODULE: ./components/templates/Account/Breadcrumbs.vue?vue&type=template&id=0d751b66&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/templates/Account/Breadcrumbs.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Breadcrumbsvue_type_script_lang_js_ = ({
  name: 'XTAccountBreadcrumbs',
  props: {
    getRouterName: {
      type: Function,
      default: null
    }
  },
  computed: {
    isShowBackArrow() {
      return this.$route.name !== 'account';
    },
    title() {
      return this.getRouterName(this.$route.name);
    }
  },
  methods: {
    fnGoBack() {
      this.$router.push({
        path: '/account'
      });
    }
  }
});
// CONCATENATED MODULE: ./components/templates/Account/Breadcrumbs.vue?vue&type=script&lang=js&
 /* harmony default export */ var Account_Breadcrumbsvue_type_script_lang_js_ = (Breadcrumbsvue_type_script_lang_js_); 
// CONCATENATED MODULE: ./components/templates/Account/Breadcrumbs.vue



function Breadcrumbs_injectStyles (context) {
  
  var style0 = __webpack_require__(1061)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var Breadcrumbs_component = Object(componentNormalizer["a" /* default */])(
  Account_Breadcrumbsvue_type_script_lang_js_,
  Breadcrumbsvue_type_template_id_0d751b66_scoped_true_lang_pug_render,
  Breadcrumbsvue_type_template_id_0d751b66_scoped_true_lang_pug_staticRenderFns,
  false,
  Breadcrumbs_injectStyles,
  "0d751b66",
  "13226438"
  
)

/* harmony default export */ var Breadcrumbs = (Breadcrumbs_component.exports);
// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/Account/Tabs.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//




/* harmony default export */ var Tabsvue_type_script_lang_js_ = ({
  name: 'XOAccountTabs',
  components: {
    XMTabsList: List,
    XMTabsContent: Content,
    XTAccountBreadcrumbs: Breadcrumbs
  },
  methods: {
    getRouterName(name) {
      const names = {
        'account': 'My Account',
        'account-settings': 'Account Settings',
        'account-linked-accounts': 'Linked Accounts'
      };
      return names[name];
    }
  }
});
// CONCATENATED MODULE: ./components/organisms/Account/Tabs.vue?vue&type=script&lang=js&
 /* harmony default export */ var Account_Tabsvue_type_script_lang_js_ = (Tabsvue_type_script_lang_js_); 
// CONCATENATED MODULE: ./components/organisms/Account/Tabs.vue



function Tabs_injectStyles (context) {
  
  var style0 = __webpack_require__(1063)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var Tabs_component = Object(componentNormalizer["a" /* default */])(
  Account_Tabsvue_type_script_lang_js_,
  Tabsvue_type_template_id_6dbe5470_scoped_true_lang_pug_render,
  Tabsvue_type_template_id_6dbe5470_scoped_true_lang_pug_staticRenderFns,
  false,
  Tabs_injectStyles,
  "6dbe5470",
  "407aa672"
  
)

/* harmony default export */ var Tabs = (Tabs_component.exports);
// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/Account.vue?vue&type=script&lang=js&
//
//
//
//
//


/* harmony default export */ var Accountvue_type_script_lang_js_ = ({
  name: 'XPAccount',
  components: {
    XOTabs: Tabs
  }
});
// CONCATENATED MODULE: ./components/pages/Account.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_Accountvue_type_script_lang_js_ = (Accountvue_type_script_lang_js_); 
// CONCATENATED MODULE: ./components/pages/Account.vue



function Account_injectStyles (context) {
  
  var style0 = __webpack_require__(1065)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var Account_component = Object(componentNormalizer["a" /* default */])(
  pages_Accountvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  Account_injectStyles,
  "1aea2d3f",
  "1685d01b"
  
)

/* harmony default export */ var Account = __webpack_exports__["default"] = (Account_component.exports);

/***/ }),

/***/ 872:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1058);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("e5bf87fe", content, true, context)
};

/***/ }),

/***/ 873:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1060);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("09ad1560", content, true, context)
};

/***/ }),

/***/ 874:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1062);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("7c1ad4ee", content, true, context)
};

/***/ }),

/***/ 875:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1064);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("d13a3f74", content, true, context)
};

/***/ }),

/***/ 876:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1066);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("67e8f7b9", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=78.js.map
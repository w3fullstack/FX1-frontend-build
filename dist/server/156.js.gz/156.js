exports.ids = [156];
exports.modules = {

/***/ 1359:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/Auth/Header/Left.vue?vue&type=template&id=70d332d8&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xo-auth-header-left"},[_c('nuxt-link',{staticClass:"row",attrs:{"to":"/"}},[_c('img',{attrs:{"src":__webpack_require__(656),"width":"58","height":"43"}})])],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/Auth/Header/Left.vue?vue&type=template&id=70d332d8&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/Auth/Header/Left.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Leftvue_type_script_lang_js_ = ({
  name: 'XOAuthHeaderLeft'
});
// CONCATENATED MODULE: ./components/organisms/Auth/Header/Left.vue?vue&type=script&lang=js&
 /* harmony default export */ var Header_Leftvue_type_script_lang_js_ = (Leftvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/organisms/Auth/Header/Left.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Header_Leftvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  "4c4cbd47"
  
)

/* harmony default export */ var Left = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 656:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iMTciIHZpZXdCb3g9IjAgMCA0MCAxNyIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik03LjI0OCA3LjM1MkgxNC42NEwxMy43NzYgMTEuNjI0SDYuNDA4TDcuMjQ4IDcuMzUyWk01LjcxMiAxN0gwLjA0OEwzLjQwOCAwLjE5OTk5OUgxNy4wNjRMMTYuMiA0LjQ3Mkg4LjIwOEw1LjcxMiAxN1pNOS42NzQ5NCAxN0wxOS4xNTQ5IDYuNjA4TDE4LjQxMDkgOS44OTZMMTMuMzQ2OSAwLjE5OTk5OUgxOS4zOTQ5TDIyLjMyMjkgNi4xNzZMMTkuODc0OSA2LjIyNEwyNS4wNTg5IDAuMTk5OTk5SDMxLjQ0MjlMMjIuNTg2OSA5Ljk2OEwyMi43Nzg5IDYuNzc2TDI4LjI5ODkgMTdIMjIuMTc4OUwxOS4xMzA5IDEwLjcxMkwyMS42OTg5IDEwLjc2TDE2LjQ0MjkgMTdIOS42NzQ5NFoiIGZpbGw9IiMwQzM1M0UiIGZpbGwtb3BhY2l0eT0iMC44Ii8+DQo8cGF0aCBkPSJNMzAuMzY3NSAxN0wzMy4zMTk1IDIuMjRMMzUuMjg3NSA0LjQ3MkgyOS45ODM1TDMwLjg0NzUgMC4xOTk5OTlIMzkuMzkxNUwzNi4wMzE1IDE3SDMwLjM2NzVaIiBmaWxsPSIjRjg1NDU0Ii8+DQo8L3N2Zz4NCg=="

/***/ })

};;
//# sourceMappingURL=156.js.map
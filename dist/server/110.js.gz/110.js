exports.ids = [110];
exports.modules = {

/***/ 1216:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Catalogs_vue_vue_type_style_index_0_id_5d061506_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(951);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Catalogs_vue_vue_type_style_index_0_id_5d061506_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Catalogs_vue_vue_type_style_index_0_id_5d061506_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Catalogs_vue_vue_type_style_index_0_id_5d061506_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Catalogs_vue_vue_type_style_index_0_id_5d061506_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1217:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(24);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(478);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xo-home-section-catalogs[data-v-5d061506]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");background-repeat:no-repeat;background-position:left 0 bottom -120px;background-color:#000;padding:65px 0 100px}.xo-home-section-catalogs[data-v-5d061506] h1{margin-bottom:50px}.xo-home-section-catalogs[data-v-5d061506] .catalogs-container{display:grid;grid-template-columns:1fr 1fr;grid-gap:24px;gap:24px;grid-auto-flow:row;grid-template-areas:\"claim-medal analytics\" \"claim-medal explore-events\" \"help explore-events\" \"peer-to-peer peer-to-peer\"}.xo-home-section-catalogs[data-v-5d061506] .catalogs-container .content-section{position:relative;padding:48px 64px;border-radius:10px;grid-gap:75px;gap:75px}.xo-home-section-catalogs[data-v-5d061506] .catalogs-container .content-section .left-content h2{margin-bottom:28px}.xo-home-section-catalogs[data-v-5d061506] .catalogs-container .explore-events{grid-area:explore-events}.xo-home-section-catalogs[data-v-5d061506] .catalogs-container .claim-medal,.xo-home-section-catalogs[data-v-5d061506] .catalogs-container .explore-events{border-image-source:linear-gradient(127.3deg,#fff .38%,hsla(0,0%,100%,0) 59.4%);border:1px solid hsla(0,0%,100%,.2);background:rgba(0,0,0,.01);box-shadow:inset 0 1px 30px -5px rgba(227,222,255,.07),inset 0 4px 18px 0 rgba(146,156,210,.1),inset 0 98px 100px -48px rgba(170,188,204,.2);-webkit-backdrop-filter:blur(30px);backdrop-filter:blur(30px);flex-flow:column}.xo-home-section-catalogs[data-v-5d061506] .catalogs-container .claim-medal{z-index:11;grid-area:claim-medal}.xo-home-section-catalogs[data-v-5d061506] .catalogs-container .analytics{grid-area:analytics;color:#08252c;background:#ffaf23;background:var(--accent-orange,#ffaf23);box-shadow:0 1.06592px 2.80384px 0 rgba(255,175,35,.08),0 2.47835px 6.51914px 0 rgba(255,175,35,.12),0 4.45054px 11.70687px 0 rgba(255,175,35,.15),0 7.38625px 19.42906px 0 rgba(255,175,35,.17),0 12.1686px 32.00872px 0 rgba(255,175,35,.2),0 21.26719px 55.94197px 0 rgba(255,175,35,.24),0 46px 121px 0 rgba(255,175,35,.32)}.xo-home-section-catalogs[data-v-5d061506] .catalogs-container .peer-to-peer{padding:30px 60px;grid-area:peer-to-peer;border-image-source:linear-gradient(127.3deg,#fff .38%,hsla(0,0%,100%,0) 59.4%);border:1px solid hsla(0,0%,100%,.2);background:rgba(0,0,0,.01);box-shadow:inset 0 1px 30px -5px rgba(227,222,255,.07),inset 0 4px 18px 0 rgba(146,156,210,.1),inset 0 98px 100px -48px rgba(170,188,204,.2);-webkit-backdrop-filter:blur(30px);backdrop-filter:blur(30px);flex-direction:row-reverse}.xo-home-section-catalogs[data-v-5d061506] .catalogs-container .help{grid-area:help;color:#fff;background:#4f3b98;background:var(--accent-purple-700,#4f3b98);box-shadow:0 1.4113px 3.95718px 0 rgba(79,59,152,.12),0 3.39155px 9.50965px 0 rgba(79,59,152,.17),0 6.38599px 17.90582px 0 rgba(79,59,152,.21),0 11.39152px 31.94092px 0 rgba(79,59,152,.25),0 21.30658px 59.74198px 0 rgba(79,59,152,.3),0 51px 143px 0 rgba(79,59,152,.42)}@media screen and (max-width:1439px){.xo-home-section-catalogs[data-v-5d061506]{padding:40px 0 80px}.xo-home-section-catalogs[data-v-5d061506] .container h1{margin-bottom:35px}.xo-home-section-catalogs[data-v-5d061506] .container .catalogs-container{grid-gap:14px;gap:14px}.xo-home-section-catalogs[data-v-5d061506] .container .catalogs-container .content-section{padding:36px 28px;grid-gap:40px;gap:40px}.xo-home-section-catalogs[data-v-5d061506] .container .catalogs-container .content-section .left-content h2{margin-bottom:20px}}@media screen and (max-width:1023px){.xo-home-section-catalogs[data-v-5d061506] .container .catalogs-container{grid-template-areas:\"claim-medal claim-medal\" \"analytics help\" \"explore-events explore-events\" \"peer-to-peer peer-to-peer\";grid-gap:20px;gap:20px}.xo-home-section-catalogs[data-v-5d061506] .container .catalogs-container .claim-medal,.xo-home-section-catalogs[data-v-5d061506] .container .catalogs-container .explore-events{flex-flow:row;grid-gap:10px;gap:10px}}@media screen and (min-width:768px)and (max-width:850px){.xo-home-section-catalogs[data-v-5d061506] .container .catalogs-container .explore-events .right-content{width:350px}}@media screen and (max-width:767px){.xo-home-section-catalogs[data-v-5d061506]{padding:50px 0}.xo-home-section-catalogs[data-v-5d061506] .container h1{margin-bottom:20px}.xo-home-section-catalogs[data-v-5d061506] .container .catalogs-container{grid-gap:20px;gap:20px;grid-template-columns:1fr;grid-template-areas:\"claim-medal\" \"analytics\" \"explore-events\" \"help\"}.xo-home-section-catalogs[data-v-5d061506] .container .catalogs-container .peer-to-peer{display:none}.xo-home-section-catalogs[data-v-5d061506] .container .catalogs-container .content-section{padding:30px 20px}.xo-home-section-catalogs[data-v-5d061506] .container .catalogs-container .content-section .left-content h2{margin-bottom:10px}.xo-home-section-catalogs[data-v-5d061506] .container .catalogs-container .claim-medal{flex-flow:column;grid-gap:30px;gap:30px}.xo-home-section-catalogs[data-v-5d061506] .container .catalogs-container .explore-events{flex-flow:column;align-items:center}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1389:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/v2/Home/Catalogs.vue?vue&type=template&id=5d061506&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xo-home-section-catalogs"},[_vm._ssrNode("<div class=\"container is-max-widescreen\" data-v-5d061506>","</div>",[_vm._ssrNode("<h1 data-v-5d061506>Coming soon</h1>"),_vm._ssrNode("<div class=\"catalogs-container\" data-v-5d061506>","</div>",[_vm._ssrNode("<div class=\"content-section claim-medal row\" data-v-5d061506>","</div>",[_vm._ssrNode("<div class=\"left-content col\" data-v-5d061506><h2 data-v-5d061506>Supercharged Sports Betting</h2><p class=\"txt-intro text-weight-light\" data-v-5d061506>Live sports betting using regular currency or crypto that rewards you even when you lose. Earn medals and trophies as you climb conferences and make your way to the top.</p></div>"),_vm._ssrNode("<div class=\"right-content col\" data-v-5d061506>","</div>",[_c('XMHomeCatalogsFanLeaderboard')],1)],2),_vm._ssrNode("<div class=\"content-section help row\" data-v-5d061506><div class=\"left-content col\" data-v-5d061506><h2 data-v-5d061506>The FX1 Edge</h2><p class=\"txt-intro text-weight-light\" data-v-5d061506>The FX1 Edge is the help you have been looking for to supercharge your sports betting. Get access to newly undiscovered data that not even the professionals are aware of, or have access to.</p></div></div><div class=\"content-section analytics row\" data-v-5d061506><div class=\"left-content col\" data-v-5d061506><h2 data-v-5d061506>Live Game Analytics</h2><p class=\"txt-intro text-weight-light\" data-v-5d061506>We’re working to provide more than just real-time stats for live sports games. Our proprietary AI technology and time-based charts allow you to understand the game better than you ever have before.</p></div></div>"),_vm._ssrNode("<div class=\"content-section peer-to-peer row\" data-v-5d061506>","</div>",[_vm._ssrNode("<div class=\"left-content col\" data-v-5d061506><h2 data-v-5d061506>Why Peer-to-Peer</h2><p class=\"txt-intro text-weight-light\" data-v-5d061506>Peer-to-peer is the future of sports betting. Peer-to-peer is you betting against someone else, not the house or the bookie and comes with many benefits including lower fees and better odds.</p></div>"),_vm._ssrNode("<div class=\"right-content col\" data-v-5d061506>","</div>",[_c('XMHomeCatalogsAmbassador')],1)],2),_vm._ssrNode("<div class=\"content-section explore-events row\" data-v-5d061506>","</div>",[_vm._ssrNode("<div class=\"left-content col\" data-v-5d061506><h2 data-v-5d061506>An Interactive Experience</h2><p class=\"txt-intro text-weight-light\" data-v-5d061506>Betting online is more fun with friends. We create a social experience delivering fun and entertainment using chat, audio and video. You can even create private groups and invite only your friends.</p></div>"),_vm._ssrNode("<div class=\"right-content col\" data-v-5d061506>","</div>",[_c('XMHomeCatalogsWinPrizes')],1)],2)],2)],2)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/v2/Home/Catalogs.vue?vue&type=template&id=5d061506&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/v2/Home/Catalogs.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Catalogsvue_type_script_lang_js_ = ({
  name: 'XOHomeCatalogs',
  components: {
    XMHomeCatalogsFanLeaderboard: () => __webpack_require__.e(/* import() */ 134).then(__webpack_require__.bind(null, 1423)),
    XMHomeCatalogsWinPrizes: () => __webpack_require__.e(/* import() */ 135).then(__webpack_require__.bind(null, 1424)),
    XMHomeCatalogsAmbassador: () => __webpack_require__.e(/* import() */ 133).then(__webpack_require__.bind(null, 1425))
  }
});
// CONCATENATED MODULE: ./components/organisms/v2/Home/Catalogs.vue?vue&type=script&lang=js&
 /* harmony default export */ var Home_Catalogsvue_type_script_lang_js_ = (Catalogsvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/organisms/v2/Home/Catalogs.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1216)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Home_Catalogsvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "5d061506",
  "f0fa3148"
  
)

/* harmony default export */ var Catalogs = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 478:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/circles-and-light-2.2dbec37.svg";

/***/ }),

/***/ 951:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1217);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("9b9b2fae", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=110.js.map
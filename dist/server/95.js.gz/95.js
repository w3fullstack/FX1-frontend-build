exports.ids = [95];
exports.modules = {

/***/ 1244:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_TeamSection_vue_vue_type_style_index_0_id_3d67aa7f_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(965);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_TeamSection_vue_vue_type_style_index_0_id_3d67aa7f_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_TeamSection_vue_vue_type_style_index_0_id_3d67aa7f_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_TeamSection_vue_vue_type_style_index_0_id_3d67aa7f_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_TeamSection_vue_vue_type_style_index_0_id_3d67aa7f_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1245:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".token-team-section[data-v-3d67aa7f]{width:100%;position:relative;overflow:hidden;padding:0 0 150px;z-index:2}.token-team-section[data-v-3d67aa7f] .top-margin-a{margin-top:25px}.token-team-section[data-v-3d67aa7f] .top-margin-b{margin-top:50px}@media screen and (max-width:500px){.token-team-section[data-v-3d67aa7f]{padding:50px 0}.token-team-section[data-v-3d67aa7f] .top-margin-b{margin-top:25px}.token-team-section[data-v-3d67aa7f] .top-margin-a{margin-top:0!important}.token-team-section[data-v-3d67aa7f] .right-side{margin-top:50px!important}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1412:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/TeamSection.vue?vue&type=template&id=3d67aa7f&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"token-team-section row"},[_vm._ssrNode("<div class=\"container token-container text-center\" data-v-3d67aa7f><h1 data-v-3d67aa7f>Team</h1><div class=\"top-margin-b\" data-v-3d67aa7f></div><div class=\"row\" data-v-3d67aa7f><div class=\"col left-side\" data-v-3d67aa7f><a href=\"https://assuredefi.com/projects/fx1/\" target=\"_blank\" data-v-3d67aa7f><img"+(_vm._ssrAttr("src",__webpack_require__(641)))+" alt=\"Damien Team Member\" data-v-3d67aa7f></a><h2 data-v-3d67aa7f>Damien</h2><div class=\"top-margin-a\" data-v-3d67aa7f></div><p class=\"token-p\" data-v-3d67aa7f>Co-Founder &amp; CEO</p><p class=\"token-p\" data-v-3d67aa7f>California</p></div><div class=\"col right-side\" data-v-3d67aa7f><a href=\"https://assuredefi.com/projects/fx1/\" target=\"_blank\" data-v-3d67aa7f><img"+(_vm._ssrAttr("src",__webpack_require__(652)))+" alt=\"Trent Team Member\" data-v-3d67aa7f></a><h2 data-v-3d67aa7f>Trent</h2><div class=\"top-margin-a\" data-v-3d67aa7f></div><p class=\"token-p\" data-v-3d67aa7f>Co-Founder &amp; CEO</p><p class=\"token-p\" data-v-3d67aa7f>California</p></div></div></div>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Token/TeamSection.vue?vue&type=template&id=3d67aa7f&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/TeamSection.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var TeamSectionvue_type_script_lang_js_ = ({
  name: 'TeamSection'
});
// CONCATENATED MODULE: ./components/molecules/Token/TeamSection.vue?vue&type=script&lang=js&
 /* harmony default export */ var Token_TeamSectionvue_type_script_lang_js_ = (TeamSectionvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/Token/TeamSection.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1244)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Token_TeamSectionvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "3d67aa7f",
  "c6f95448"
  
)

/* harmony default export */ var TeamSection = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 641:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/damien.75c75c0.png";

/***/ }),

/***/ 652:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/trent.e5a5579.png";

/***/ }),

/***/ 965:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1245);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("05350b00", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=95.js.map
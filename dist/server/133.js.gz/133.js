exports.ids = [133];
exports.modules = {

/***/ 1272:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Ambassador_vue_vue_type_style_index_0_id_574bc612_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(979);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Ambassador_vue_vue_type_style_index_0_id_574bc612_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Ambassador_vue_vue_type_style_index_0_id_574bc612_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Ambassador_vue_vue_type_style_index_0_id_574bc612_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Ambassador_vue_vue_type_style_index_0_id_574bc612_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1273:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xm-home-catalogs-ambassador[data-v-574bc612]{position:relative}.xm-home-catalogs-ambassador .emoji-icon[data-v-574bc612]{background-color:rgba(0,0,0,.8);border:1px solid hsla(0,0%,100%,.6);box-shadow:0 6px 20px rgba(0,0,0,.13);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);border-radius:15px;position:absolute}.xm-home-catalogs-ambassador .starstruck[data-v-574bc612]{top:7%;right:15%}.xm-home-catalogs-ambassador .number-msg[data-v-574bc612]{flex-flow:row;background:hsla(0,0%,100%,.6);border:1px solid hsla(0,0%,100%,.4);box-shadow:0 6px 20px rgba(0,0,0,.13);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);border-radius:6px;position:absolute;font-size:1.3rem;color:#08252c;font-weight:400}.xm-home-catalogs-ambassador .txt-number-1[data-v-574bc612]{top:2%;left:-6%;width:70px;height:43px}.xm-home-catalogs-ambassador .txt-number-2[data-v-574bc612]{top:41%;right:5%;width:103px;height:43px}.xm-home-catalogs-ambassador .members-block[data-v-574bc612]{position:absolute;bottom:-20%;left:-6%;display:flex;flex-direction:column;align-items:center;grid-gap:8px;gap:8px;width:-moz-max-content;width:max-content;padding:8px;background-color:hsla(0,0%,100%,.2);border:1px solid hsla(0,0%,100%,.4);box-shadow:0 6px 20px rgba(0,0,0,.13);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);border-radius:10px}.xm-home-catalogs-ambassador .members-block p[data-v-574bc612]{font-weight:500;font-size:12px;line-height:1.1;letter-spacing:-.28px}.xm-home-catalogs-ambassador .members-block .avatars[data-v-574bc612]{display:flex}.xm-home-catalogs-ambassador .members-block .avatars[data-v-574bc612]>:not(:first-child){margin-left:-20px}.xm-home-catalogs-ambassador img[data-v-574bc612]{display:block}@media screen and (max-width:1439px){.xm-home-catalogs-ambassador .bg-img[data-v-574bc612]{width:346px;height:258px}.xm-home-catalogs-ambassador .txt-number-1[data-v-574bc612]{width:64px;height:40px}.xm-home-catalogs-ambassador .txt-number-2[data-v-574bc612]{width:95px;height:40px;right:19%}.xm-home-catalogs-ambassador .starstruck[data-v-574bc612]{top:6%;right:24%}.xm-home-catalogs-ambassador .starstruck .stars-emoji[data-v-574bc612]{width:61px;height:61px}.xm-home-catalogs-ambassador .members-block[data-v-574bc612]{width:158px;height:83px}.xm-home-catalogs-ambassador .members-block .avatar-img[data-v-574bc612]{width:44px;height:44px}}@media screen and (max-width:1215px){.xm-home-catalogs-ambassador .starstruck[data-v-574bc612]{right:3%}.xm-home-catalogs-ambassador .txt-number-2[data-v-574bc612]{right:-3%}}@media screen and (max-width:1023px){.xm-home-catalogs-ambassador[data-v-574bc612]{width:317px}.xm-home-catalogs-ambassador .bg-img[data-v-574bc612]{width:283px;height:265px}.xm-home-catalogs-ambassador .txt-number-1[data-v-574bc612]{width:52px;height:32px;top:-7%;left:5%}.xm-home-catalogs-ambassador .txt-number-2[data-v-574bc612]{width:78px;height:32px;right:1%;top:28%}.xm-home-catalogs-ambassador .starstruck[data-v-574bc612]{top:6%;right:15%}.xm-home-catalogs-ambassador .starstruck .stars-emoji[data-v-574bc612]{width:46px;height:46px}.xm-home-catalogs-ambassador .members-block[data-v-574bc612]{width:132px;height:62px;padding:4px;grid-gap:4px;gap:4px;bottom:-11%;left:5%}.xm-home-catalogs-ambassador .members-block p[data-v-574bc612]{font-size:10px}.xm-home-catalogs-ambassador .members-block .avatar-img[data-v-574bc612]{width:36px;height:36px}.xm-home-catalogs-ambassador .number-msg[data-v-574bc612]{font-size:1rem}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1425:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/v2/Home/Catalogs/Ambassador.vue?vue&type=template&id=574bc612&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xm-home-catalogs-ambassador"},[_c('nuxt-img',{staticClass:"bg-img",attrs:{"src":"/v2/Home/ambassador/baseball-match.png","width":"375","height":"280","format":"webp"}}),_vm._ssrNode("<div class=\"row items-center justify-center number-msg txt-number-1\" data-v-574bc612>"+_vm._ssrEscape(_vm._s(_vm.number_1))+"</div><div class=\"row items-center justify-center number-msg txt-number-2\" data-v-574bc612>"+_vm._ssrEscape(_vm._s(_vm.number_2))+"</div>"),_vm._ssrNode("<div class=\"emoji-icon starstruck\" data-v-574bc612>","</div>",[_c('nuxt-img',{staticClass:"stars-emoji",attrs:{"src":"/v2/Home/star-struck.svg","width":"61","height":"61","format":"webp"}})],1),_vm._ssrNode("<div class=\"members-block\" data-v-574bc612>","</div>",[_vm._ssrNode("<p data-v-574bc612>"+_vm._ssrEscape(_vm._s(_vm.membersCount)+" members")+"</p>"),_vm._ssrNode("<div class=\"avatars\" data-v-574bc612>","</div>",_vm._l((_vm.avatarUrls),function(url,index){return _c('nuxt-img',{key:index,staticClass:"avatar-img",attrs:{"src":url,"width":"48","height":"48","format":"webp"}})}),1)],2)],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/v2/Home/Catalogs/Ambassador.vue?vue&type=template&id=574bc612&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/v2/Home/Catalogs/Ambassador.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Ambassadorvue_type_script_lang_js_ = ({
  name: 'XMHomeCatalogsAmbassador',
  data() {
    return {
      membersCount: 736,
      number_1: 4.73,
      number_2: ' 103/100',
      avatarUrls: ['/v2/Home/ambassador/person-1.png', '/v2/Home/ambassador/person-2.png', '/v2/Home/ambassador/person-3.png', '/v2/Home/ambassador/person-4.png', '/v2/Home/ambassador/person-5.png']
    };
  }
});
// CONCATENATED MODULE: ./components/molecules/v2/Home/Catalogs/Ambassador.vue?vue&type=script&lang=js&
 /* harmony default export */ var Catalogs_Ambassadorvue_type_script_lang_js_ = (Ambassadorvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/v2/Home/Catalogs/Ambassador.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1272)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Catalogs_Ambassadorvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "574bc612",
  "86cd6026"
  
)

/* harmony default export */ var Ambassador = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 979:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1273);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("73e0e677", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=133.js.map
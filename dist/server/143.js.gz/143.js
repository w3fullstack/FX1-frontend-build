exports.ids = [143];
exports.modules = {

/***/ 1075:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_CreateNewPassword_vue_vue_type_style_index_0_id_64f05dbe_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(881);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_CreateNewPassword_vue_vue_type_style_index_0_id_64f05dbe_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_CreateNewPassword_vue_vue_type_style_index_0_id_64f05dbe_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_CreateNewPassword_vue_vue_type_style_index_0_id_64f05dbe_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_CreateNewPassword_vue_vue_type_style_index_0_id_64f05dbe_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1076:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, "@media screen and (max-width:1023px){.xp-create-new-password[data-v-64f05dbe] .step-content .left-content{min-height:calc(100vh - 60px)!important;align-items:flex-start}}.xp-create-new-password[data-v-64f05dbe] .step-content .left-content .form-container form .actions .button{width:230px}@media screen and (max-width:767px){.xp-create-new-password[data-v-64f05dbe] .step-content .left-content .form-container form .actions .button{width:100%}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1344:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/CreateNewPassword.vue?vue&type=template&id=64f05dbe&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xp-create-new-password auth-page"},[_vm._ssrNode("<div class=\"step-content row\" data-v-64f05dbe>","</div>",[_vm._ssrNode("<div class=\"left-content row items-center justify-center\" data-v-64f05dbe>","</div>",[_vm._ssrNode("<div class=\"form-container\" data-v-64f05dbe>","</div>",[_vm._ssrNode("<div class=\"form-header\" data-v-64f05dbe><h1 data-v-64f05dbe>Create new password</h1></div>"),_vm._ssrNode("<form action=\"#\" autocomplete=\"off\" data-v-64f05dbe>","</form>",[_vm._ssrNode("<div class=\"mb-5\" data-v-64f05dbe>","</div>",[_c('XAFormsInput',{attrs:{"type":"password","placeholder":"New password","disabled":_vm.isSubmitting,"error":_vm.validation.firstError('password')},model:{value:(_vm.password),callback:function ($$v) {_vm.password=$$v},expression:"password"}})],1),_vm._ssrNode("<div class=\"mb-6\" data-v-64f05dbe>","</div>",[_c('XAFormsInput',{attrs:{"type":"password","placeholder":"Confirm new password","disabled":_vm.isSubmitting,"error":_vm.validation.firstError('passwordConfirmation')},model:{value:(_vm.passwordConfirmation),callback:function ($$v) {_vm.passwordConfirmation=$$v},expression:"passwordConfirmation"}})],1),_vm._ssrNode("<div class=\"actions\" data-v-64f05dbe>","</div>",[_c('b-button',{staticClass:"btn-next",attrs:{"type":"is-primary","loading":_vm.isSubmitting,"disabled":_vm.isDisableSaveButton},on:{"click":function($event){$event.preventDefault();return _vm.fnSetNewPassword()}}},[_vm._v("Save")])],1)])],2)]),_c('XMSignUpRightContent')],1)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/pages/CreateNewPassword.vue?vue&type=template&id=64f05dbe&scoped=true&lang=pug&

// EXTERNAL MODULE: external "vuex"
var external_vuex_ = __webpack_require__(4);

// EXTERNAL MODULE: external "simple-vue-validator"
var external_simple_vue_validator_ = __webpack_require__(37);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/CreateNewPassword.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ var CreateNewPasswordvue_type_script_lang_js_ = ({
  validators: {
    password(value) {
      return external_simple_vue_validator_["Validator"].value(value).required('Password field is required').custom(() => {
        if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~])[A-Za-z\d!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~]{8,}$/.test(value)) {
          return 'Please ensure your password is at least 8 characters in length, and contains one number, upper and lowercase letters and one special character';
        }
      });
    },
    'passwordConfirmation, password'(passwordConfirmation, password) {
      return external_simple_vue_validator_["Validator"].value(passwordConfirmation).required('Password confirmation field is required').match(password, 'Please enter the same password in both fields');
    }
  },
  name: 'XPCreateNewPassword',
  components: {
    XMSignUpRightContent: () => __webpack_require__.e(/* import() */ 2).then(__webpack_require__.bind(null, 1374)),
    XAFormsInput: () => __webpack_require__.e(/* import() */ 0).then(__webpack_require__.bind(null, 991))
  },
  data() {
    return {
      password: null,
      passwordConfirmation: null,
      isSubmitting: false
    };
  },
  computed: {
    isDisableSaveButton() {
      return !this.password || !this.passwordConfirmation;
    }
  },
  methods: {
    ...Object(external_vuex_["mapActions"])({
      checkActionCode: 'auth/checkActionCode',
      resetPassword: 'auth/resetPassword'
    }),
    fnSetNewPassword() {
      this.isSubmitting = true;
      this.$validate().then(async success => {
        if (success) {
          try {
            var _this$$route$query;
            const actionCode = (_this$$route$query = this.$route.query) === null || _this$$route$query === void 0 ? void 0 : _this$$route$query.c;
            const result = await this.checkActionCode({
              actionCode
            });
            if (result) {
              try {
                const {
                  password
                } = this;
                await this.resetPassword({
                  actionCode,
                  password
                });
                const message = 'Password changed. Please login with new password';
                const duration = 5000;
                await this.fnSuccessToast(message, duration);
                this.$router.push({
                  path: '/signin'
                });
              } catch (error) {
                var _error$response;
                error === null || error === void 0 ? void 0 : (_error$response = error.response) === null || _error$response === void 0 ? void 0 : _error$response.errors.forEach(error => {
                  this.$toast.success(error.message, {
                    duration: 5000,
                    position: 'bottom-left',
                    className: 'fx1-success',
                    iconPack: 'mdi',
                    icon: 'alert-circle-outline'
                  });
                });
              }
            }
          } catch (e) {
            const message = e.toString();
            const findError = error => {
              if (message.includes(error)) {
                return message;
              }
            };
            switch (message) {
              case findError('invalid-action-code'):
                this.$toast.error('The action code is invalid. This can happen if the code is malformed, expired, or has already been used.', {
                  duration: 5000,
                  position: 'top-center'
                });
                break;
              default:
                break;
            }
          } finally {
            this.isSubmitting = false;
          }
          return;
        }
        this.isSubmitting = false;
      });
    }
  }
});
// CONCATENATED MODULE: ./components/pages/CreateNewPassword.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_CreateNewPasswordvue_type_script_lang_js_ = (CreateNewPasswordvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/pages/CreateNewPassword.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1075)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pages_CreateNewPasswordvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "64f05dbe",
  "4991532d"
  
)

/* harmony default export */ var CreateNewPassword = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 881:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1076);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("25410b14", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=143.js.map
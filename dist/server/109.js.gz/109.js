exports.ids = [109];
exports.modules = {

/***/ 1210:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_style_index_0_id_7f7d3e0a_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(948);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_style_index_0_id_7f7d3e0a_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_style_index_0_id_7f7d3e0a_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_style_index_0_id_7f7d3e0a_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_style_index_0_id_7f7d3e0a_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1211:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(24);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(480);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xo-home-banner[data-v-7f7d3e0a]{height:1144px;overflow:hidden;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");background-repeat:no-repeat;background-position:top}.xo-home-banner .banner-content[data-v-7f7d3e0a]{padding-top:204px}.xo-home-banner .banner-content .banner-txt[data-v-7f7d3e0a]{max-width:673px}.xo-home-banner .banner-content .banner-txt p.txt-intro[data-v-7f7d3e0a]{padding:28px 0;margin:0 auto;max-width:521px;opacity:.6}.xo-home-banner .banner-content .actions[data-v-7f7d3e0a]{margin:12px auto!important}.xo-home-banner .banner-content .actions .button[data-v-7f7d3e0a]{width:251px!important;height:76px!important;margin-right:unset!important;margin-left:unset!important;font-size:20px;line-height:28px;text-transform:uppercase;border-radius:10px;box-shadow:0 1.06592px 2.80384px 0 rgba(248,84,84,.08),0 2.47835px 6.51914px 0 rgba(248,84,84,.12),0 4.45054px 11.70687px 0 rgba(248,84,84,.15),0 7.38625px 19.42906px 0 rgba(248,84,84,.17),0 12.1686px 32.00872px 0 rgba(248,84,84,.2),0 21.26719px 55.94197px 0 rgba(248,84,84,.24),0 46px 121px 0 rgba(248,84,84,.32)}@media screen and (max-width:1439px){.xo-home-banner .banner-content .banner-txt[data-v-7f7d3e0a]{max-width:512px}.xo-home-banner .banner-content .banner-txt p.txt-title[data-v-7f7d3e0a]{font-size:3.428rem;letter-spacing:.96px;line-height:normal}.xo-home-banner .banner-content .actions[data-v-7f7d3e0a]{margin:8px auto!important}.xo-home-banner .banner-content .actions .button[data-v-7f7d3e0a]{height:66px!important;font-size:18px}}@media screen and (max-width:767px){.xo-home-banner[data-v-7f7d3e0a]{background-size:1200px}.xo-home-banner .banner-content .banner-txt[data-v-7f7d3e0a]{max-width:345px}.xo-home-banner .banner-content .banner-txt p.txt-title[data-v-7f7d3e0a]{font-size:41px;letter-spacing:.82px;line-height:normal}.xo-home-banner .banner-content .banner-txt p.txt-intro[data-v-7f7d3e0a]{padding:16px 0}.xo-home-banner .banner-content .actions[data-v-7f7d3e0a]{margin:20px auto!important}.xo-home-banner .banner-content .actions .button[data-v-7f7d3e0a]{height:46px!important;width:205px!important;font-size:14px}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1386:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/v2/Home/Banner.vue?vue&type=template&id=7f7d3e0a&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xo-home-banner row"},[_vm._ssrNode("<div class=\"container is-max-widescreen row items-top justify-center\" data-v-7f7d3e0a>","</div>",[_vm._ssrNode("<div class=\"banner-content\" data-v-7f7d3e0a>","</div>",[_vm._ssrNode("<div class=\"banner-txt\" data-v-7f7d3e0a><p class=\"txt-title text-center text-weight-medium\" data-v-7f7d3e0a> Supercharged AI\nSports Betting</p><p class=\"txt-intro text-center text-weight-regular\" data-v-7f7d3e0a>FX1 is a peer-to-peer sports betting exchange that uses data and AI to help you win more bets. Set your own odds, compete against your friends, and gain back control with our advanced insights and time-based subscription tools.</p></div>"),_vm._ssrNode("<div class=\"actions row justify-center\" data-v-7f7d3e0a>","</div>",[_c('b-button',{staticClass:"items-center justify-center text-weight-medium",attrs:{"type":"is-primary","tag":"router-link","to":"/signup?step=1"}},[_vm._v("Create Account")])],1)],2)])])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/v2/Home/Banner.vue?vue&type=template&id=7f7d3e0a&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/v2/Home/Banner.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Bannervue_type_script_lang_js_ = ({
  name: 'XOHomeBanner'
});
// CONCATENATED MODULE: ./components/organisms/v2/Home/Banner.vue?vue&type=script&lang=js&
 /* harmony default export */ var Home_Bannervue_type_script_lang_js_ = (Bannervue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/organisms/v2/Home/Banner.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1210)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Home_Bannervue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "7f7d3e0a",
  "680cb6e4"
  
)

/* harmony default export */ var Banner = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 480:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/circles-and-light.8a6707c.svg";

/***/ }),

/***/ 948:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1211);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("d832a96e", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=109.js.map
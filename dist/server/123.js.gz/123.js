exports.ids = [123];
exports.modules = {

/***/ 1190:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatMedias_vue_vue_type_style_index_0_id_555616c5_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(938);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatMedias_vue_vue_type_style_index_0_id_555616c5_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatMedias_vue_vue_type_style_index_0_id_555616c5_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatMedias_vue_vue_type_style_index_0_id_555616c5_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatMedias_vue_vue_type_style_index_0_id_555616c5_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1191:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xm-channels-chat-medias[data-v-555616c5]{margin:0 -16px 10px}@media screen and (max-width:767px){.xm-channels-chat-medias[data-v-555616c5]{margin:0 -13px 10px}}.xm-channels-chat-medias[data-v-555616c5] .media-container{width:100%;height:auto;position:relative;overflow:hidden}@media screen and (max-width:767px){.xm-channels-chat-medias[data-v-555616c5] .media-container{height:225px}}@media screen and (max-width:480px){.xm-channels-chat-medias[data-v-555616c5] .media-container{height:200px}}.xm-channels-chat-medias[data-v-555616c5] .media-container .count{background-color:rgba(0,0,0,.6);position:absolute;top:0;left:0;width:100%;height:100%;z-index:1;font-size:2.2857rem;cursor:pointer;border-bottom-right-radius:8px}.xm-channels-chat-medias[data-v-555616c5].media-2{justify-content:space-between}.xm-channels-chat-medias[data-v-555616c5].media-2 .media-container{width:calc(50% - 2px)}@media screen and (max-width:767px){.xm-channels-chat-medias[data-v-555616c5].media-2 .media-container{width:calc(50% - 1px)}}.xm-channels-chat-medias[data-v-555616c5].media-multiple{display:block}.xm-channels-chat-medias[data-v-555616c5].media-multiple .media-container{width:calc(55% - 2px);float:left}@media screen and (max-width:767px){.xm-channels-chat-medias[data-v-555616c5].media-multiple .media-container{width:calc(55% - 1px)}}.xm-channels-chat-medias[data-v-555616c5].media-multiple .media-container:not(:first-child){height:155.5px;float:right;width:calc(45% - 2px)}@media screen and (max-width:767px){.xm-channels-chat-medias[data-v-555616c5].media-multiple .media-container:not(:first-child){height:111.5px;width:calc(45% - 1px)}}@media screen and (max-width:480px){.xm-channels-chat-medias[data-v-555616c5].media-multiple .media-container:not(:first-child){height:99px}}.xm-channels-chat-medias[data-v-555616c5].media-multiple .media-container:last-child{margin-top:4px}@media screen and (max-width:767px){.xm-channels-chat-medias[data-v-555616c5].media-multiple .media-container:last-child{margin-top:2px}}.xm-channels-chat-medias[data-v-555616c5].media-multiple:after{content:\"\";clear:both;display:block}.xm-channels-chat-medias[data-v-555616c5].no-text{margin-bottom:0}.xm-channels-chat-medias[data-v-555616c5].no-text .media-container:first-child .xa-channels-chat-item-image img{border-bottom-left-radius:8px}.xm-channels-chat-medias[data-v-555616c5].no-text .media-container:last-child .xa-channels-chat-item-image img{border-bottom-right-radius:8px}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1435:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Channels/ChatMedias.vue?vue&type=template&id=555616c5&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return (_vm.medias)?_c('div',{staticClass:"xm-channels-chat-medias row",class:_vm.mediaClasses},_vm._l((_vm.medias.slice(0, 3)),function(media,index){return _vm._ssrNode("<div class=\"media-container\" data-v-555616c5>","</div>",[(media.objectType === 'Photo' || media['type'].includes('image'))?_c('XAChannelsChatItemImage',{attrs:{"media":media,"index":index,"scroll-to-bottom":_vm.scrollToBottom},on:{"click":function($event){return _vm.fnShowLightbox(index)}}}):_vm._e(),_vm._ssrNode(((index === 2 && _vm.countExcludedMedias > 0)?("<div class=\"count row items-center justify-center\" data-v-555616c5>"+_vm._ssrEscape("+"+_vm._s(_vm.countExcludedMedias))+"</div>"):"<!---->"))],2)}),0):_vm._e()}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Channels/ChatMedias.vue?vue&type=template&id=555616c5&scoped=true&lang=pug&

// EXTERNAL MODULE: external "vuex"
var external_vuex_ = __webpack_require__(4);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Channels/ChatMedias.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var ChatMediasvue_type_script_lang_js_ = ({
  name: 'XMChannelsChatMedias',
  components: {
    XAChannelsChatItemImage: () => __webpack_require__.e(/* import() */ 115).then(__webpack_require__.bind(null, 1439))
  },
  props: {
    medias: {
      type: Array,
      default: () => []
    },
    showChatOptions: {
      type: Boolean,
      default: false
    },
    scrollToBottom: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      lightboxMedias: []
    };
  },
  computed: {
    mediaClasses() {
      const mediaLength = this.medias.length;
      switch (mediaLength) {
        case 0:
          return '';
        case 1:
          return 'media-1';
        case 2:
          return 'media-2';
        default:
          return 'media-multiple';
      }
    },
    countExcludedMedias() {
      const countExcludedMedias = this.medias.slice(3);
      return countExcludedMedias.length;
    }
  },
  methods: {
    ...Object(external_vuex_["mapActions"])({
      setMediaLightbox: 'media/setMediaLightbox'
    }),
    async fnShowLightbox(index) {
      if (this.showChatOptions) return;
      await this.fnRetrieveLargerImage();
      await this.setMediaLightbox(this.lightboxMedias);
      this.$root.$emit('evtRtShowLightbox', {
        show: true,
        initialSlide: index
      });
    },
    async fnRetrieveLargerImage() {
      const medias = this.medias || [];
      const mappedMedias = medias.map(x => {
        return {
          objectID: x === null || x === void 0 ? void 0 : x.objectID,
          objectType: x === null || x === void 0 ? void 0 : x.objectType,
          isSport: false,
          type: '1024'
        };
      });
      try {
        const {
          getPhotoURLs
        } = await this.$api.getPhotoURLs({
          input: mappedMedias
        });
        this.lightboxMedias = getPhotoURLs.map(x => {
          return {
            src: x,
            type: 'Photo'
          };
        });
      } catch (error) {}
    },
    fnHideLightbox() {
      this.$root.$emit('evtRtShowLightbox', {
        show: false,
        initialSlide: 0
      });
    }
  }
});
// CONCATENATED MODULE: ./components/molecules/Channels/ChatMedias.vue?vue&type=script&lang=js&
 /* harmony default export */ var Channels_ChatMediasvue_type_script_lang_js_ = (ChatMediasvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/Channels/ChatMedias.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1190)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Channels_ChatMediasvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "555616c5",
  "389c650a"
  
)

/* harmony default export */ var ChatMedias = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 938:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1191);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("328e8994", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=123.js.map
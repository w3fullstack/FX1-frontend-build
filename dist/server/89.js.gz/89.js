exports.ids = [89];
exports.modules = {

/***/ 1170:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ForWho_vue_vue_type_style_index_0_id_ae2bfac2_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(928);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ForWho_vue_vue_type_style_index_0_id_ae2bfac2_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ForWho_vue_vue_type_style_index_0_id_ae2bfac2_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ForWho_vue_vue_type_style_index_0_id_ae2bfac2_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ForWho_vue_vue_type_style_index_0_id_ae2bfac2_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1171:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".for-who-section[data-v-ae2bfac2]{width:100%;position:relative;overflow:hidden;padding:150px 0 0;z-index:2}@media screen and (max-width:1025px){.for-who-section[data-v-ae2bfac2]{padding:120px 0 0}}.for-who-section[data-v-ae2bfac2] .top-margin-a{margin-top:110px}@media screen and (max-width:1025px){.for-who-section[data-v-ae2bfac2] .top-margin-a{margin-top:85px}}.for-who-section[data-v-ae2bfac2] .top-margin-b{margin-top:70px}.for-who-section[data-v-ae2bfac2] h2{font-size:60px;font-weight:500}@media screen and (max-width:1021px){.for-who-section[data-v-ae2bfac2] h2{font-size:36px;line-height:40px;font-weight:700}}@media screen and (max-width:500px){.for-who-section[data-v-ae2bfac2] h2{font-size:28px;line-height:31px;text-align:left}}.for-who-section[data-v-ae2bfac2] .content-container{margin-right:-30px}@media screen and (max-width:1025px){.for-who-section[data-v-ae2bfac2] .content-container{margin-right:-25px;justify-content:center}}@media screen and (max-width:500px){.for-who-section[data-v-ae2bfac2] .content-container{margin-right:0}}.for-who-section[data-v-ae2bfac2] .content-container .item{background:transparent;margin-bottom:30px;margin-right:30px;flex-basis:calc(33.33333% - 30px)}@media screen and (max-width:1025px){.for-who-section[data-v-ae2bfac2] .content-container .item{flex-basis:calc(50% - 25px);margin-right:25px}}@media screen and (max-width:500px){.for-who-section[data-v-ae2bfac2] .content-container .item{flex-basis:100%;margin-bottom:60px;margin-right:0}}.for-who-section[data-v-ae2bfac2] .content-container .svg-icon{max-width:30%;margin-right:10px}@media screen and (max-width:500px){.for-who-section[data-v-ae2bfac2] .content-container .svg-icon{width:80px;height:80px}}.for-who-section[data-v-ae2bfac2] .content-container .token-p{max-width:65%;font-size:24px}@media screen and (max-width:500px){.for-who-section[data-v-ae2bfac2] .content-container .token-p{font-size:18px!important;line-height:28px!important;font-weight:300}}@media screen and (max-width:500px){.for-who-section[data-v-ae2bfac2]{padding:0 0 50px}.for-who-section[data-v-ae2bfac2] .top-margin-b{margin-top:0!important}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1370:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/BossMembership/ForWho.vue?vue&type=template&id=ae2bfac2&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"for-who-section row"},[_vm._ssrNode("<div class=\"container token-container\" data-v-ae2bfac2><div class=\"row\" data-v-ae2bfac2><div class=\"col\" data-v-ae2bfac2><h2 class=\"text-center\" data-v-ae2bfac2>Who is it for?</h2><div class=\"top-margin-a\" data-v-ae2bfac2></div><div class=\"row content-container\" data-v-ae2bfac2><div class=\"item\" data-v-ae2bfac2><div class=\"row items-center\" data-v-ae2bfac2><div class=\"svg-icon\" data-v-ae2bfac2><img"+(_vm._ssrAttr("src",__webpack_require__(607)))+" data-v-ae2bfac2></div><p class=\"token-p\" data-v-ae2bfac2>Anyone that cares about the problem we’re solving</p></div></div><div class=\"item\" data-v-ae2bfac2><div class=\"row items-center\" data-v-ae2bfac2><div class=\"svg-icon\" data-v-ae2bfac2><img"+(_vm._ssrAttr("src",__webpack_require__(602)))+" data-v-ae2bfac2></div><p class=\"token-p\" data-v-ae2bfac2>Those that want to be part of an exclusive club</p></div></div><div class=\"item\" data-v-ae2bfac2><div class=\"row items-center\" data-v-ae2bfac2><div class=\"svg-icon\" data-v-ae2bfac2><img"+(_vm._ssrAttr("src",__webpack_require__(603)))+" data-v-ae2bfac2></div><p class=\"token-p\" data-v-ae2bfac2>Fans that want early access to future NFT drops</p></div></div></div></div></div></div>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/BossMembership/ForWho.vue?vue&type=template&id=ae2bfac2&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/BossMembership/ForWho.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var ForWhovue_type_script_lang_js_ = ({
  name: 'ForWho'
});
// CONCATENATED MODULE: ./components/molecules/BossMembership/ForWho.vue?vue&type=script&lang=js&
 /* harmony default export */ var BossMembership_ForWhovue_type_script_lang_js_ = (ForWhovue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/BossMembership/ForWho.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1170)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  BossMembership_ForWhovue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "ae2bfac2",
  "0e6602c5"
  
)

/* harmony default export */ var ForWho = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 602:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/exclusive-club.a52f30e.svg";

/***/ }),

/***/ 603:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/fans-future-drops.a46fcc5.svg";

/***/ }),

/***/ 607:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/problems-solving.489e12c.svg";

/***/ }),

/***/ 928:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1171);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("0a4cdd39", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=89.js.map
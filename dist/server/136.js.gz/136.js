exports.ids = [136];
exports.modules = {

/***/ 1220:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Chat_vue_vue_type_style_index_0_id_159af441_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(953);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Chat_vue_vue_type_style_index_0_id_159af441_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Chat_vue_vue_type_style_index_0_id_159af441_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Chat_vue_vue_type_style_index_0_id_159af441_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Chat_vue_vue_type_style_index_0_id_159af441_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1221:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xo-explore-event-chat[data-v-159af441]{position:fixed;font-family:\"Rotunda\";width:357px;height:100%;bottom:0;z-index:11;background:#0c353e;border-left:1px solid #385960}@media screen and (max-width:767px){.xo-explore-event-chat[data-v-159af441]{width:100%;padding:0!important}.xo-explore-event-chat[data-v-159af441] .send-message-box{width:100%}}.xo-explore-event-chat[data-v-159af441] .chat-body{overflow-y:scroll;-ms-overflow-style:none;scrollbar-width:none}.xo-explore-event-chat[data-v-159af441] .chat-body::-webkit-scrollbar{display:none}.xo-explore-event-chat[data-v-159af441] .vuebar{height:calc(100% - 66.6px)!important}@media screen and (max-width:427px){.xo-explore-event-chat[data-v-159af441] .vuebar{height:calc(100% - 154px)!important}}.xo-explore-event-chat[data-v-159af441] .vuebar-private{height:calc(100% - 132px)!important}@media screen and (max-width:427px){.xo-explore-event-chat[data-v-159af441] .vuebar-private{height:calc(100% - 219px)!important}}.xo-explore-event-chat[data-v-159af441] .vuebar-private-creation{height:calc(100% - 66.6px)!important}.xo-explore-event-chat[data-v-159af441] .send-message-box{padding:0;grid-gap:12px;gap:12px;position:absolute;width:357px;left:0;bottom:0;background:#0c353e;border-top:1px solid rgba(231,232,232,.2)}.xo-explore-event-chat[data-v-159af441] .send-message-box .add-icon{display:inline-block;margin-top:5px}.xo-explore-event-chat[data-v-159af441] .send-message-box .message-input-field{display:inline-block;position:absolute}.xo-explore-event-chat[data-v-159af441] .send-message-box .message-input-field input{border:none!important;background:none;color:#94a6aa!important;width:100%;height:20px}.xo-explore-event-chat[data-v-159af441] .send-message-box .message-input-field input::-webkit-input-placeholder{font-style:normal;font-weight:600;font-size:15px;line-height:20px;color:#94a6aa}.xo-explore-event-chat[data-v-159af441] .send-message-box .btn-actions{float:right;margin-top:17px;margin-right:17px}.xo-explore-event-chat[data-v-159af441] .send-message-box .btn-actions .send-btn{display:inline-block;margin-right:21px;cursor:pointer}.xo-explore-event-chat[data-v-159af441] .send-message-box .btn-actions .camera{display:inline-block;cursor:pointer}.show[data-v-159af441]{right:0!important}.hide[data-v-159af441],.show[data-v-159af441]{transition:.5s}.hide[data-v-159af441]{right:-375px}@media screen and (max-width:767px){.hide[data-v-159af441]{height:0;right:0;transition:.5s;overflow:hidden}.hide .send-message-box[data-v-159af441]{display:none}.show[data-v-159af441]{max-height:550px;transition:.5s}.show .send-message-box[data-v-159af441]{display:block}.full-screen[data-v-159af441]{position:absolute;bottom:0;max-height:unset}.add-icon[data-v-159af441]{width:10%!important}.message-input-field[data-v-159af441]{width:75%!important}.message-input-field .field .control input[type=text][data-v-159af441]{width:100%!important}.btn-actions[data-v-159af441]{width:15%;text-align:right}}@media screen and (max-width:500px){.send-message-box .add-icon[data-v-159af441]{width:13%!important}.send-message-box .message-input-field[data-v-159af441]{width:65%!important}.send-message-box .btn-actions[data-v-159af441]{width:25%;text-align:right}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1391:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/ExploreEvent/Chat.vue?vue&type=template&id=159af441&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xo-explore-event-chat",class:[_vm.showModal ? 'show' : 'hide', { 'full-screen': _vm.activeChat === 'private' && !_vm.privateChannel }]},[_c('XOChatNavigation',{attrs:{"showModal":_vm.showModal,"currentStep":_vm.currentStep,"totalSteps":_vm.totalSteps,"activeChat":_vm.activeChat,"game":_vm.game,"privateChannel":_vm.privateChannel,"lockerRoom":_vm.lockerRoom},on:{"hide":function($event){return _vm.$emit('hide')},"switchChat":_vm.switchChat,"setPrivateChannel":_vm.setPrivateChannel}}),_vm._ssrNode("<div"+(_vm._ssrClass("chat-body vuebar",[_vm.activeChat === 'private' && (_vm.privateChannel ? 'vuebar-private' : 'vuebar-private-creation')]))+" style=\"padding: 0px !important\" data-v-159af441>","</div>",[_c('XOChatBody',{directives:[{name:"show",rawName:"v-show",value:(_vm.mode === 'chat'),expression:"mode === 'chat'"}],class:{ 'private-room': _vm.activeChat === 'private' || _vm.activeChat === 'public' },attrs:{"channelSlug":_vm.channelSlug,"game":_vm.game,"activeChat":_vm.activeChat,"currentStep":_vm.currentStep,"privateChannel":_vm.privateChannel,"lockerRoomProp":_vm.lockerRoom},on:{"cancel":function($event){return _vm.$emit('hide')},"changeStep":_vm.changeStep,"setPrivateChannel":_vm.setPrivateChannel}}),(_vm.videoTabMounted && _vm.activeChat === 'private' && _vm.privateChannel)?_c('XOVideoBody',{directives:[{name:"show",rawName:"v-show",value:(_vm.mode === 'video'),expression:"mode === 'video'"}],attrs:{"privateChannel":_vm.privateChannel}}):_vm._e()],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/ExploreEvent/Chat.vue?vue&type=template&id=159af441&scoped=true&lang=pug&

// EXTERNAL MODULE: external "vuex-map-fields"
var external_vuex_map_fields_ = __webpack_require__(2);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/ExploreEvent/Chat.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var Chatvue_type_script_lang_js_ = ({
  name: 'XOExploreChat',
  components: {
    XOExploreChatMember: () => __webpack_require__.e(/* import() */ 139).then(__webpack_require__.bind(null, 1426)),
    XOChatNavigation: () => __webpack_require__.e(/* import() */ 67).then(__webpack_require__.bind(null, 1310)),
    XOChatBody: () => __webpack_require__.e(/* import() */ 137).then(__webpack_require__.bind(null, 1427)),
    XOVideoBody: () => __webpack_require__.e(/* import() */ 79).then(__webpack_require__.bind(null, 1307))
  },
  props: {
    showModal: {
      type: Boolean
    },
    channelSlug: {
      type: String,
      default: ''
    },
    game: {
      type: Object,
      default: () => {}
    },
    activeChat: {
      type: String,
      default: ''
    },
    privateChannel: {
      type: Object,
      default: () => {}
    },
    lockerRoom: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      channel: 'public',
      currentStep: 1,
      totalSteps: 2,
      videoTabMounted: false
    };
  },
  computed: {
    ...Object(external_vuex_map_fields_["mapFields"])('chats', ['mode'])
  },
  watch: {
    activeChat(val) {
      if (val === 'public' && this.mode !== 'chat') {
        this.mode = 'chat';
      }
    },
    mode(val) {
      if (!this.videoTabMounted && val === 'video') {
        this.videoTabMounted = true;
      }
    }
  },
  methods: {
    switchChat(chat) {
      this.$emit('switchChat', chat);
    },
    changeStep(step) {
      this.currentStep = step;
    },
    setPrivateChannel(channel) {
      this.$emit('setPrivateChannel', channel);
    }
  }
});
// CONCATENATED MODULE: ./components/organisms/ExploreEvent/Chat.vue?vue&type=script&lang=js&
 /* harmony default export */ var ExploreEvent_Chatvue_type_script_lang_js_ = (Chatvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/organisms/ExploreEvent/Chat.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1220)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  ExploreEvent_Chatvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "159af441",
  "6a797438"
  
)

/* harmony default export */ var Chat = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 953:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1221);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("9450f594", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=136.js.map
exports.ids = [149];
exports.modules = {

/***/ 1115:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Terms_vue_vue_type_style_index_0_id_7504f518_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(901);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Terms_vue_vue_type_style_index_0_id_7504f518_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Terms_vue_vue_type_style_index_0_id_7504f518_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Terms_vue_vue_type_style_index_0_id_7504f518_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Terms_vue_vue_type_style_index_0_id_7504f518_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1116:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".page-content[data-v-7504f518]{min-height:calc(100vh - 406px);border-bottom:1px solid #1c3e45;background-color:#0c353e;padding:50px}.page-content[data-v-7504f518] a{color:#fff;text-decoration:underline}.page-content[data-v-7504f518] .bottom-border{border-bottom:2px solid #fff}.page-content[data-v-7504f518] h1{font-size:3rem;line-height:1.2;margin-bottom:30px;letter-spacing:0}.page-content[data-v-7504f518] h2{font-size:1.5714rem;font-weight:500;margin-bottom:.75rem}.page-content[data-v-7504f518] h3{font-size:1.5714rem;line-height:1.2;margin:40px 0 20px;border-bottom:1px solid #fff;padding-bottom:10px}.page-content[data-v-7504f518] p{font-size:1.1429rem;font-weight:300;margin-bottom:20px}.page-content[data-v-7504f518] ul{margin-bottom:20px}.page-content[data-v-7504f518] ul li{list-style-type:none;font-size:1.1429rem;font-weight:300;margin-bottom:20px}.page-content[data-v-7504f518] ul li ul{margin-top:20px;margin-left:20px;margin-bottom:0}.page-content[data-v-7504f518] ul li ul li{list-style-type:none}.page-content[data-v-7504f518] pre{display:block;padding:.7143rem;word-break:break-all;background-color:#f5f5f5;border:1px solid #ccc;border-radius:5px;font-size:12px;white-space:pre-line;margin-bottom:.7143rem}.page-content[data-v-7504f518] pre span{display:block}.page-content[data-v-7504f518] strong{color:#fff}.page-content[data-v-7504f518] .privacy-container{position:relative}.page-content[data-v-7504f518] .privacy-container #privacy{position:absolute;top:-110px}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1351:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/Terms.vue?vue&type=template&id=7504f518&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"page-content"},[_vm._ssrNode("<div class=\"container is-max-desktop\" data-v-7504f518>","</div>",[_vm._ssrNode("<h1 data-v-7504f518>Website Terms and Conditions</h1>"),_vm._ssrNode("<p data-v-7504f518>","</p>",[_vm._ssrNode("This website located at "),_c('nuxt-link',{attrs:{"to":"/"}},[_c('strong',[_vm._v("https://fx1.io/")])]),_vm._ssrNode(" <strong data-v-7504f518>(Website)</strong> is owned and operated by <strong data-v-7504f518>FX1 Pty Ltd</strong> ACN 637 528 851 <strong data-v-7504f518>(FX1)</strong>.")],2),_vm._ssrNode("<p data-v-7504f518>By using this Website and in consideration of <b data-v-7504f518>FX1</b> providing you with access to the Website, you confirm that these Terms and Conditions govern your access to and use of the Website and you accept and agree to comply with them.</p><p data-v-7504f518><b data-v-7504f518>FX1</b> recommends that you print a copy of these Terms and Conditions for future reference.</p><p data-v-7504f518><b data-v-7504f518>FX1</b> reserves the right to amend these Terms and Conditions from time to time. Every time you wish to use the Website, please check these Terms and Conditions to ensure you understand the terms and conditions that apply at that time.</p><h3 data-v-7504f518>1. Early Access Form</h3><ul data-v-7504f518><li data-v-7504f518>1.1 The Website has an online early access form, which you can submit to FX1 to register for future notifications from FX1.</li><li data-v-7504f518>1.2 By submitting the form, you warrant that:<ul data-v-7504f518><li data-v-7504f518>(a) you are over 18 years old; and</li><li data-v-7504f518>(b) the information submitted by you is true and correct.</li></ul></li><li data-v-7504f518>1.3 By submitting the form, you agree that FX1 may contact you (including via email) to:<ul data-v-7504f518><li data-v-7504f518>(a) provide updates regarding the development of the FX1 platform (the Platform) and app (the App);</li><li data-v-7504f518>(b) invite you to register a user account to the App and the Platform, which will be subject to separate terms and conditions; and</li><li data-v-7504f518>(c) provide and promote our services to you and the goods and services of our partners.</li></ul></li><li data-v-7504f518>1.4 In particular, if you indicate in the online form that you are a business, professionalathlete or anything other than a general user, we may contact you to discuss the\npotential for partnering with FX1 to provide content, goods or services via the App or the\nPlatform, and to seek your consent to listing your name, business name, brand or logo\non the Website as an FX1 partner. If you do provide your consent, you warrant that you\nare authorised by the business or brand-owner concerned to provide that consent and\nthat FX1’s use of the business name, brand or logo on the Website will not infringe the\nrights, including intellectual property rights, of any third party.</li><li data-v-7504f518>1.5 You can unsubscribe from our emails or manage your email preferences at any time byclicking the unsubscribe link which is available at the bottom of any marketing based\nemails you may receive.</li></ul><div class=\"privacy-container\" data-v-7504f518><h3 data-v-7504f518>2. Privacy Collection Statement</h3><div id=\"privacy\" data-v-7504f518></div></div><p data-v-7504f518>FX1 collects your personal information when you submit the online registration form on our Website.We collect this information to provide updates regarding the development of the Platform and App and\nprovide and promote our services to you and the goods and services of our partners. If you don't\nprovide any of the information requested, we may not be able to contact you and keep you informed.\nIn order to keep you informed, FX1 may disclose the personal information it collects to other entities in\nthe APP Group, our agents, contractors, and service providers (including our web and IT\nadministrators, mail houses and advisors). FX1 does not generally disclose personal information\noutside Australia. Please contact FX1 at hello@fx1.io to access or correct any personal information\nwe hold about you.</p><h3 data-v-7504f518>3. Intellectual Property</h3><ul data-v-7504f518><li data-v-7504f518>All material on the Website, including the text, code, information, graphics, illustrations,photographs, video, music, sound, trading names, service marks, logos, design, layout,\ndownloads, pricing, products and services (<b data-v-7504f518>Content</b>) is owned by or licensed to <b data-v-7504f518>FX1</b>.</li><li data-v-7504f518>3.2 You must not reproduce, transmit, adapt, distribute, sell, modify, publish or store Contentfor any purpose, other than with the prior written consent of <b data-v-7504f518>FX1</b> or as permitted by law.\nAll rights of <b data-v-7504f518>FX1</b> are reserved.</li><li data-v-7504f518>FX1 , the FX1 Logo and the FX1 logo are trade marks of <b data-v-7504f518>FX1</b>.</li><li data-v-7504f518>3.4 Trade marks used on the Website to describe third parties and their products are trademarks of those third parties and you are not permitted to use them without the consent of\nthose third parties.</li></ul><h3 data-v-7504f518>4. Links and Third Party Content</h3><ul data-v-7504f518><li data-v-7504f518>4.1 You must not link to, frame or mirror any part of the Website without FX1’s written authorisation.</li><li data-v-7504f518>4.2 The Website may contain links to or display the content of third parties (<b data-v-7504f518>Third PartyContent</b>), including links to websites operated by other organisations and individuals\n(<b data-v-7504f518>Third Party Websites</b>). Third Party Content and Third Party Websites are not under\nthe control of <b data-v-7504f518>FX1</b>. <b data-v-7504f518>FX1</b> does not endorse, approve or make any warranty or claim\nregarding Third Party Content, Third Party Websites or the products, services or\ninformation available on any Third Party Website, or in respect of the owner or operator\nof a Third Party Website or their conduct. If you use or rely upon Third Party Content or\nThird Party Websites, you do so solely at your own risk.</li></ul><h3 data-v-7504f518>5. Your conduct</h3><ul data-v-7504f518><li data-v-7504f518>5.1 You must not:</li><ul data-v-7504f518><li data-v-7504f518>(a) use the Website in breach of any applicable laws or regulations;</li><li data-v-7504f518>(b) use the Website to harm, abuse, harass, stalk, threaten or otherwise offend others;</li><li data-v-7504f518>(c) interfere with, disrupt, or create an undue burden on the Website;</li><li data-v-7504f518>(d) upload, post, transmit or otherwise make available any material that:<ul data-v-7504f518><li data-v-7504f518>(i) is not your original work, or which may infringe the intellectual property or other rights of another person;</li><li data-v-7504f518>(ii) is, or could reasonably be expected to be, defamatory, obscene, offensive,threatening, abusive, pornographic, vulgar, profane, indecent or otherwise\nunlawful, including material that racially or religiously vilifies, incites violence\nor hatred, or is likely to offend, insult or humiliate others based on race,\nreligion, ethnicity, gender, age, sexual orientation or any physical or mental\ndisability;</li><li data-v-7504f518>(iii) includes an image or personal information of another person unless you havetheir consent;</li><li data-v-7504f518>(iv) you know or suspect, or should reasonably know or suspect, to be false,misleading or deceptive;</li><li data-v-7504f518>(v) contains large amounts of untargeted, unwanted or repetitive content; or</li><li data-v-7504f518>(vi) contains financial, legal, medical or other professional advice.</li></ul></li><li data-v-7504f518>Without limiting the above, you will not and will not permit a third party to:</li><li data-v-7504f518>(e) misuse the Website by knowingly introducing viruses, trojans, worms, logic bombs orother material that is malicious or technically harmful. You must not attempt to gain\nunauthorised access to the Website, the server on which the Website is stored or any\nserver, computer or database connected to the Website. You must not attack the\nWebsite via a denial-of-service attack or a distributed denial-of service attack;</li><li data-v-7504f518>(f) use any method or process (including data scraping, web-bots, collection oraccumulation tool, robot, spider or scripted responses) for the purpose of obtaining,\nprocessing, copying, replicating, distributing, reconfiguring, republishing, viewing,\nassessing, analysing, modifying or repacking the Content;</li><li data-v-7504f518>(g) use, obtain, or attempt to obtain from the Website, information in order to identify or discover pricing, rating and related business methodology or systems; and</li><li data-v-7504f518>(h) do anything which will or may damage, disrupt access to or interfere with the proper operation of the Website.</li><li data-v-7504f518>If you believe that a user has breached any of the above conditions, please contact us <b data-v-7504f518><a href=\"mailto:info@FX1.com\" data-v-7504f518>info@FX1.com</a></b>.</li></ul></ul><h3 data-v-7504f518>6. User-generated Content</h3><ul data-v-7504f518><li data-v-7504f518>6.1 <b data-v-7504f518>FX1</b> reserves the right to block or suspend any user of its Website, and to modify orremove any material uploaded, posted, transmitted or otherwise made available on the\nWebsite by any user, without notice. <b data-v-7504f518>FX1</b> also has the right to disclose your identity to\nany third party who is claiming that any material posted or uploaded by you on the\nWebsite constitutes a violation of their intellectual property rights or of their right to\nprivacy.</li><li data-v-7504f518>6.2 <b data-v-7504f518>FX1</b> is not responsible for, and accepts no liability with respect to any material uploaded,posted, transmitted or otherwise made available on the Website by any person other\nthan <b data-v-7504f518>FX1</b>. <b data-v-7504f518>FX1</b> does not endorse any opinion, view, advice or statement made by any\nperson other than <b data-v-7504f518>FX1</b>.</li></ul><h3 data-v-7504f518>7. Cookies</h3><ul data-v-7504f518><li data-v-7504f518>7.1 A cookie is a small text file stored in your computer’s memory or on your hard disk for apre-defined period of time. We use cookies to identify specific machines in order to\ncollect aggregate information on how visitors experience the Website. This information\nwill help to better adapt the Website to suit personal requirements.</li><li data-v-7504f518>7.2 We may use third-party vendors to show <b data-v-7504f518>FX1</b> ads on sites on the Internet and servethese ads based on a user’s prior visits to the Website. <b data-v-7504f518>FX1</b> may also use analytics data\nsupplied by these vendors to inform and optimise its ad campaigns based on your prior\nvisits to the Website.</li><li data-v-7504f518>7.3 While cookies allow a computer to be identified, they do not contain personal informationabout a specific individual. For information on cookie settings of your internet browser,\nplease refer to your browser’s manual.</li></ul><h3 data-v-7504f518>8. Disclaimer and Liability</h3><ul data-v-7504f518><li data-v-7504f518>8.1 <b data-v-7504f518>FX1</b> does not guarantee that the Website will be secure or free from bugs or viruses orfunction without interruption or errors. The Website is provided on an &quot;as is&quot; and &quot;as\navailable&quot; basis. You are responsible for configuring your information technology,\ncomputer programmes and platform to access the Website. You should use your own\nvirus protection software. By accessing the Website, you assume all risks associated\nwith its use, including but not limited to the risk that your computer, software or data may\nbe damaged by any virus transmitted by the Website or by any Third Party Content or\nThird Party Website.</li><li data-v-7504f518>8.2 Subject to clause 8.3 below and any other express terms in these Terms and Conditions:<ul data-v-7504f518><li data-v-7504f518>(a) all conditions, warranties and implied terms, whether statutory or otherwise, are excluded in relation to the Website, including:<ul data-v-7504f518><li data-v-7504f518>(i) your use of, or inability to use the Website;</li><li data-v-7504f518>(ii) your use of or reliance on any Content or material displayed on the Website; and</li><li data-v-7504f518>(iii) any goods or services provided in connection with the Website.</li></ul></li><li data-v-7504f518>(b) you release <b data-v-7504f518>FX1</b> and its Affiliates from any liability for legal costs and disbursementsand, without limitation, including any direct, indirect, special, incidental, consequential\nor punitive damages, which includes, but is not limited to, loss of revenue or profits or\nbusiness or anticipated savings, loss of use or goodwill or reputation, loss of data,\neven if such loss was foreseeable, suffered by you under or in connection with the\nWebsite;</li><li data-v-7504f518>(c) <b data-v-7504f518>FX1’s</b> liability, and the liability of any of its Affiliates, for any loss suffered or incurredby you, howsoever caused, which arises out of or in connection with the supply of\ngoods or services under these Terms and Conditions is limited to:<ul data-v-7504f518><li data-v-7504f518>(i) the resupply of the goods or services; or</li><li data-v-7504f518>(ii) the payment of the cost of resupply of the goods or services; and</li><li data-v-7504f518>(iii) a credit note in the amount of the price paid for the goods or services.</li></ul></li></ul></li><li data-v-7504f518>8.3 The Australian Consumer Law provides Consumers with a number of ConsumerGuarantees that cannot be excluded or limited. The limitations of liability set out in these\nTerms and Conditions are therefore subject to, and will not apply to the extent that they\nlimit or exclude, such Consumer Guarantees applicable to Consumers. However where\nthe Australian Consumer Law permits <b data-v-7504f518>FX1</b> and its Affiliates to limit the remedies\navailable to them for a breach of a Consumer Guarantee, <b data-v-7504f518>FX1</b> and its Affiliates hereby\nlimit their remedies to such Consumers for a breach of a Consumer Guarantee to\nsupplying the goods or services again or paying the cost of having the goods or services\nsupplied again.</li><li data-v-7504f518>8.4 FX1 will not be liable or responsible under these Terms and Conditions or otherwise for afailure to provide any services in accordance with these Terms and Conditions or at all to\nthe extent that such failure is caused or contributed to by you.</li><li data-v-7504f518>8.5 For the purposes of this clause 8:<ul data-v-7504f518><li data-v-7504f518>(a) <b data-v-7504f518>Australian Consumer</b> Law means schedule 2 of the Competition and Consumer Act 2010 (Cth) and any equivalent state or territory legislation;</li><li data-v-7504f518>(b) <b data-v-7504f518>Consumer Guarantees</b> means any right or statutory guarantee under Division 1 of Part 3-2 of the Australian Consumer Law; and</li><li data-v-7504f518>(c) <b data-v-7504f518>Consumer</b> has the meaning given to it in section 3 of the Australian Consumer Law.</li></ul></li></ul><h3 data-v-7504f518>9. Jurisdiction</h3><ul data-v-7504f518><li data-v-7504f518>These terms and conditions are governed by the laws of Victoria, Australia.</li></ul><h3 data-v-7504f518>10. Contact</h3><ul data-v-7504f518><li data-v-7504f518>If you have any queries regarding these Terms and Conditions, please contact <b data-v-7504f518>FX1 at <a href=\"mailto:hello@FX1.com\" data-v-7504f518>hello@FX1.com</a>.</b></li></ul>")],2)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/pages/Terms.vue?vue&type=template&id=7504f518&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/Terms.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Termsvue_type_script_lang_js_ = ({
  name: 'XPTerms'
});
// CONCATENATED MODULE: ./components/pages/Terms.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_Termsvue_type_script_lang_js_ = (Termsvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/pages/Terms.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1115)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pages_Termsvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "7504f518",
  "b3806016"
  
)

/* harmony default export */ var Terms = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 901:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1116);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("43d7ea26", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=149.js.map
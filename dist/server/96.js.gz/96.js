exports.ids = [96];
exports.modules = {

/***/ 1230:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_VideoSection_vue_vue_type_style_index_0_id_31e1a948_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(958);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_VideoSection_vue_vue_type_style_index_0_id_31e1a948_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_VideoSection_vue_vue_type_style_index_0_id_31e1a948_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_VideoSection_vue_vue_type_style_index_0_id_31e1a948_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_VideoSection_vue_vue_type_style_index_0_id_31e1a948_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1231:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".token-video-section[data-v-31e1a948]{width:100%;position:relative;overflow:hidden;padding:135px 0 200px;z-index:2}.token-video-section[data-v-31e1a948] .top-margin-a{margin-top:150px}.token-video-section[data-v-31e1a948] .top-margin-b{margin-top:230px}.token-video-section[data-v-31e1a948] .top-margin-c{margin-top:0}.token-video-section[data-v-31e1a948] .tokenonmics-red-box{width:100%;padding:45px 0;background:linear-gradient(268.82deg,#f85454 56.01%,rgba(248,84,84,0) 122.21%);border-radius:10px}.token-video-section[data-v-31e1a948] .tokenonmics-red-box .same-width{width:14%}.token-video-section[data-v-31e1a948] .tokenonmics-red-box .light-text{margin-top:10px;letter-spacing:.5px}.token-video-section[data-v-31e1a948] .tokenonmics-red-box .tokenonmics-text{width:30%}.token-video-section[data-v-31e1a948] .logo-section img{width:85%}.token-video-section[data-v-31e1a948] .content-middle{position:relative;z-index:1;width:100%;margin:auto;box-shadow:0 25px 77px -10px hsla(0,0%,100%,.2)}@media screen and (max-width:500px){.token-video-section[data-v-31e1a948]{padding:100px 0}.token-video-section[data-v-31e1a948] .top-margin-a,.token-video-section[data-v-31e1a948] .top-margin-b{margin-top:80px}.token-video-section[data-v-31e1a948] .top-margin-c{margin-top:20px}.token-video-section[data-v-31e1a948] .tokenonmics-red-box{display:block!important;text-align:center!important}.token-video-section[data-v-31e1a948] .same-width{width:100%!important;margin-top:20px}.token-video-section[data-v-31e1a948] .light-text{margin-top:0!important;letter-spacing:.5px}.token-video-section[data-v-31e1a948] .tokenonmics-text{width:100%!important}.token-video-section[data-v-31e1a948] .logo-left,.token-video-section[data-v-31e1a948] .logo-right,.token-video-section[data-v-31e1a948] .text-left,.token-video-section[data-v-31e1a948] .text-right{width:100%!important;flex:none!important;text-align:center!important;margin-bottom:20px}.token-video-section[data-v-31e1a948] .logo-left{padding:0 5px}.token-video-section[data-v-31e1a948] .logo-section img{width:90%}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1405:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/VideoSection.vue?vue&type=template&id=31e1a948&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"token-video-section row"},[_vm._ssrNode("<div class=\"container token-container\" data-v-31e1a948>","</div>",[_vm._ssrNode("<div class=\"content-middle video-body text-center\" data-v-31e1a948>","</div>",[_c('EmbedVideo')],1),_vm._ssrNode("<div class=\"top-margin-b\" data-v-31e1a948></div><div class=\"tokenonmics-red-box row\" data-v-31e1a948><div class=\"tokenonmics-text text-center\" data-v-31e1a948><h2 data-v-31e1a948><b data-v-31e1a948>Tokenomics</b></h2></div><div class=\"same-width maxsupply-text text-center\" data-v-31e1a948><h2 data-v-31e1a948>250M</h2><p class=\"token-p light-text\" data-v-31e1a948>Max Supply</p></div><div class=\"same-width selltax-text text-center\" data-v-31e1a948><h2 data-v-31e1a948>6%</h2><p class=\"token-p light-text\" data-v-31e1a948>Sell Tax</p></div><div class=\"same-width buytax-text text-center\" data-v-31e1a948><h2 data-v-31e1a948>6%</h2><p class=\"token-p light-text\" data-v-31e1a948>Buy Tax</p></div><div class=\"same-width maxtransaction-text text-center\" data-v-31e1a948><h2 data-v-31e1a948>0.5%</h2><p class=\"token-p light-text\" data-v-31e1a948>Max Transaction<br data-v-31e1a948>Anti-whale</p></div><div class=\"same-width maxwhale-text text-center\" data-v-31e1a948><h2 data-v-31e1a948>1%</h2><p class=\"token-p light-text\" data-v-31e1a948>Max Wallet<br data-v-31e1a948>Anti-Whale</p></div></div><div class=\"top-margin-b\" data-v-31e1a948></div><div class=\"logo-section row\" data-v-31e1a948><div class=\"logo-left col text-left\" data-v-31e1a948><img"+(_vm._ssrAttr("src",__webpack_require__(648)))+" alt=\"Register your club\" data-v-31e1a948><div class=\"top-margin-c\" data-v-31e1a948></div></div><div class=\"logo-right col text-right\" data-v-31e1a948><img"+(_vm._ssrAttr("src",__webpack_require__(653)))+" alt=\"Register your club\" data-v-31e1a948></div></div>")],2)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Token/VideoSection.vue?vue&type=template&id=31e1a948&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/VideoSection.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var VideoSectionvue_type_script_lang_js_ = ({
  name: 'VideoSection',
  components: {
    EmbedVideo: () => __webpack_require__.e(/* import() */ 23).then(__webpack_require__.bind(null, 1437))
  }
});
// CONCATENATED MODULE: ./components/molecules/Token/VideoSection.vue?vue&type=script&lang=js&
 /* harmony default export */ var Token_VideoSectionvue_type_script_lang_js_ = (VideoSectionvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/Token/VideoSection.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1230)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Token_VideoSectionvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "31e1a948",
  "0486ecf4"
  
)

/* harmony default export */ var VideoSection = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 648:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/proof-verification.930a649.png";

/***/ }),

/***/ 653:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/verified-badge-stacked.60406d1.png";

/***/ }),

/***/ 958:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1231);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("306d8e6a", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=96.js.map
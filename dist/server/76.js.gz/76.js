exports.ids = [76];
exports.modules = {

/***/ 1141:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_style_index_0_id_7320054d_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(914);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_style_index_0_id_7320054d_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_style_index_0_id_7320054d_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_style_index_0_id_7320054d_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_style_index_0_id_7320054d_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1142:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".explore-event-footer[data-v-7320054d]{display:flex;justify-content:space-between;font-family:\"Rotunda\";font-style:normal;position:fixed;bottom:0;left:0;right:0;width:100%;height:92px;position:absolute;background:rgba(8,37,44,.9);padding:16px 20px}@media screen and (max-width:500px){.explore-event-footer[data-v-7320054d]{height:auto;padding-bottom:30px}}.explore-event-footer b[data-v-7320054d]{font-weight:600;font-size:22px;line-height:24px;letter-spacing:-.66px}.explore-event-footer b span[data-v-7320054d]{text-transform:uppercase}.explore-event-footer .left .date__container[data-v-7320054d]{display:flex;align-items:center;margin-top:15px}@media(min-width:375px)and (max-width:767px){.explore-event-footer .left .date__container[data-v-7320054d]{margin-top:0}}.explore-event-footer .left img[data-v-7320054d]{font-weight:400;font-size:16px;line-height:18px;letter-spacing:-.66px;margin-right:10px}.explore-event-footer .chat[data-v-7320054d]{height:46px;display:flex;align-items:center;border-radius:8px;padding:13px;cursor:pointer}@media screen and (max-width:600px){.explore-event-footer .chat[data-v-7320054d]{height:41px;padding:9px 9px 9px 0}}@media screen and (max-width:400px){.explore-event-footer .chat[data-v-7320054d]{font-size:13px;height:40px}}.explore-event-footer .chat img[data-v-7320054d]{margin-right:5px}.explore-event-footer .chat p[data-v-7320054d]{margin-top:2px;font-weight:500;font-size:14px;line-height:16px;letter-spacing:.8px;text-transform:uppercase;color:#fff}@media screen and (max-width:427px){.explore-event-footer .chat p[data-v-7320054d]{max-width:150px;overflow:hidden;text-overflow:ellipsis}}@media screen and (max-width:600px){.explore-event-footer b[data-v-7320054d]{font-size:16px}}@media screen and (max-width:350px){.explore-event-footer b[data-v-7320054d],.explore-event-footer p[data-v-7320054d]{font-size:13px}}.chat-active[data-v-7320054d]{background-color:#0c353e}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1143:
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./Baseball.svg": 621,
	"./Basketball.svg": 622,
	"./Football.svg": 623,
	"./Ice-Hockey.svg": 624,
	"./Soccer.svg": 625,
	"./boxing.svg": 626
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 1143;

/***/ }),

/***/ 1144:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ExploreEvent_vue_vue_type_style_index_0_id_4ebde8ec_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(915);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ExploreEvent_vue_vue_type_style_index_0_id_4ebde8ec_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ExploreEvent_vue_vue_type_style_index_0_id_4ebde8ec_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ExploreEvent_vue_vue_type_style_index_0_id_4ebde8ec_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ExploreEvent_vue_vue_type_style_index_0_id_4ebde8ec_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1145:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(24);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(655);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".explore-page[data-v-4ebde8ec]{height:100%}.content__container[data-v-4ebde8ec]{display:flex;height:80%}.switch[data-v-4ebde8ec]{position:relative;display:inline-block;width:37px;height:17px}.switch input[data-v-4ebde8ec]{opacity:0;width:0;height:0}.slider[data-v-4ebde8ec]{cursor:pointer;top:0;left:0;right:0;bottom:0;background-color:#ccc}.slider[data-v-4ebde8ec],.slider[data-v-4ebde8ec]:before{position:absolute;transition:.4s}.slider[data-v-4ebde8ec]:before{content:\"\";height:19px;width:19px;top:-1px;left:-4px;bottom:4px;background-color:#fff}input:checked+.slider[data-v-4ebde8ec]{background-color:#886bf2}input:focus+.slider[data-v-4ebde8ec]{box-shadow:0 0 1px #886bf2}input:checked+.slider[data-v-4ebde8ec]:before{transform:translateX(26px)}.slider.round[data-v-4ebde8ec]{border-radius:34px}.slider.round[data-v-4ebde8ec]:before{border-radius:50%}.show-scores-text[data-v-4ebde8ec]{margin-top:20px}.show-scores-text p[data-v-4ebde8ec]{font-size:20px;line-height:22px;text-transform:none;display:inline-block;margin-right:15px}@media screen and (max-width:767px){.show-scores-text p[data-v-4ebde8ec]{display:inline-block!important;font-size:11px}}@media screen and (max-width:400px){.show-scores-text p[data-v-4ebde8ec]{margin-right:10px}}@media screen and (max-width:400px){.show-scores-text[data-v-4ebde8ec]{width:130%}}.iframeStyles[data-v-4ebde8ec]{height:calc(100% - 170px)!important;width:100%;position:fixed;left:0;height:63%;top:80px}.close[data-v-4ebde8ec]{position:fixed;right:8px;margin-right:10px;z-index:100000;top:10;width:44px;height:50px}.watch-on[data-v-4ebde8ec]{margin:10px auto auto;position:relative;text-align:center}.watch-on span[data-v-4ebde8ec]{display:inline-block;position:absolute;margin-top:72px;margin-left:-62px}.watch-on .watch-link[data-v-4ebde8ec]{display:inline-block;margin-left:15px;cursor:pointer;width:70px;margin-top:5px}.watch-on .watch-link img[data-v-4ebde8ec]{width:82px;height:82px}@media screen and (max-width:767px){.watch-on .watch-link img[data-v-4ebde8ec]{width:42px;height:42px}}.watch-on-text[data-v-4ebde8ec]{margin-top:5px}@media(max-width:500px){.logo-img[data-v-4ebde8ec]{width:90%}}.explore-footer[data-v-4ebde8ec]{position:fixed;left:0;bottom:0}.xp-live[data-v-4ebde8ec] .bg-image{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ")!important;background-size:cover;background-repeat:no-repeat;background-position:50%}.xp-live[data-v-4ebde8ec] .page-content{font-family:\"Rotunda\";font-style:normal}.xp-live[data-v-4ebde8ec] .page-content .vuebar{width:100%!important;padding:24px 32px 0!important;box-sizing:border-box!important;-ms-overflow-style:none;scrollbar-width:none}.xp-live[data-v-4ebde8ec] .page-content .vuebar .back-arrow{margin-top:-8px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .back-arrow a{margin-top:5px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .show-modal{position:absolute;top:30px;right:20px;cursor:pointer}.xp-live[data-v-4ebde8ec] .page-content .vuebar .show-modal img{display:block}.xp-live[data-v-4ebde8ec] .page-content .vuebar .soccer{padding:8px;min-width:135px;height:40px;margin-left:36px;background:hsla(0,0%,100%,.2);border-radius:5px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .soccer img{float:left;margin-right:10px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .soccer p{min-width:87px;float:right;height:24px;font-weight:600;font-size:22px;line-height:24px;letter-spacing:-.66px;color:#fff}@media screen and (max-width:845px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .livescores{grid-gap:0!important;gap:0!important}}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev{padding:0;grid-gap:60px;gap:60px;width:831px;margin:-5px auto auto;text-transform:uppercase}@media screen and (max-width:1200px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev{margin-top:10px}}@media screen and (min-width:426px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev{height:100%}}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .circle{border-radius:100%;height:235px;font-size:20px;text-align:center;line-height:242px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .logo h2{font-weight:500;font-size:32px;margin-top:25px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .logo p{font-weight:500;font-size:14px;line-height:16px;margin-top:20px}@media screen and (max-width:500px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .logo{max-width:80px}}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .live{margin:-46px auto auto;position:relative;width:117px;height:42px;background:#f85454;border-radius:8px;justify-content:center;align-items:center;padding:4px 12px;grid-gap:8px;gap:8px}@media screen and (max-width:767px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .live{margin-top:0}}@media screen and (max-width:500px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .live{margin-top:30px}}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .live img{display:inline-block;margin-left:-35px;margin-top:5px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .live span{display:inline-block;position:absolute;margin-top:6px;text-transform:capitalize;margin-left:6px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .scores{margin-top:30px;font-weight:500;font-size:3vw;text-transform:uppercase;color:#fff}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .scores .team1Score{justify-content:center;align-items:center;padding:10px;grid-gap:8px;gap:8px;width:91px;height:85px;background:hsla(0,0%,100%,.3);border-radius:5px;display:inline-block}@media screen and (min-width:2559px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .scores .team1Score{height:115px}}@media screen and (min-width:1900px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .scores .team1Score{height:100px}}@media screen and (max-width:1100px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .scores .team1Score{width:70px;height:60px;font-size:3.2vw}}@media screen and (max-width:667px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .scores .team1Score{width:42px;height:36px;font-size:25px;padding:0;position:relative}}@media screen and (max-width:350px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .scores .team1Score{width:35px;height:26px;font-size:15px}}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .scores .divider{display:inline-block;padding:2px;background:#fff;margin:12px;height:5px;width:25px}@media screen and (max-width:667px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .scores .divider{width:15px;height:5px}}@media screen and (max-width:500px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .scores .divider{width:15px;height:5px;margin:5px}}@media screen and (max-width:350px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .scores .divider{width:12px;height:0;margin:3px}}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .scores .team2Score{justify-content:center;display:inline-block;align-items:center;padding:10px;grid-gap:8px;gap:8px;width:91px;height:85px;background:hsla(0,0%,100%,.3);border-radius:5px}@media screen and (min-width:2559px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .scores .team2Score{height:115px}}@media screen and (min-width:1900px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .scores .team2Score{height:100px}}@media screen and (max-width:1100px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .scores .team2Score{width:70px;height:60px;font-size:3.2vw}}@media screen and (max-width:667px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .scores .team2Score{width:42px;height:36px;font-size:25px;padding:0;position:relative}}@media screen and (max-width:350px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .scores .team2Score{width:35px;height:26px;font-size:16px}}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .score-error{padding-top:30px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time .points{font-weight:400;font-size:20px;line-height:22px;color:#f5f5f5;margin-top:10px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .date-time{font-weight:500;margin:30px auto auto;font-size:18px;line-height:22px;padding:10px;grid-gap:8px;gap:8px;width:205px;background:hsla(0,0%,100%,.3);border-radius:5px;align-self:stretch}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev h2.time{font-weight:600;font-size:40px;line-height:45px;margin-top:30px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev h2.full-time{font-weight:600;font-size:40px;margin-top:10px;line-height:45px}@media screen and (max-width:814px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev h2.full-time{font-size:30px}}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev h2.time+p{margin-top:10px;font-weight:400;font-size:20px;line-height:22px;word-spacing:35px;margin-left:15px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .setreminder{background:#f85454}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .setreminder span{display:inline-flex;align-items:flex-start;grid-gap:12px;gap:12px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .removereminder{background:none;border:none!important}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .removereminder span{display:inline-flex;align-items:flex-start;grid-gap:12px;gap:12px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .remind-me{margin-top:20px;font-weight:500;font-size:14px;line-height:18px;text-align:center;letter-spacing:.8px;text-transform:uppercase;justify-content:center;align-items:center;padding:12px 24px;grid-gap:10px;gap:10px;width:205px;height:42px;border-radius:5px;color:#fff}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .upcomingGames{display:flex;margin:15px auto;padding:0}@media screen and (max-width:500px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .upcomingGames{font-size:8px}}@media screen and (max-width:1024px){.xp-live[data-v-4ebde8ec] .page-content .vuebar{padding:24px 57px 40px 40px!important}}@media screen and (max-width:767px){.xp-live[data-v-4ebde8ec] .page-content .vuebar{padding:30px 7px 30px 5px!important}}@media screen and (max-width:420px){.xp-live[data-v-4ebde8ec] .page-content .vuebar{padding:24px 16px!important;width:100%!important}}@media screen and (max-width:919px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev{width:100%!important}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .circle{width:150px;margin:auto;height:150px;line-height:158px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev h2{font-weight:500;font-size:28px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .date-time{font-size:16px;line-height:18px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev h2.time{font-weight:700;font-size:36px;line-height:40px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev h2.time+p{font-size:16px;line-height:18px}}@media screen and (max-width:814px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .soccer p{font-size:18px;line-height:20px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev{width:100%!important}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .circle{width:150px;margin:auto;height:150px;line-height:158px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev h2{font-weight:500;font-size:24px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .date-time{font-size:12px;line-height:18px;width:160px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev h2.time{font-weight:700;font-size:32px;width:160px;line-height:40px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev h2.time+p{font-size:12px;line-height:18px}}@media screen and (max-width:767px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .soccer p{font-size:18px;line-height:23px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .center-image{display:none}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev{padding:0;grid-gap:0!important;gap:0!important;width:100%!important}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .circle{width:120px;margin:auto;font-size:14px;height:120px;line-height:129px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .logo h2,.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev p{display:none}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .scores p{display:block!important}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev h2{font-weight:500;font-size:18px!important}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .date-time,.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .removereminder,.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .setreminder{font-size:12px;line-height:18px;width:160px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev h2.time{font-weight:700;font-size:32px;width:100%;line-height:40px;word-spacing:13px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev h2.time+p{display:none}}@media screen and (max-width:500px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .soccer{margin-left:5px;margin-top:0;min-width:auto}.xp-live[data-v-4ebde8ec] .page-content .vuebar .soccer p{font-size:14px;line-height:26px;font-weight:300;min-width:auto}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev{padding:0;margin-top:-10px;grid-gap:0!important;gap:0!important;width:100%!important}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .circle{width:80px;margin:auto;font-size:12px;height:80px;line-height:85px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .center-time{max-width:100%;display:\"flex\";justify-content:center;align-items:center;flex-direction:\"coloum\"}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev h2{font-weight:500;font-size:16px!important}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .date-time{width:100%;max-width:133px;padding:8px;font-size:12px;line-height:18px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .removereminder,.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .setreminder{width:100%;max-width:145px;margin-top:10px;padding:unset;font-size:12px;line-height:18px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .upcomingGames{font-size:8px!important}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev h2.time{margin-top:8px;line-height:40px;word-spacing:10px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .watch-on-text{display:none}.xp-live[data-v-4ebde8ec] .page-content .vuebar .watch-on{display:inline-block;width:100%!important;padding-right:15px;padding-left:5px}}@media screen and (max-width:400px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .circle{margin:0!important;width:70px;margin:auto;font-size:10px;height:70px;line-height:76px}.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .rightcircle{float:right}}@media screen and (max-width:300px){.xp-live[data-v-4ebde8ec] .page-content .vuebar .main-dev .circle{margin:0!important;width:60px;margin:auto;font-size:10px;height:60px;line-height:64px}}.xp-live[data-v-4ebde8ec] .page-content .vuebar::-webkit-scrollbar{display:none}.xp-live[data-v-4ebde8ec] .page-content.vb>.vb-dragger{z-index:5;width:12px;right:0;opacity:0}.xp-live[data-v-4ebde8ec] .page-content.vb>.vb-dragger>.vb-dragger-styler{backface-visibility:hidden;transform:rotate3d(0,0,0,0);transition:background-color .1s ease-out,margin .1s ease-out,height .1s ease-out;background-color:#08252c;margin:5px 2px 0;border-radius:20px;height:calc(100% - 10px);display:block}.xp-live[data-v-4ebde8ec] .page-content.vb>.vb-dragger:hover>.vb-dragger-styler{background-color:#08252c;height:100%}.xp-live[data-v-4ebde8ec] .page-content.vb.vb-scrolling-phantom>.vb-dragger>.vb-dragger-styler{background-color:#08252c}.xp-live[data-v-4ebde8ec] .page-content.vb.vb-dragging>.vb-dragger>.vb-dragger-styler{background-color:#08252c;height:100%}.xp-live[data-v-4ebde8ec] .page-content.vb.vb-dragging-phantom>.vb-dragger>.vb-dragger-styler{background-color:#08252c}.xp-live[data-v-4ebde8ec] .page-content.vb:hover>.vb-dragger{opacity:.8}@media screen and (max-width:767px){.xp-live[data-v-4ebde8ec].is-logged-out .page-content{height:100vh}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1356:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/ExploreEvent.vue?vue&type=template&id=4ebde8ec&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xp-live col",class:!_vm.isLoggedIn && 'is-logged-out'},[_c('div',{directives:[{name:"bar",rawName:"v-bar"}],staticClass:"page-content bg-image"},[_vm._ssrNode("<div class=\"vuebar\" data-v-4ebde8ec>","</div>",[(!_vm.lockerRoomLoading && !_vm.paramsValidationActive)?_vm._ssrNode("<div class=\"explore-page\" data-v-4ebde8ec>","</div>",[_vm._ssrNode("<div class=\"row items-left back-arrow\" data-v-4ebde8ec>","</div>",[_c('nuxt-link',{attrs:{"to":"/explore"}},[_c('img',{attrs:{"src":__webpack_require__(324)}})]),_vm._ssrNode(((_vm.game && Object.keys(_vm.game).length > 0)?("<div class=\"soccer\" data-v-4ebde8ec><img"+(_vm._ssrAttr("src",_vm.sportIcon))+" data-v-4ebde8ec><p data-v-4ebde8ec>"+_vm._ssrEscape(_vm._s(_vm.game.sport))+"</p></div>"):"<!---->"))],2),_vm._ssrNode("<div class=\"content__container\" data-v-4ebde8ec>","</div>",[_vm._ssrNode("<div"+(_vm._ssrClass("row items-center jusitfy-content-center main-dev",_vm.gameStatus === 2 ? 'livescores' : ''))+" data-v-4ebde8ec>","</div>",[_vm._ssrNode("<div class=\"col text-center logo\" data-v-4ebde8ec>","</div>",[(_vm.game.team1Logo)?_c('nuxt-img',{staticClass:"logo-img",attrs:{"src":_vm.game.team1Logo}}):_c('div',{staticClass:"circle",style:({ backgroundColor: '#' + _vm.game.team1Color })},[_vm._v(_vm._s(_vm.team1Title))]),_vm._ssrNode("<h2 data-v-4ebde8ec>"+_vm._ssrEscape(_vm._s(_vm.team1Title))+"</h2><p data-v-4ebde8ec>AWAY</p>")],2),_vm._ssrNode("<div class=\"col text-center center-time\" data-v-4ebde8ec>","</div>",[_vm._ssrNode(((_vm.gameStatus === 1)?("<div data-v-4ebde8ec>"+((_vm.showExploreLeagueImage)?("<img"+(_vm._ssrAttr("src",__webpack_require__(320)))+" class=\"center-image\" data-v-4ebde8ec>"):"<!---->")+"<div class=\"date-time\" data-v-4ebde8ec>"+_vm._ssrEscape(_vm._s(_vm.dateTimeFormat))+"</div>"+((!_vm.hideTimer)?("<div data-v-4ebde8ec><h2 class=\"time\" data-v-4ebde8ec>"+_vm._ssrEscape(_vm._s(_vm.timeLeft))+"</h2><p data-v-4ebde8ec>HR MIN SEC</p></div>"):"<!---->")+"</div>"):"<!---->")+((_vm.gameStatus === 3)?("<div class=\"match-full\" data-v-4ebde8ec><h2 class=\"full-time\" data-v-4ebde8ec>Full-Time</h2><div class=\"show-scores-text\" data-v-4ebde8ec><p data-v-4ebde8ec>Show scores</p><label class=\"switch\" data-v-4ebde8ec><input type=\"checkbox\""+(_vm._ssrAttr("checked",_vm.showScore))+(_vm._ssrAttr("checked",Array.isArray(_vm.showScore)?_vm._i(_vm.showScore,null)>-1:(_vm.showScore)))+" data-v-4ebde8ec><span class=\"slider round\" data-v-4ebde8ec></span></label></div></div>"):"<!---->")+((_vm.gameStatus === 3 && _vm.showScore && !_vm.scoreIsNull)?("<div class=\"scores\" data-v-4ebde8ec><div class=\"team1Score\" data-v-4ebde8ec><p data-v-4ebde8ec>"+_vm._ssrEscape(_vm._s(_vm.game.team1Score))+"</p></div><div class=\"divider\" data-v-4ebde8ec></div><div class=\"team2Score\" data-v-4ebde8ec><p data-v-4ebde8ec>"+_vm._ssrEscape(_vm._s(_vm.game.team2Score))+"</p></div></div>"):"<!---->")+((_vm.gameStatus === 3 && _vm.showScore && _vm.scoreIsNull)?("<div class=\"score-error\" data-v-4ebde8ec><p data-v-4ebde8ec>An error has occurred</p></div>"):"<!---->")+((_vm.gameStatus == 2)?("<div data-v-4ebde8ec><div class=\"live\" data-v-4ebde8ec><img"+(_vm._ssrAttr("src",__webpack_require__(341)))+" data-v-4ebde8ec><span data-v-4ebde8ec>Live</span></div><div class=\"scores\" data-v-4ebde8ec><div class=\"team1Score\" data-v-4ebde8ec><p data-v-4ebde8ec>"+_vm._ssrEscape(_vm._s(_vm.game.team1Score))+"</p></div><div class=\"divider\" data-v-4ebde8ec></div><div class=\"team2Score\" data-v-4ebde8ec><p data-v-4ebde8ec>"+_vm._ssrEscape(_vm._s(_vm.game.team2Score))+"</p></div></div><p class=\"points\" data-v-4ebde8ec>"+_vm._ssrEscape(_vm._s(_vm.game.timeLeft))+"</p></div>"):"<!---->")),(_vm.gameStatus === 1)?_c('b-button',{staticClass:"is-uppercase remind-me",class:_vm.reminderSet ? 'removereminder' : 'setreminder',attrs:{"loading":_vm.isReminderLoading,"type":"is-primary","disabled":_vm.isReminderLoading},on:{"click":function($event){_vm.reminderSet ? _vm.unsetReminder() : _vm.setReminder()}}},[_vm._v(_vm._s(_vm.reminderSet ? 'REMOVE REMINDER' : 'REMIND ME')),_c('img',{attrs:{"src":__webpack_require__(325)}})]):_vm._e(),(_vm.gameStatus === 3)?_c('nuxt-link',{staticClass:"is-uppercase remind-me upcomingGames",class:_vm.reminderSet ? 'removereminder' : 'setreminder',attrs:{"to":"/explore","loading":_vm.isReminderLoading,"type":"is-primary"}},[_vm._v("SEE UPCOMING GAMES")]):_vm._e()],2),_vm._ssrNode("<div class=\"col text-center logo\" data-v-4ebde8ec>","</div>",[(_vm.game.team2Logo)?_c('nuxt-img',{staticClass:"logo-img",attrs:{"src":_vm.game.team2Logo}}):_c('div',{staticClass:"circle rightcircle",style:({ backgroundColor: '#' + _vm.game.team2Color })},[_vm._v(_vm._s(_vm.team2Title))]),_vm._ssrNode("<h2 data-v-4ebde8ec>"+_vm._ssrEscape(_vm._s(_vm.team2Title))+"</h2><p data-v-4ebde8ec>HOME</p>")],2)])])]):_c('XALoader'),_vm._ssrNode(((!_vm.lockerRoomLoading)?("<div class=\"show-modal\""+(_vm._ssrStyle(null,{ transform: _vm.isShowChat ? 'rotate(-180deg)' : 'rotate(0deg)' }, null))+" data-v-4ebde8ec><img"+(_vm._ssrAttr("src",__webpack_require__(349)))+" data-v-4ebde8ec></div>"):"<!---->")),(_vm.showLoadingPlayer)?_vm._ssrNode("<div data-v-4ebde8ec>","</div>",[_c('b-button',{staticClass:"is-primary close",on:{"click":_vm.closeStreaming}},[_vm._v("close")]),_vm._ssrNode(((_vm.showLoadingPlayer)?("<iframe"+(_vm._ssrAttr("src",_vm.iframeSrc))+" tile=\"Live Streaming\" class=\"iframeStyles\" data-v-4ebde8ec></iframe>"):"<!---->"))],2):_vm._e(),_c('XOExploreEventFooter',{staticClass:"explore-footer",attrs:{"game":_vm.game,"showChat":_vm.isShowChat,"privateChannel":_vm.privateChannel},on:{"showChat":_vm.showChat}}),(_vm.game && _vm.channelSlug)?_c('XOExploreEventChat',{attrs:{"showModal":_vm.isShowChat,"activeChat":_vm.activeChat,"channelSlug":_vm.channelSlug,"privateChannel":_vm.privateChannel,"game":_vm.game,"lockerRoom":_vm.lockerRoom},on:{"cancel":_vm.isShowChat,"hide":function($event){_vm.isShowChat = false},"switchChat":_vm.switchChat,"setPrivateChannel":_vm.setPrivateChannel}}):_vm._e()],2)])])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/pages/ExploreEvent.vue?vue&type=template&id=4ebde8ec&scoped=true&lang=pug&

// EXTERNAL MODULE: external "moment"
var external_moment_ = __webpack_require__(215);
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_);

// EXTERNAL MODULE: external "vuex-map-fields"
var external_vuex_map_fields_ = __webpack_require__(2);

// EXTERNAL MODULE: ./components/organisms/ExploreEvent/Footer.vue + 4 modules
var Footer = __webpack_require__(992);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/ExploreEvent.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ var ExploreEventvue_type_script_lang_js_ = ({
  name: 'Explore',
  components: {
    XOExploreEventFooter: Footer["a" /* default */],
    XOExploreEventChat: () => __webpack_require__.e(/* import() */ 136).then(__webpack_require__.bind(null, 1391)),
    XALoader: () => __webpack_require__.e(/* import() */ 3).then(__webpack_require__.bind(null, 275))
  },
  props: {
    lockerRoom: {
      type: Object,
      default: () => {}
    },
    paramsValidationActive: {
      type: Boolean
    }
  },
  data() {
    return {
      game: {},
      isShowChat: false,
      showExploreLeagueImage: false,
      showLoadingPlayer: false,
      hideTimer: false,
      showScore: false,
      channelSlug: null,
      channelActive: null,
      socket: null,
      gameStatus: 1,
      // 1 Is for UpComming games, 2 is for Live Games and 3 is Over Games
      iframeSrc: '',
      reminderSet: false,
      timeLeft: '0 : 0 : 0',
      endpoint: null,
      activeChat: '',
      isReminderLoading: false,
      interval: null,
      timerInterval: null,
      privateChannel: null,
      style: {
        backgroundImage: `url('@/assets/images/explore-event/Background.png') !important;`
      }
    };
  },
  computed: {
    ...Object(external_vuex_map_fields_["mapFields"])('app', ['selectedGameEventRoom']),
    ...Object(external_vuex_map_fields_["mapFields"])('user', ['userID']),
    ...Object(external_vuex_map_fields_["mapFields"])('locker-room', ['lockerRoomLoading']),
    dateTimeFormat() {
      if (this.lockerRoom && this.lockerRoom.Game) {
        var _this$lockerRoom$Game;
        return external_moment_default()((_this$lockerRoom$Game = this.lockerRoom.Game) === null || _this$lockerRoom$Game === void 0 ? void 0 : _this$lockerRoom$Game.date).local().format('ddd DD MMM | HH:mm');
      }
      return '';
    },
    sportIcon() {
      var _this$lockerRoom;
      return Object.keys((_this$lockerRoom = this.lockerRoom) === null || _this$lockerRoom === void 0 ? void 0 : _this$lockerRoom.Game).length > 0 ? __webpack_require__(1143)(`./${this.lockerRoom.Game.sport.replace(' ', '-')}.svg`) : null;
    },
    scoreIsNull() {
      return this.game.team1Score === null || this.game.team2Score === null;
    },
    team1Title() {
      return this.game.team1Name || this.game.team1DisplayName || this.game.team1Nickname || this.game.team1City;
    },
    team2Title() {
      return this.game.team2Name || this.game.team2DisplayName || this.game.team2Nickname || this.game.team2City;
    }
  },
  watch: {
    lockerRoom: {
      deep: true,
      handler() {
        this.initEventRoom(this.lockerRoom.Game);
      }
    },
    paramsValidationActive: {
      handler(value) {
        if (!value && this.$route.query.privateShow) {
          this.activeChat = 'private';
          this.isShowChat = true;
        }
      }
    }
  },
  async created() {
    if (this.$route.query.privateShow && !this.isLoggedIn) {
      await this.$router.push({
        path: '/signin'
      });
    }
    this.socket = this.$nuxtSocket({
      channel: '/',
      auth: {
        token: this.$store.state.auth.token || null,
        type: 'desktop'
      },
      transports: ['websocket']
    });
    if (this.selectedGameEventRoom) {
      await this.initEventRoom(this.selectedGameEventRoom);
    }
  },
  mounted() {
    this.interval = setInterval(async () => {
      if (this.lockerRoom && this.lockerRoom.Game) {
        const gameID = this.lockerRoom.Game.gameID;
        const {
          getGame
        } = await this.$api.getGame({
          gameID
        });
        this.updateEventRoom(getGame);
      }
    }, 5000);
  },
  beforeDestroy() {
    clearInterval(this.interval);
    clearInterval(this.timerInterval);
  },
  methods: {
    initEventRoom(game) {
      try {
        this.game = game;
        this.channelActive = this.lockerRoom.ChannelGroups[0].Channels[0];
        this.channelSlug = this.lockerRoom.ChannelGroups[0].Channels[0].slug;
        const userIsOwner = this.lockerRoom.ChannelGroups[0].Channels.findIndex(channel => {
          var _channel$Roles, _channel$Roles$Owners;
          return ((_channel$Roles = channel.Roles) === null || _channel$Roles === void 0 ? void 0 : (_channel$Roles$Owners = _channel$Roles.Owners[0]) === null || _channel$Roles$Owners === void 0 ? void 0 : _channel$Roles$Owners.User.id) === this.userID;
        });
        const userIsJoiner = this.lockerRoom.ChannelGroups[0].Channels.findIndex(channel => {
          var _channel$Roles2;
          return (_channel$Roles2 = channel.Roles) === null || _channel$Roles2 === void 0 ? void 0 : _channel$Roles2.Joiners.find(joiner => joiner.User.id === this.userID);
        });
        this.privateChannel = userIsOwner !== -1 || userIsJoiner !== -1 ? this.lockerRoom.ChannelGroups[0].Channels[userIsOwner !== -1 ? userIsOwner : userIsJoiner] : null;
        this.updateEventRoom(this.game);
      } catch (error) {
        var _error$response;
        error === null || error === void 0 ? void 0 : (_error$response = error.response) === null || _error$response === void 0 ? void 0 : _error$response.errors.forEach(error => {
          this.$toast.error(error.message, {
            duration: 5000,
            position: 'bottom-left',
            className: 'fx1-success',
            iconPack: 'mdi',
            icon: 'alert-circle-outline'
          });
        });
      } finally {
        this.$store.dispatch('locker-room/setLockerRoomLoading', false);
      }
    },
    updateEventRoom(game) {
      this.game = game;
      if (this.game) {
        var _this$game, _this$game2;
        if ((_this$game = this.game) !== null && _this$game !== void 0 && _this$game.isLive) {
          this.game.GameStatus = 2;
          this.gameStatus = 2;
        }
        if (external_moment_default()().isAfter(external_moment_default()(this.game.date)) && !((_this$game2 = this.game) !== null && _this$game2 !== void 0 && _this$game2.isLive)) {
          this.game.GameStatus = 3;
          this.gameStatus = 3;
        }
        if (!this.game.timeLeft && external_moment_default()().isBefore(external_moment_default()(this.game.date))) {
          this.game.GameStatus = 1;
          this.gameStatus = 1;
        }
        this.reminderSet = this.game.isReminded;
        if (this.game && this.game.date) {
          this.timerInterval = setInterval(() => {
            const date1 = external_moment_default()(this.game.date);
            const date2 = external_moment_default()(new Date());

            // Get the duration between the two dates
            const durationDiff = Object(external_moment_["duration"])(date1.diff(date2));
            const totalHours = date1.diff(date2, 'hours');

            // Extract hours, minutes, and seconds from the duration
            const minutes = durationDiff.minutes();
            const seconds = durationDiff.seconds();
            if (totalHours < 0 || totalHours > 24) {
              this.hideTimer = true;
            }
            this.timeLeft = `${totalHours} : ${minutes} : ${seconds}`;
          }, 1000);
        }
      }
    },
    closeStreaming() {
      this.showLoadingPlayer = false;
    },
    showChat(chat, value = true) {
      this.activeChat = chat;
      this.isShowChat = value;
    },
    switchChat(chat) {
      this.activeChat = chat;
    },
    async setPrivateChannel(channel) {
      await this.$emit('setLockerRoom');
      this.privateChannel = channel;
    },
    async setReminder() {
      this.isReminderLoading = true;
      try {
        await this.$api.setGameReminder({
          gameID: this.lockerRoom.Game.gameID.toString()
        });
        this.reminderSet = true;
        this.$toast.success(`Thanks for setting a reminder for the upcoming match! We'll send you an email reminder before the match starts!`, {
          duration: 8000,
          position: 'bottom-left',
          className: 'fx1-success',
          iconPack: 'mdi',
          icon: 'check-circle-outline'
        });
        this.$mixpanelClient.trackSetReminder({
          lockerRoom: this.lockerRoom,
          game: this.game
        });
      } catch (error) {
        var _error$response2;
        error === null || error === void 0 ? void 0 : (_error$response2 = error.response) === null || _error$response2 === void 0 ? void 0 : _error$response2.errors.forEach(error => {
          this.$toast.error(error.message, {
            duration: 5000,
            position: 'bottom-left',
            className: 'fx1-success',
            iconPack: 'mdi',
            icon: 'alert-circle-outline'
          });
        });
      }
      this.isReminderLoading = false;
    },
    async unsetReminder() {
      this.isReminderLoading = true;
      try {
        await this.$api.unsetGameReminder({
          gameID: this.lockerRoom.Game.gameID.toString()
        });
        this.reminderSet = false;
        this.$toast.success(`Reminder was removed. We won’t send you a reminder before the match starts.`, {
          duration: 5000,
          position: 'bottom-left',
          className: 'fx1-success',
          iconPack: 'mdi',
          icon: 'check-circle-outline'
        });
      } catch (error) {
        var _error$response3;
        error === null || error === void 0 ? void 0 : (_error$response3 = error.response) === null || _error$response3 === void 0 ? void 0 : _error$response3.errors.forEach(error => {
          this.$toast.error(error.message, {
            duration: 5000,
            position: 'bottom-left',
            className: 'fx1-success',
            iconPack: 'mdi',
            icon: 'alert-circle-outline'
          });
        });
      }
      this.isReminderLoading = false;
    }
  }
});
// CONCATENATED MODULE: ./components/pages/ExploreEvent.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_ExploreEventvue_type_script_lang_js_ = (ExploreEventvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/pages/ExploreEvent.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1144)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pages_ExploreEventvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "4ebde8ec",
  "593a326e"
  
)

/* harmony default export */ var ExploreEvent = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 313:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/create-private.33d0f18.svg";

/***/ }),

/***/ 320:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/EUROPALeague.0e8ac69.svg";

/***/ }),

/***/ 324:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0yMCAxMUg3LjgzTDEzLjQyIDUuNDFMMTIgNEw0IDEyTDEyIDIwTDEzLjQxIDE4LjU5TDcuODMgMTNIMjBWMTFaIiBmaWxsPSJ3aGl0ZSIvPg0KPC9zdmc+DQo="

/***/ }),

/***/ 325:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/bell.cc5e50d.svg";

/***/ }),

/***/ 326:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/calendar.7b8ca8a.svg";

/***/ }),

/***/ 341:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjEiIHZpZXdCb3g9IjAgMCAyMCAyMSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0xMy41MzQ5IDYuOTY0NDdDMTUuNDg3NSA4LjkxNzEgMTUuNDg3NSAxMi4wODI5IDEzLjUzNDkgMTQuMDM1NU02LjQ2MzgyIDE0LjAzNTVDNC41MTExOSAxMi4wODI5IDQuNTExMTkgOC45MTcwNyA2LjQ2MzgyIDYuOTY0NDVNNC4xMDY3OSAxNi4zOTI2QzAuODUyNDIzIDEzLjEzODIgMC44NTI0MjMgNy44NjE4MiA0LjEwNjc5IDQuNjA3NDVNMTUuODkxOSA0LjYwNzQ5QzE5LjE0NjMgNy44NjE4NiAxOS4xNDYzIDEzLjEzODIgMTUuODkxOSAxNi4zOTI2TTExLjY2NiAxMC41QzExLjY2NiAxMS40MjA1IDEwLjkxOTggMTIuMTY2NyA5Ljk5OTM1IDEyLjE2NjdDOS4wNzg4NyAxMi4xNjY3IDguMzMyNjggMTEuNDIwNSA4LjMzMjY4IDEwLjVDOC4zMzI2OCA5LjU3OTUzIDkuMDc4ODcgOC44MzMzNCA5Ljk5OTM1IDguODMzMzRDMTAuOTE5OCA4LjgzMzM0IDExLjY2NiA5LjU3OTUzIDExLjY2NiAxMC41WiIgc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+DQo8L3N2Zz4NCg=="

/***/ }),

/***/ 349:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik00Ljg1NzE0IDEyLjUwMDNMMTYgMTIuNTAwM005LjE0Mjg2IDcuMzU3NDJMNCAxMi41MDAzTDkuMTQyODYgMTcuNjQzMSIgc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPg0KPHBhdGggZD0iTTIwIDE5VjYiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS13aWR0aD0iMS41IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 621:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/Baseball.6800dd1.svg";

/***/ }),

/***/ 622:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/Basketball.cd81528.svg";

/***/ }),

/***/ 623:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/Football.3be7d81.svg";

/***/ }),

/***/ 624:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/Ice-Hockey.a993e84.svg";

/***/ }),

/***/ 625:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0xMiAyMUMxNi45NzA2IDIxIDIxIDE2Ljk3MDYgMjEgMTJDMjEgNy4wMjk0NCAxNi45NzA2IDMgMTIgM0M3LjAyOTQ0IDMgMyA3LjAyOTQ0IDMgMTJDMyAxNi45NzA2IDcuMDI5NDQgMjEgMTIgMjFaIiBzdHJva2U9IndoaXRlIiBzdHJva2Utd2lkdGg9IjEuNSIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2UtbGluZWNhcD0icm91bmQiLz4NCjxwYXRoIGQ9Ik0xNS41NjY3IDExLjIwMjJMMTguMDQ1IDEwLjE1MjJMMTkuMjUzNCA2LjcxODExTTIwLjk1MzEgMTIuNjU0OEwxOC4wNDUgMTAuMTUyMk04LjQzMzI4IDExLjIwMjJMNS45NTUgMTAuMTUyMkw0Ljc0NjU2IDYuNzE4MTFNMy4wNDY4OCAxMi42NTQ4TDUuOTU1IDEwLjE1MjJNMTIgOC4yMTAxNFY1LjUxMTU1TDE1IDMuNTEyOE05IDMuNTEyMzNMMTIgNS41MTE1NU0xNC42MjUgMTVMMTUuOTM3NSAxNy4yNUwxNC42MjUgMjAuNTc4MU0xOS4yNTM0IDE3LjI1SDE2LjAzMTJNOS4zNzUgMTVMOC4wNjI1IDE3LjI1TDkuMzkyMzQgMjAuNjAxNU00Ljc2MzkxIDE3LjI1SDguMDYyNU0xMiA4LjIxMDE0TDguNDMzMjggMTEuMjAyMkw5LjM3NSAxNUgxNC42MjVMMTUuNTY2NyAxMS4yMDIyTDEyIDguMjEwMTRaIiBzdHJva2U9IndoaXRlIiBzdHJva2Utd2lkdGg9IjEuNSIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+DQo8L3N2Zz4NCg=="

/***/ }),

/***/ 626:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCAxOCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik01LjQ4ODg0IDE1LjcyN0gxNS4zNTU4TTUuNDg4ODQgMTUuNzI3VjE5SDE1LjM1NThWMTUuNzI3TTUuNDg4ODQgMTUuNzI3QzIuMTk5ODQgMTMuNTQ2IDAuNTU1ODQ0IDguMDkxIDEuMTAzODQgNi40NTVDMS41NDE4NCA1LjE0NSAzLjQ3ODg0IDUuNTQ1IDQuMzkyODQgNS45MDlDNC4zOTI4NCAyLjA5MSA2LjAzNjg0IDEgMTAuNDIyOCAxQzE0LjgwNTggMSAxNi45OTk4IDIuMDkgMTYuOTk5OCA3LjU0NUMxNi45OTk4IDExLjkwOSAxNS45MDM4IDE0LjgxOCAxNS4zNTU4IDE1LjcyNyIgc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPg0KPC9zdmc+DQo="

/***/ }),

/***/ 655:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/Background.8b6ea62.png";

/***/ }),

/***/ 914:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1142);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("f2c6ecb8", content, true, context)
};

/***/ }),

/***/ 915:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1145);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("4f6cc0e4", content, true, context)
};

/***/ }),

/***/ 992:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/ExploreEvent/Footer.vue?vue&type=template&id=7320054d&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"explore-event-footer",class:[_vm.showChat ? 'chat-active' : '']},[_vm._ssrNode("<div class=\"left\" data-v-7320054d><b data-v-7320054d><span data-v-7320054d>"+_vm._ssrEscape(_vm._s(_vm.game.leagueCode))+"</span><span data-v-7320054d>"+_vm._ssrEscape(": "+_vm._s(_vm.game.team1Name || _vm.game.team1DisplayName || _vm.game.team1Nickname || _vm.game.team1City)+" vs "+_vm._s(_vm.game.team2Name || _vm.game.team2DisplayName || _vm.game.team2Nickname || _vm.game.team2City))+"</span></b><div class=\"date__container\" data-v-7320054d><img"+(_vm._ssrAttr("src",__webpack_require__(326)))+" data-v-7320054d><p data-v-7320054d>"+_vm._ssrEscape(_vm._s(_vm.gameDate))+"</p></div></div>"+((!_vm.lockerRoomLoading && !_vm.insideNavigation && !_vm.showChat)?("<div class=\"chat\" data-v-7320054d><img"+(_vm._ssrAttr("src",__webpack_require__(313)))+" data-v-7320054d>"+((_vm.privateSlug)?("<p data-v-7320054d>"+_vm._ssrEscape("Private group: "+_vm._s(_vm.privateSlug))+"</p>"):("<p data-v-7320054d>Create a private group</p>"))+"</div>"):"<!---->")+((_vm.insideNavigation && !_vm.privateSlug && !_vm.lockerRoomPrivateChat && !_vm.showChat)?("<div class=\"chat\" data-v-7320054d><img"+(_vm._ssrAttr("src",__webpack_require__(313)))+" data-v-7320054d><p data-v-7320054d>Create a private group</p></div>"):"<!---->"))])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/ExploreEvent/Footer.vue?vue&type=template&id=7320054d&scoped=true&lang=pug&

// EXTERNAL MODULE: external "moment"
var external_moment_ = __webpack_require__(215);
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_);

// EXTERNAL MODULE: external "vuex-map-fields"
var external_vuex_map_fields_ = __webpack_require__(2);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/ExploreEvent/Footer.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ var Footervue_type_script_lang_js_ = ({
  name: 'XOExploreEventFooter',
  props: {
    game: {
      type: Object,
      default: () => {}
    },
    showChat: {
      type: Boolean
    },
    privateChannel: {
      type: Object,
      default: () => {}
    },
    insideNavigation: {
      type: Boolean,
      default: false
    }
  },
  data() {
    var _this$privateChannel;
    return {
      message: null,
      privateSlug: (_this$privateChannel = this.privateChannel) === null || _this$privateChannel === void 0 ? void 0 : _this$privateChannel.slug
    };
  },
  computed: {
    ...Object(external_vuex_map_fields_["mapFields"])('locker-room', ['lockerRoomLoading', 'lockerRoomPrivateChat']),
    gameDate() {
      return external_moment_default()(this.game.date).local().format('DD MMMM YYYY');
    }
  },
  watch: {
    privateChannel: {
      handler(newV) {
        if (newV) {
          this.privateSlug = newV.slug;
        }
      }
    }
  }
});
// CONCATENATED MODULE: ./components/organisms/ExploreEvent/Footer.vue?vue&type=script&lang=js&
 /* harmony default export */ var ExploreEvent_Footervue_type_script_lang_js_ = (Footervue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/organisms/ExploreEvent/Footer.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1141)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  ExploreEvent_Footervue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "7320054d",
  "af096a0a"
  
)

/* harmony default export */ var Footer = __webpack_exports__["a"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=76.js.map
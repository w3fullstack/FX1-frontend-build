exports.ids = [94];
exports.modules = {

/***/ 1226:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_TicketCountSection_vue_vue_type_style_index_0_id_52983d1e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(956);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_TicketCountSection_vue_vue_type_style_index_0_id_52983d1e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_TicketCountSection_vue_vue_type_style_index_0_id_52983d1e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_TicketCountSection_vue_vue_type_style_index_0_id_52983d1e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_TicketCountSection_vue_vue_type_style_index_0_id_52983d1e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1227:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(24);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(613);
var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(617);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".win-chance[data-v-52983d1e]{min-height:70vh!important}@media screen and (max-width:650px){.win-chance[data-v-52983d1e]{min-height:77vh!important}}@media screen and (max-width:389px){.win-chance[data-v-52983d1e]{min-height:100vh!important}}.ticketcount-section[data-v-52983d1e]{padding:150px 0 0;position:relative;z-index:99}@media screen and (max-width:650px){.ticketcount-section[data-v-52983d1e]{padding-top:100px}}.ticketcount-section .coins[data-v-52983d1e]{position:absolute;background-position:50%;background-repeat:no-repeat;width:100%;overflow:hidden;z-index:0;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");height:160%;top:-32%;left:39%;zoom:.6}@media screen and (max-width:1650px){.ticketcount-section .coins[data-v-52983d1e]{left:36%}}@media screen and (max-width:1340px){.ticketcount-section .coins[data-v-52983d1e]{left:32%}}@media screen and (max-width:1210px){.ticketcount-section .coins[data-v-52983d1e]{top:-43%;left:31%}}@media screen and (max-width:900px){.ticketcount-section .coins[data-v-52983d1e]{left:26%}}@media screen and (max-width:650px){.ticketcount-section .coins[data-v-52983d1e]{left:0;top:-10%}}.ticketcount-section .ticket-section[data-v-52983d1e]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ");background-position:50%;background-repeat:no-repeat;overflow:hidden;-webkit-backdrop-filter:blur(30px);backdrop-filter:blur(30px);width:100%;height:448px;padding:72px,371px,72px,60px;border-radius:20px;border:1px solid #00d8f9}.ticketcount-section .token-p4[data-v-52983d1e]{font-size:75px!important;font-weight:400;line-height:80px}.ticketcount-section .frame[data-v-52983d1e]{position:absolute;top:72px;left:60px}.ticketcount-section .connect-wallet[data-v-52983d1e]:hover{cursor:pointer}.ticketcount-section .actions[data-v-52983d1e]{margin:50px 0 25px}.ticketcount-section .actions .button[data-v-52983d1e]{width:235px;height:82px;text-transform:uppercase}.ticketcount-section .action-button[data-v-52983d1e]{position:absolute;width:100%;top:300px;left:60px}.ticketcount-section .action-button .connect-wallet[data-v-52983d1e]{padding:24px 32px;border:1px solid #fff;border-radius:5px;background:rgba(0,0,0,.1);-webkit-backdrop-filter:blur(30px);backdrop-filter:blur(30px);box-shadow:inset 0 1px 30px -5px rgba(227,222,255,.07),inset 0 4px 18px 0 rgba(146,156,210,.1),inset 0 98px 100px -48px rgba(170,188,204,.2);height:76px;width:296px;display:inline-block;align-items:center}.ticketcount-section .action-button .connect-wallet .right img[data-v-52983d1e]{margin-top:4px;width:25px!important}.ticketcount-section .token-h1[data-v-52983d1e]{-webkit-text-stroke:0;font-weight:300!important;text-shadow:none!important}.ticketcount-section .token-h2[data-v-52983d1e]{font-weight:500;color:#fff;font-size:56px}.ticketcount-section .row[data-v-52983d1e]{align-items:center}@media screen and (max-width:500px){.ticketcount-section .row[data-v-52983d1e]{flex-direction:column}}.ticketcount-section .left[data-v-52983d1e]{float:left!important;max-width:100%!important}.ticketcount-section .right[data-v-52983d1e]{float:right!important;max-width:100%!important}.ticketcount-section .jackpot-box[data-v-52983d1e],.ticketcount-section .jackpot-box-2[data-v-52983d1e]{top:35%;right:0;position:absolute;width:291px;height:188px;padding:16px 28px;align-items:center;text-align:center;border-radius:12px;border:1px solid #fff;background:rgba(0,0,0,.01);box-shadow:inset 0 1px 30px -5px rgba(227,222,255,.07),inset 0 4px 18px 0 rgba(146,156,210,.1),inset 0 98px 100px -48px rgba(170,188,204,.2);-webkit-backdrop-filter:blur(30px);backdrop-filter:blur(30px)}.ticketcount-section .jackpot-box-2[data-v-52983d1e]{margin-right:15px}@media screen and (max-width:1210px){.ticketcount-section .jackpot-box-2[data-v-52983d1e]{top:26%}}@media screen and (max-width:650px){.ticketcount-section .jackpot-box-2[data-v-52983d1e]{top:56%;height:150px!important;left:0;right:0;margin-left:auto;margin-right:auto}}.ticketcount-section .jackpot-box[data-v-52983d1e]{right:290px}.ticketcount-section .score-board[data-v-52983d1e]{margin-top:20px;width:100%;text-align:center;display:flex}.ticketcount-section .score-board .score[data-v-52983d1e]{width:33.33%}@media screen and (max-width:1215px){.ticketcount-section .token-p4[data-v-52983d1e]{font-size:48px!important;line-height:60px}}@media screen and (max-width:650px){.ticketcount-section .token-p4[data-v-52983d1e]{font-size:36px!important;line-height:40px}.ticketcount-section .ticket-count[data-v-52983d1e]{text-align:center}.ticketcount-section .actions[data-v-52983d1e]{margin-top:50px!important}.ticketcount-section .margin-bottom-1[data-v-52983d1e]{margin-bottom:25px!important}}@media screen and (max-width:430px){.ticketcount-section .token-p4[data-v-52983d1e]{font-size:28px!important}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1404:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Jackpot/TicketCountSection.vue?vue&type=template&id=52983d1e&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"root"},[_vm._ssrNode("<div class=\"ticketcount-section row win-chance\" data-v-52983d1e><div class=\"container token-container\" data-v-52983d1e><div class=\"row justify-between\" data-v-52983d1e><div class=\"col ticket-count\" data-v-52983d1e><div class=\"coins\" data-v-52983d1e></div><div class=\"jackpot-box-2\" data-v-52983d1e><div class=\"token-p3 grey-text\" data-v-52983d1e>Jackpot #3</div><div class=\"score-board\" data-v-52983d1e><div class=\"score\" data-v-52983d1e><div class=\"token-h2\" data-v-52983d1e>10</div><div class=\"token-p3 grey-text\" data-v-52983d1e>NOV</div></div><div class=\"score\" data-v-52983d1e><div class=\"token-h2\" data-v-52983d1e>-</div><div class=\"token-p3 grey-text\" data-v-52983d1e> </div></div><div class=\"score\" data-v-52983d1e><div class=\"token-h2\" data-v-52983d1e>11</div><div class=\"token-p3 grey-text\" data-v-52983d1e>DEC</div></div></div></div><div class=\"token-p4\" data-v-52983d1e>Increase your chances<br data-v-52983d1e>to win now!</div><div class=\"margin-bottom-1\" data-v-52983d1e></div><div class=\"token-p grey-text\" data-v-52983d1e>Don’t wait, entries close on 8th of November.</div><div class=\"actions\" data-v-52983d1e><a href=\"https://app.uniswap.org/swap?outputCurrency=0xC5190E7FEC4d97a3a3b1aB42dfedac608e2d0793\" target=\"_blank\" class=\"button jackpot-button\" data-v-52983d1e>Buy $FX1</a></div></div></div></div></div>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Jackpot/TicketCountSection.vue?vue&type=template&id=52983d1e&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Jackpot/TicketCountSection.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var TicketCountSectionvue_type_script_lang_js_ = ({
  name: 'TicketCountSection'
});
// CONCATENATED MODULE: ./components/molecules/Jackpot/TicketCountSection.vue?vue&type=script&lang=js&
 /* harmony default export */ var Jackpot_TicketCountSectionvue_type_script_lang_js_ = (TicketCountSectionvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/Jackpot/TicketCountSection.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1226)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Jackpot_TicketCountSectionvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "52983d1e",
  "fd0830be"
  
)

/* harmony default export */ var TicketCountSection = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 613:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/coins-group.4f6c463.png";

/***/ }),

/***/ 617:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/tc-back.c145320.png";

/***/ }),

/***/ 956:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1227);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("d0dd252e", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=94.js.map
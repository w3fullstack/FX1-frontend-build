exports.ids = [74];
exports.modules = {

/***/ 1258:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ProgressUpdates_vue_vue_type_style_index_0_id_248076be_prod_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(972);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ProgressUpdates_vue_vue_type_style_index_0_id_248076be_prod_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ProgressUpdates_vue_vue_type_style_index_0_id_248076be_prod_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ProgressUpdates_vue_vue_type_style_index_0_id_248076be_prod_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ProgressUpdates_vue_vue_type_style_index_0_id_248076be_prod_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1259:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".home-after-banner-progress[data-v-248076be]{position:absolute;top:15%;left:-1%;padding:18px 12px;border-radius:20px;border:.5px solid hsla(0,0%,100%,.4);background:hsla(0,0%,100%,.07);box-shadow:5px 6px 18px 0 rgba(0,0,0,.1),22px 24px 32px 0 rgba(0,0,0,.09),49px 53px 43px 0 rgba(0,0,0,.05),87px 94px 51px 0 rgba(0,0,0,.01),136px 147px 56px 0 transparent;-webkit-backdrop-filter:blur(5px);backdrop-filter:blur(5px);flex-wrap:nowrap;overflow:hidden;width:181px;height:297px}.home-after-banner-progress .group[data-v-248076be]{padding-bottom:12px}.home-after-banner-progress .group[data-v-248076be]:last-child{padding-bottom:0}.home-after-banner-progress .group .row[data-v-248076be]{flex-flow:row;align-items:stretch;grid-gap:4.5px;gap:4.5px}.home-after-banner-progress .group .row .txt-label[data-v-248076be]{font-size:8px;line-height:1.2;font-weight:300}.home-after-banner-progress .group .row .light[data-v-248076be]{font-size:7px;line-height:1;font-weight:100}.home-after-banner-progress .group .row .epic[data-v-248076be]{font-size:7px;line-height:1;font-weight:300;background:#f85454;border-radius:8px;padding:2px;width:-moz-fit-content;width:fit-content}.home-after-banner-progress .group .row .txt-time[data-v-248076be]{font-size:7px;line-height:1;font-weight:300;color:#94a6aa}.home-after-banner-progress .group .row img[data-v-248076be]{width:14px;height:14px}.home-after-banner-progress .group .row .dot[data-v-248076be]{min-width:8px;min-height:8px;border-radius:50%;background:#385960}.home-after-banner-progress .group .row .icon-img[data-v-248076be]{display:flex;flex-flow:column;align-items:center;justify-content:flex-start;width:14px}.home-after-banner-progress .group .row .icon-img .vertical-line[data-v-248076be]{width:1px;flex:1;min-height:100%;background:#385960}.home-after-banner-progress .group .row .detail[data-v-248076be]{grid-gap:4.5px;gap:4.5px}.home-after-banner-progress .group .row .detail.hight-light[data-v-248076be]{background:#6046bf;border-radius:6px;padding:4px;flex:1}@media screen and (max-width:1439px){.home-after-banner-progress[data-v-248076be]{width:167px;height:272px}}@media screen and (max-width:1023px){.home-after-banner-progress[data-v-248076be]{width:123px;height:200px;top:36%;left:0}}@media screen and (max-width:767px){.home-after-banner-progress[data-v-248076be]{width:127px;height:207px;left:0;top:85px}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1418:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/v2/Home/AfterBanner/ProgressUpdates.vue?vue&type=template&id=248076be&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"home-after-banner-progress flex-column"},[_vm._ssrNode((_vm._ssrList((_vm.progressData),function(group,index){return ("<div class=\"group\" data-v-248076be><div class=\"row\" data-v-248076be><div class=\"icon-img\" data-v-248076be>"+((group.icon)?("<img"+(_vm._ssrAttr("src",__webpack_require__(669)("./" + (group.icon) + ".svg")))+" data-v-248076be>"):("<div class=\"dot\" data-v-248076be></div>"))+"<div class=\"vertical-line\" data-v-248076be></div></div><div"+(_vm._ssrClass("detail flex-column",{ 'hight-light': group.light }))+" data-v-248076be>"+((group.epic)?("<span class=\"epic\" data-v-248076be>"+_vm._ssrEscape(_vm._s(group.epic))+"</span>"):"<!---->")+((group.light)?("<span class=\"light\" data-v-248076be>"+_vm._ssrEscape(_vm._s(group.light))+"</span>"):"<!---->")+"<span class=\"txt-label\" data-v-248076be>"+_vm._ssrEscape(_vm._s(group.label))+"</span><span class=\"txt-time\" data-v-248076be>"+_vm._ssrEscape(_vm._s(group.time))+"</span></div></div></div>")})))])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/v2/Home/AfterBanner/ProgressUpdates.vue?vue&type=template&id=248076be&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/v2/Home/AfterBanner/ProgressUpdates.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var ProgressUpdatesvue_type_script_lang_js_ = ({
  name: 'HomeAfterBannerProgressUpdates',
  data() {
    return {
      progressData: [{
        epic: 'EPIC',
        time: '12:23:12',
        label: 'New game excitement level!',
        icon: 'fluent-emoji_star-struck'
      }, {
        time: '12:23:01',
        label: 'Wilmer Flores flied out to RF.',
        icon: 'team-icon'
      }, {
        time: '12:23:12',
        label: 'Reached on error',
        icon: 'fluent-emoji-fire',
        light: 'HIGHLIGHT'
      }, {
        time: '12:20:01',
        label: 'Single to SS.Sandoval to 2B.'
      }, {
        time: '12:23:12',
        label: 'Wilmer Flores flied out to RF.',
        icon: 'team-icon',
        light: 'HIGHLIGHT'
      }, {
        time: '12:23:01',
        label: 'Wilmer Flores flied out to RF.',
        icon: 'team-icon'
      }, {
        epic: 'EPIC',
        time: '12:23:12',
        label: 'New game excitement level!',
        icon: 'fluent-emoji_star-struck'
      }]
    };
  }
});
// CONCATENATED MODULE: ./components/molecules/v2/Home/AfterBanner/ProgressUpdates.vue?vue&type=script&lang=js&
 /* harmony default export */ var AfterBanner_ProgressUpdatesvue_type_script_lang_js_ = (ProgressUpdatesvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/v2/Home/AfterBanner/ProgressUpdates.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1258)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  AfterBanner_ProgressUpdatesvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "248076be",
  "33e3ba63"
  
)

/* harmony default export */ var ProgressUpdates = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 451:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/appstore.2854c99.svg";

/***/ }),

/***/ 452:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/googleplay.9921262.svg";

/***/ }),

/***/ 476:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDk0IiBoZWlnaHQ9IjE4OSIgdmlld0JveD0iMCAwIDQ5NCAxODkiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxnIG9wYWNpdHk9IjAuMDgiPgo8cGF0aCBkPSJNNDI5LjgwOSA3NS43NjQxSDQ2Ni4yMkw0MzYuMTI5IDIzMi41MTZINTA1LjkzOEw1NDYuODYyIDIwLjM4NTNINDQwLjM0TDQyOS44MDkgNzUuNzY0MVoiIGZpbGw9IiNGNzU0NTQiLz4KPHBhdGggZD0iTTQwMi4wNTkgMjMyLjgxOUgzMDkuMjcyTDI4Ny4yMTEgMTg2LjkzOUwyNTAuNjAzIDIzMi44MTlIMTU3LjMyOEwyNDkuMzk1IDEyNC4xNkwyMjkuMDc5IDgzLjQzNjFIMTQ2LjE3MUwxNDEuOTQ0IDEwNC45ODhIMjE5LjM2NUwyMDYuOTg4IDE2Ny45NDVIMTI5LjU1NUwxMTYuNjEzIDIzMi44MTlIMzguMTY4TDgwLjExMjggMjAuNDcxOUgyODguMjU3TDMwNi42NTQgNjEuNDAxN0wzMzguMyAyMC40NzE5SDQzMi4xMDNMMzQ2LjM0MSAxMjIuODI5TDQwMi4wNTkgMjMyLjgxOVpNMzE3LjQwNCAyMTkuOTM0SDM4MS4wNTJMMzMwLjk3MiAxMjEuMDc3TDQwNC40NjYgMzMuMzYwOUgzNDQuNjVMMzAzLjY5OSA4Ni4zMjQ1TDI3OS44OTEgMzMuMzU2Mkg5MC43MzM1TDUzLjg5IDIxOS45MzRIMTA2LjAxMkwxMTguOTU1IDE1NS4wNjFIMTk2LjM0OEwyMDMuNjYyIDExNy44NjVIMTI2LjI1OUwxMzUuNTM5IDcwLjU0NDhIMjM3LjA4MUwyNjQuNzM3IDEyNS45OTlMMTg1LjE1NyAyMTkuOTM3SDI0NC4zODFMMjg5Ljk0MyAxNjIuODFMMzE3LjQwNCAyMTkuOTM0WiIgZmlsbD0id2hpdGUiLz4KPC9nPgo8L3N2Zz4K"

/***/ }),

/***/ 477:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/circles-and-light-1.c93372d.svg";

/***/ }),

/***/ 478:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/circles-and-light-2.2dbec37.svg";

/***/ }),

/***/ 479:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/circles-and-light-mobile.339c3d1.svg";

/***/ }),

/***/ 480:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/circles-and-light.8a6707c.svg";

/***/ }),

/***/ 481:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTkiIGhlaWdodD0iMTgiIHZpZXdCb3g9IjAgMCAxOSAxOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTE0LjUgNC44MDc1TDEzLjQ0MjUgMy43NUw5LjI1IDcuOTQyNUw1LjA1NzUgMy43NUw0IDQuODA3NUw4LjE5MjUgOUw0IDEzLjE5MjVMNS4wNTc1IDE0LjI1TDkuMjUgMTAuMDU3NUwxMy40NDI1IDE0LjI1TDE0LjUgMTMuMTkyNUwxMC4zMDc1IDlMMTQuNSA0LjgwNzVaIiBmaWxsPSJ3aGl0ZSIvPgo8L3N2Zz4K"

/***/ }),

/***/ 482:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMjIiIHZpZXdCb3g9IjAgMCAxOCAyMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTYgMTAuNTAwMUw4IDEyLjUwMDFMMTIuNSA4LjAwMDExTTE3IDExLjAwMDFDMTcgMTUuOTA4NiAxMS42NDYgMTkuNDc4NSA5LjY5Nzk5IDIwLjYxNUM5LjQ3NjYgMjAuNzQ0MiA5LjM2NTkgMjAuODA4NyA5LjIwOTY4IDIwLjg0MjJDOS4wODg0NCAyMC44NjgyIDguOTExNTYgMjAuODY4MiA4Ljc5MDMyIDIwLjg0MjJDOC42MzQxIDIwLjgwODcgOC41MjM0IDIwLjc0NDIgOC4zMDIwMSAyMC42MTVDNi4zNTM5NiAxOS40Nzg1IDEgMTUuOTA4NiAxIDExLjAwMDFWNi4yMTc3MkMxIDUuNDE4MiAxIDUuMDE4NDUgMS4xMzA3NiA0LjY3NDgyQzEuMjQ2MjcgNC4zNzEyNiAxLjQzMzk4IDQuMTAwMzkgMS42Nzc2NiAzLjg4NTY0QzEuOTUzNSAzLjY0MjU1IDIuMzI3OCAzLjUwMjE5IDMuMDc2NCAzLjIyMTQ2TDguNDM4MiAxLjIxMDc5QzguNjQ2MSAxLjEzMjgzIDguNzUwMDUgMS4wOTM4NSA4Ljg1Njk4IDEuMDc4MzlDOC45NTE4NCAxLjA2NDY5IDkuMDQ4MTYgMS4wNjQ2OSA5LjE0MzAyIDEuMDc4MzlDOS4yNDk5NSAxLjA5Mzg1IDkuMzUzOSAxLjEzMjgzIDkuNTYxOCAxLjIxMDc5TDE0LjkyMzYgMy4yMjE0NkMxNS42NzIyIDMuNTAyMTkgMTYuMDQ2NSAzLjY0MjU1IDE2LjMyMjMgMy44ODU2NEMxNi41NjYgNC4xMDAzOSAxNi43NTM3IDQuMzcxMjYgMTYuODY5MiA0LjY3NDgyQzE3IDUuMDE4NDUgMTcgNS40MTgyIDE3IDYuMjE3NzJWMTEuMDAwMVoiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+Cjwvc3ZnPgo="

/***/ }),

/***/ 484:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDU1IiBoZWlnaHQ9Ijg2NiIgdmlld0JveD0iMCAwIDQ1NSA4NjYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxnIGZpbHRlcj0idXJsKCNmaWx0ZXIwX2ZfOTY5Ml81MjQ4MSkiPgo8cGF0aCBkPSJNNzUuMzA3MSAyMDEuNzFDMTQ1LjA1OSAxOTYuNjI5IDI0NC4zMiAyMTEuNyAyNTMuNjkxIDM0MC4zNDFDMjYzLjA2MiA0NjguOTgzIDEzNi4zNzIgNjYwLjQ4NiA2Ni42MTk4IDY2NS41NjdDLTMuMTMyNTQgNjcwLjY0OCAtMTI1LjM3NCA0NzcuMTA5IC0xMzQuNzQ1IDM0OC40NjdDLTE0NC4xMTcgMjE5LjgyNSA1LjU1NDc4IDIwNi43OTEgNzUuMzA3MSAyMDEuNzFaIiBmaWxsPSIjMDI4Q0E3IiBmaWxsLW9wYWNpdHk9IjAuMiIvPgo8L2c+CjxkZWZzPgo8ZmlsdGVyIGlkPSJmaWx0ZXIwX2ZfOTY5Ml81MjQ4MSIgeD0iLTMzNS4xNjYiIHk9IjAuODgzMTQ4IiB3aWR0aD0iNzg5LjM1IiBoZWlnaHQ9Ijg2NC43ODIiIGZpbHRlclVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgY29sb3ItaW50ZXJwb2xhdGlvbi1maWx0ZXJzPSJzUkdCIj4KPGZlRmxvb2QgZmxvb2Qtb3BhY2l0eT0iMCIgcmVzdWx0PSJCYWNrZ3JvdW5kSW1hZ2VGaXgiLz4KPGZlQmxlbmQgbW9kZT0ibm9ybWFsIiBpbj0iU291cmNlR3JhcGhpYyIgaW4yPSJCYWNrZ3JvdW5kSW1hZ2VGaXgiIHJlc3VsdD0ic2hhcGUiLz4KPGZlR2F1c3NpYW5CbHVyIHN0ZERldmlhdGlvbj0iMTAwIiByZXN1bHQ9ImVmZmVjdDFfZm9yZWdyb3VuZEJsdXJfOTY5Ml81MjQ4MSIvPgo8L2ZpbHRlcj4KPC9kZWZzPgo8L3N2Zz4K"

/***/ }),

/***/ 500:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAxNiAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0wIDBIMTZWMjRDMTIuMzUyOCAxMC43NjUzIDguODIxNzYgNS40NzI4OCAwIDBaIiBmaWxsPSIjMDgyNTJDIi8+DQo8L3N2Zz4NCg=="

/***/ }),

/***/ 501:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/avatar-1.4e1682c.svg";

/***/ }),

/***/ 502:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/avatar-2.88f3eaf.svg";

/***/ }),

/***/ 503:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/avatar-3.858df45.svg";

/***/ }),

/***/ 504:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/avatar-4.d86bf38.svg";

/***/ }),

/***/ 505:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/avatar-5.5ea9254.svg";

/***/ }),

/***/ 506:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/avatar-6.3e65472.svg";

/***/ }),

/***/ 507:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/avatar-7.f372fb8.svg";

/***/ }),

/***/ 508:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/avatar-8.99b5ca5.svg";

/***/ }),

/***/ 509:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/avatar.efc084d.svg";

/***/ }),

/***/ 510:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/battle.3057774.svg";

/***/ }),

/***/ 511:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/broadcst-1.7b3e47f.svg";

/***/ }),

/***/ 512:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/broadcst-2.586783b.svg";

/***/ }),

/***/ 513:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/chat-with.d58f9fa.svg";

/***/ }),

/***/ 514:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/chat.e4eafa6.svg";

/***/ }),

/***/ 515:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/earn.e3ca1d8.svg";

/***/ }),

/***/ 516:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/epic-img.52eb79f.svg";

/***/ }),

/***/ 517:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/fluent-emoji-fire.b5914e0.svg";

/***/ }),

/***/ 518:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/fluent-emoji_star-struck.689d153.svg";

/***/ }),

/***/ 519:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/group.5673864.svg";

/***/ }),

/***/ 520:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/medal.8d2e686.svg";

/***/ }),

/***/ 521:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/microphone-gray.23f1591.svg";

/***/ }),

/***/ 522:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/online-purple.2435baa.svg";

/***/ }),

/***/ 523:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/participants-vector.58b93c9.svg";

/***/ }),

/***/ 524:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/participants.d1c3b8d.svg";

/***/ }),

/***/ 525:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/peace.e50fb08.svg";

/***/ }),

/***/ 526:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/person.fafc606.svg";

/***/ }),

/***/ 527:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/shutterstock.058442b.svg";

/***/ }),

/***/ 528:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/stadium.180972e.svg";

/***/ }),

/***/ 529:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/star-struck.de10147.svg";

/***/ }),

/***/ 530:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0yMS42NTY4IDEwLjM0MzFDMjQuNzgxIDEzLjQ2NzMgMjQuNzgxIDE4LjUzMjYgMjEuNjU2OCAyMS42NTY4TTEwLjM0MzEgMjEuNjU2OEM3LjIxODkxIDE4LjUzMjYgNy4yMTg5MSAxMy40NjczIDEwLjM0MzEgMTAuMzQzMU02LjU3MTg3IDI1LjQyODFDMS4zNjQ4OCAyMC4yMjExIDEuMzY0ODggMTEuNzc4OSA2LjU3MTg3IDYuNTcxOU0yNS40MjgxIDYuNTcxOTZDMzAuNjM1IDExLjc3OSAzMC42MzUgMjAuMjIxMiAyNS40MjgxIDI1LjQyODFNMTguNjY2NiAxNkMxOC42NjY2IDE3LjQ3MjcgMTcuNDcyNyAxOC42NjY3IDE2IDE4LjY2NjdDMTQuNTI3MiAxOC42NjY3IDEzLjMzMzMgMTcuNDcyNyAxMy4zMzMzIDE2QzEzLjMzMzMgMTQuNTI3MiAxNC41MjcyIDEzLjMzMzMgMTYgMTMuMzMzM0MxNy40NzI3IDEzLjMzMzMgMTguNjY2NiAxNC41MjcyIDE4LjY2NjYgMTZaIiBzdHJva2U9IiMwODI1MkMiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+DQo8L3N2Zz4NCg=="

/***/ }),

/***/ 531:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/t-shirt.0182b58.svg";

/***/ }),

/***/ 532:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/team-icon.750127f.svg";

/***/ }),

/***/ 533:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/team-supporter.1459339.svg";

/***/ }),

/***/ 534:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/teams-scores.6f2f292.svg";

/***/ }),

/***/ 535:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/trending.eca8bd1.svg";

/***/ }),

/***/ 669:
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./FX1_Logo-1.svg": 476,
	"./ambassador/beak.svg": 500,
	"./appstore.svg": 451,
	"./avatar-1.svg": 501,
	"./avatar-2.svg": 502,
	"./avatar-3.svg": 503,
	"./avatar-4.svg": 504,
	"./avatar-5.svg": 505,
	"./avatar-6.svg": 506,
	"./avatar-7.svg": 507,
	"./avatar-8.svg": 508,
	"./avatar.svg": 509,
	"./battle.svg": 510,
	"./broadcst-1.svg": 511,
	"./broadcst-2.svg": 512,
	"./chat-with.svg": 513,
	"./chat.svg": 514,
	"./circles-and-light-1.svg": 477,
	"./circles-and-light-2.svg": 478,
	"./circles-and-light-mobile.svg": 479,
	"./circles-and-light.svg": 480,
	"./close-icon_24px.svg": 481,
	"./earn.svg": 515,
	"./epic-img.svg": 516,
	"./fluent-emoji-fire.svg": 517,
	"./fluent-emoji_star-struck.svg": 518,
	"./googleplay.svg": 452,
	"./gradient-1.svg": 484,
	"./group.svg": 519,
	"./medal.svg": 520,
	"./microphone-gray.svg": 521,
	"./online-purple.svg": 522,
	"./participants-vector.svg": 523,
	"./participants.svg": 524,
	"./peace.svg": 525,
	"./person.svg": 526,
	"./security-icon.svg": 482,
	"./shutterstock.svg": 527,
	"./stadium.svg": 528,
	"./star-struck.svg": 529,
	"./stream-gray.svg": 530,
	"./t-shirt.svg": 531,
	"./team-icon.svg": 532,
	"./team-supporter.svg": 533,
	"./teams-scores.svg": 534,
	"./trending.svg": 535
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 669;

/***/ }),

/***/ 972:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1259);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("4469ed7e", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=74.js.map
exports.ids = [104];
exports.modules = {

/***/ 1234:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WhyFx1Section_vue_vue_type_style_index_0_id_12983800_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(960);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WhyFx1Section_vue_vue_type_style_index_0_id_12983800_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WhyFx1Section_vue_vue_type_style_index_0_id_12983800_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WhyFx1Section_vue_vue_type_style_index_0_id_12983800_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WhyFx1Section_vue_vue_type_style_index_0_id_12983800_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1235:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".token-why-fx1-section[data-v-12983800]{width:100%;position:relative;overflow:hidden;padding:300px 0 150px;z-index:2}.token-why-fx1-section[data-v-12983800] .top-margin-a{margin-top:25px}.token-why-fx1-section[data-v-12983800] .top-margin-b{margin-top:230px}.token-why-fx1-section[data-v-12983800] .left-side{padding-right:20%}@media screen and (max-width:1729px){.token-why-fx1-section[data-v-12983800] .left-side{padding-right:10%}}.token-why-fx1-section[data-v-12983800] .right-side{position:relative}.token-why-fx1-section[data-v-12983800] .right-side img{top:-15%;right:0;position:absolute;min-width:750px}@media screen and (max-width:1880px){.token-why-fx1-section[data-v-12983800] .right-side img{right:-10%;min-width:700px}}@media screen and (max-width:1800px){.token-why-fx1-section[data-v-12983800] .right-side img{right:-10%;min-width:700px}}@media screen and (max-width:1750px){.token-why-fx1-section[data-v-12983800] .right-side img{top:-12%;right:-15%}}@media screen and (max-width:1729px){.token-why-fx1-section[data-v-12983800] .right-side img{top:-10%;right:-25%;min-width:750px}}@media screen and (max-width:1680px){.token-why-fx1-section[data-v-12983800] .right-side img{top:-7%;right:-25%;min-width:700px}}@media screen and (max-width:1533px){.token-why-fx1-section[data-v-12983800] .right-side img{top:-4%;right:-30%;min-width:700px}}@media screen and (max-width:1461px){.token-why-fx1-section[data-v-12983800] .right-side img{top:-2%;right:-36%;min-width:700px}}@media screen and (max-width:1021px){.token-why-fx1-section[data-v-12983800] .right-side{text-align:center!important}.token-why-fx1-section[data-v-12983800] img{margin-top:0!important;top:0!important;left:0!important;right:0!important;position:relative!important;min-width:100%!important;width:100%!important}}@media screen and (max-width:904px){.token-why-fx1-section[data-v-12983800] img{margin-top:50px!important}}@media screen and (max-width:500px){.token-why-fx1-section[data-v-12983800]{padding:100px 0 50px}.token-why-fx1-section[data-v-12983800] .right-side{text-align:center!important}.token-why-fx1-section[data-v-12983800] img{margin-top:100px!important;top:0!important;left:0!important;right:0!important;position:relative!important;min-width:80%!important;width:80%!important}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1407:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/WhyFx1Section.vue?vue&type=template&id=12983800&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"token-why-fx1-section row",attrs:{"id":"whyfx1"}},[_vm._ssrNode("<div class=\"container token-container\" data-v-12983800><div class=\"row\" data-v-12983800><div class=\"col left-side\" data-v-12983800><h1 data-v-12983800>Why FX1 Sports</h1><div class=\"top-margin-a\" data-v-12983800></div><p class=\"token-p\" data-v-12983800>We believe how we consume and interact with sports online is changing forever. As live streaming continues to explode we are entering into a new era of fandom for professional sports where watching sports online should be a community-driven, fun and engaging experience.</p><div class=\"top-margin-a\" data-v-12983800></div><p class=\"token-p\" data-v-12983800>FX1 is on a mission to redefine the way you consume live games, providing an unparalleled experience like never before. With our cutting-edge proprietary A.I. technology, we strive to lead the industry in extracting and presenting real-time statistics and data from sporting events in a groundbreaking manner.</p><div class=\"top-margin-a\" data-v-12983800></div><p class=\"token-p\" data-v-12983800>At FX1 you’ll find real-time game predictions, interactive play-by-play, player insights and A.I. generated sports commentators. One of the best things is that when you invite your friends, you have the opportunity to share in revenue.</p><div class=\"top-margin-a\" data-v-12983800></div><p class=\"token-p\" data-v-12983800>In time, we aim to be the one place to watch all sports online, anywhere, anytime.</p></div><div class=\"col right-side\" data-v-12983800><img"+(_vm._ssrAttr("src",__webpack_require__(645)))+" alt=\"Why FX1\" data-v-12983800></div></div></div>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Token/WhyFx1Section.vue?vue&type=template&id=12983800&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/WhyFx1Section.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var WhyFx1Sectionvue_type_script_lang_js_ = ({
  name: 'WhyFx1Section'
});
// CONCATENATED MODULE: ./components/molecules/Token/WhyFx1Section.vue?vue&type=script&lang=js&
 /* harmony default export */ var Token_WhyFx1Sectionvue_type_script_lang_js_ = (WhyFx1Sectionvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/Token/WhyFx1Section.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1234)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Token_WhyFx1Sectionvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "12983800",
  "6168b842"
  
)

/* harmony default export */ var WhyFx1Section = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 645:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/mobile-shoe.d10866d.png";

/***/ }),

/***/ 960:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1235);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("28139cb0", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=104.js.map
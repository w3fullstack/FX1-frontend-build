exports.ids = [140];
exports.modules = {

/***/ 1164:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Supporters_vue_vue_type_style_index_0_id_c5dfa374_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(925);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Supporters_vue_vue_type_style_index_0_id_c5dfa374_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Supporters_vue_vue_type_style_index_0_id_c5dfa374_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Supporters_vue_vue_type_style_index_0_id_c5dfa374_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Supporters_vue_vue_type_style_index_0_id_c5dfa374_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1165:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xo-locker-room-supporters[data-v-c5dfa374]{padding:0 30px 30px}@media screen and (max-width:1024px){.xo-locker-room-supporters[data-v-c5dfa374]{padding:0 20px 30px}}.xo-locker-room-supporters[data-v-c5dfa374]>._label{opacity:.7;margin-bottom:20px}.xo-locker-room-supporters[data-v-c5dfa374] .list .member{cursor:pointer;-webkit-user-select:none;-moz-user-select:none;user-select:none;margin-bottom:20px}.xo-locker-room-supporters[data-v-c5dfa374] .list .member>.name{padding:0 15px;opacity:.5;font-size:1.0714rem;line-height:1.4286rem}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1367:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/LockerRoom/Supporters.vue?vue&type=template&id=c5dfa374&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xo-locker-room-supporters"},[_vm._ssrNode("<div class=\"_label text-uppercase text-weight-light\" data-v-c5dfa374>Supporters</div>"),_vm._ssrNode("<div class=\"list\" data-v-c5dfa374>","</div>",_vm._l((_vm.supporters),function(member,index){return _c('XALockerRoomMember',{key:index,attrs:{"member":member}})}),1)],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/LockerRoom/Supporters.vue?vue&type=template&id=c5dfa374&scoped=true&lang=pug&

// EXTERNAL MODULE: external "lodash/orderBy"
var orderBy_ = __webpack_require__(227);
var orderBy_default = /*#__PURE__*/__webpack_require__.n(orderBy_);

// EXTERNAL MODULE: external "vuex-map-fields"
var external_vuex_map_fields_ = __webpack_require__(2);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/LockerRoom/Supporters.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ var Supportersvue_type_script_lang_js_ = ({
  name: 'XOLockerRoomSupporters',
  components: {
    XALockerRoomMember: () => __webpack_require__.e(/* import() */ 70).then(__webpack_require__.bind(null, 1300))
  },
  computed: {
    ...Object(external_vuex_map_fields_["mapFields"])('locker-room', ['lockerRoomActive', 'lockerRoomOnline']),
    userRole() {
      var _this$lockerRoomActiv;
      return ((_this$lockerRoomActiv = this.lockerRoomActive) === null || _this$lockerRoomActiv === void 0 ? void 0 : _this$lockerRoomActiv.role) || null;
    },
    roles() {
      var _this$lockerRoomActiv2;
      return ((_this$lockerRoomActiv2 = this.lockerRoomActive) === null || _this$lockerRoomActiv2 === void 0 ? void 0 : _this$lockerRoomActiv2.Roles) || [];
    },
    supporters() {
      var _this$roles;
      const supporters = orderBy_default()((_this$roles = this.roles) === null || _this$roles === void 0 ? void 0 : _this$roles.Supporters, ['User.username'], ['asc']);
      return supporters || [];
    }
  }
});
// CONCATENATED MODULE: ./components/organisms/LockerRoom/Supporters.vue?vue&type=script&lang=js&
 /* harmony default export */ var LockerRoom_Supportersvue_type_script_lang_js_ = (Supportersvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/organisms/LockerRoom/Supporters.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1164)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  LockerRoom_Supportersvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "c5dfa374",
  "ae5f94ea"
  
)

/* harmony default export */ var Supporters = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 925:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1165);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("1230f6dc", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=140.js.map
exports.ids = [130];
exports.modules = {

/***/ 1236:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_HowDoesFx1Section_vue_vue_type_style_index_0_id_580e7f40_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(961);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_HowDoesFx1Section_vue_vue_type_style_index_0_id_580e7f40_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_HowDoesFx1Section_vue_vue_type_style_index_0_id_580e7f40_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_HowDoesFx1Section_vue_vue_type_style_index_0_id_580e7f40_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_HowDoesFx1Section_vue_vue_type_style_index_0_id_580e7f40_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1237:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".token-howDoesFX1-section[data-v-580e7f40]{width:auto;position:relative;overflow:hidden;padding:150px 0;z-index:2}.token-howDoesFX1-section[data-v-580e7f40] .for-tablet{display:none}.token-howDoesFX1-section[data-v-580e7f40] .top-margin-a{margin-top:80px}.token-howDoesFX1-section[data-v-580e7f40] .top-margin-b{margin-top:20px}.token-howDoesFX1-section[data-v-580e7f40] .top-margin-c{margin-top:40px}.token-howDoesFX1-section[data-v-580e7f40] .box{background-color:#0c353e;padding:30px 40px;min-height:320px;border-radius:20px}@media screen and (max-width:1600px){.token-howDoesFX1-section[data-v-580e7f40] .box{min-height:380px}}@media screen and (min-width:1024px){.token-howDoesFX1-section[data-v-580e7f40] .box{height:100%}}.token-howDoesFX1-section[data-v-580e7f40] .b-1{margin-right:30px}.token-howDoesFX1-section[data-v-580e7f40] .b-2{margin-left:15px;margin-right:15px}.token-howDoesFX1-section[data-v-580e7f40] .b-3{margin-left:30px}.token-howDoesFX1-section[data-v-580e7f40] .actions{margin:12px 12px 35px}.token-howDoesFX1-section[data-v-580e7f40] .btn-left a,.token-howDoesFX1-section[data-v-580e7f40] .btn-right a{width:200px;height:60px;border-radius:8px}.token-howDoesFX1-section[data-v-580e7f40] .btn-right a{background-color:transparent;outline:1px solid #fff}@media screen and (max-width:1023px){.token-howDoesFX1-section[data-v-580e7f40] .for-desktop{display:none}.token-howDoesFX1-section[data-v-580e7f40] .for-tablet{display:flex}.token-howDoesFX1-section[data-v-580e7f40] .box{margin-bottom:15px;min-height:340px!important}.token-howDoesFX1-section[data-v-580e7f40] .b-1{width:98%;margin-left:0;margin-right:2%}.token-howDoesFX1-section[data-v-580e7f40] .b-2{width:98%;margin-left:2%;margin-right:0}.token-howDoesFX1-section[data-v-580e7f40] .b-3{width:100%;margin-left:0;margin-right:0;min-height:240px!important}}@media screen and (max-width:500px){.token-howDoesFX1-section[data-v-580e7f40]{padding:50px 0}.token-howDoesFX1-section[data-v-580e7f40] .for-desktop{display:flex}.token-howDoesFX1-section[data-v-580e7f40] .for-tablet{display:none}.token-howDoesFX1-section[data-v-580e7f40] .box{margin-bottom:15px;min-height:auto!important}.token-howDoesFX1-section[data-v-580e7f40] .b-1,.token-howDoesFX1-section[data-v-580e7f40] .b-2,.token-howDoesFX1-section[data-v-580e7f40] .b-3{margin-left:0;margin-right:0}.token-howDoesFX1-section[data-v-580e7f40] .actions.text-left,.token-howDoesFX1-section[data-v-580e7f40] .actions.text-right{text-align:center!important}.token-howDoesFX1-section[data-v-580e7f40] .btn-left,.token-howDoesFX1-section[data-v-580e7f40] .btn-right{max-width:48%!important;height:60px!important}.token-howDoesFX1-section[data-v-580e7f40] .btn-left a,.token-howDoesFX1-section[data-v-580e7f40] .btn-right a{margin:0!important;width:100%!important;height:60px!important}.token-howDoesFX1-section[data-v-580e7f40] .btn-right{margin-left:2%!important}.token-howDoesFX1-section[data-v-580e7f40] .btn-left{margin-right:2%!important}.token-howDoesFX1-section[data-v-580e7f40] .top-margin-c{margin-top:35px!important}.token-howDoesFX1-section[data-v-580e7f40] .actions{margin-top:0!important}.token-howDoesFX1-section[data-v-580e7f40] .address{display:inline-block;margin:25px 0 0}.token-howDoesFX1-section[data-v-580e7f40] .address span{margin-top:5px}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1408:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/HowDoesFx1Section.vue?vue&type=template&id=580e7f40&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"token-howDoesFX1-section row"},[_vm._ssrNode("<div class=\"container token-container text-center\" data-v-580e7f40><h1 data-v-580e7f40>How does $FX1 work?</h1><div class=\"top-margin-a\" data-v-580e7f40></div><div class=\"row for-desktop\" data-v-580e7f40><div class=\"col\" data-v-580e7f40><div class=\"box b-1\" data-v-580e7f40><h2 class=\"token-h2-b\" data-v-580e7f40>Earn</h2><div class=\"paragraphs top-margin-b\" data-v-580e7f40><p class=\"token-p\" data-v-580e7f40>Share in a split of revenue generated when you invite your friends, family and community to FX1 to enjoy the experience of our live event rooms. Progress to become an Ambassador and earn the right to sell tickets to event rooms for additional opportunities to earn.</p></div></div></div><div class=\"col\" data-v-580e7f40><div class=\"box b-2\" data-v-580e7f40><h2 class=\"token-h2-b\" data-v-580e7f40>Use</h2><div class=\"paragraphs top-margin-b\" data-v-580e7f40><p class=\"token-p\" data-v-580e7f40>All purchases on FX1 will be made using the $FX1 token. You’ll be able to use it to purchase event room features, ensuring you only ever pay for what you consume. $FX1 can also be used to purchase digital collectibles, coming soon in 2023.</p></div></div></div><div class=\"col\" data-v-580e7f40><div class=\"box b-3\" data-v-580e7f40><h2 class=\"token-h2-b\" data-v-580e7f40>Hold</h2><div class=\"paragraphs top-margin-b\" data-v-580e7f40><p class=\"token-p\" data-v-580e7f40>You’re encouraged to build your bag of $FX1 given that doing so will give you special access to private event rooms hosted by sports stars and influences, as well as earning a range of digital collectibles that you can add to your profile.</p></div></div></div></div><div class=\"row for-tablet\" data-v-580e7f40><div class=\"col\" data-v-580e7f40><div class=\"box b-1\" data-v-580e7f40><h2 class=\"token-h2-b\" data-v-580e7f40>Earn</h2><div class=\"paragraphs top-margin-b\" data-v-580e7f40><p class=\"token-p\" data-v-580e7f40>Share in a split of revenue generated when you invite your friends, family and community to FX1 to enjoy the experience of our live event rooms. Progress to become an Ambassador and earn the right to sell tickets to event rooms for additional opportunities to earn.</p></div></div></div><div class=\"col\" data-v-580e7f40><div class=\"box b-2\" data-v-580e7f40><h2 class=\"token-h2-b\" data-v-580e7f40>Use</h2><div class=\"paragraphs top-margin-b\" data-v-580e7f40><p class=\"token-p\" data-v-580e7f40>All purchases on FX1 will be made using the $FX1 token. You’ll be able to use it to purchase event room features, ensuring you only ever pay for what you consume. $FX1 can also be used to purchase digital collectibles, coming soon in 2023.</p></div></div></div></div><div class=\"row for-tablet\" data-v-580e7f40><div class=\"col\" data-v-580e7f40><div class=\"box b-3\" data-v-580e7f40><h2 class=\"token-h2-b\" data-v-580e7f40>Hold</h2><div class=\"paragraphs top-margin-b\" data-v-580e7f40><p class=\"token-p\" data-v-580e7f40>You’re encouraged to build your bag of $FX1 given that doing so will give you special access to private event rooms hosted by sports stars and influences, as well as earning a range of digital collectibles that you can add to your profile.</p></div></div></div></div><div class=\"row top-margin-c\" data-v-580e7f40><div class=\"col actions text-right btn-left\" data-v-580e7f40><a href=\"https://app.uniswap.org/#/swap?outputCurrency=0x610C584F1275f0f7c982Af0aC7883Ff4Dba661Bd\" target=\"_blank\" class=\"button is-primary\" data-v-580e7f40>Buy $FX1</a></div><div class=\"col actions text-left btn-right\" data-v-580e7f40><a href=\"https://www.dextools.io/app/en/ether/pair-explorer/0x87B958067FD665f3937de4439450B4950Eb68e15\" target=\"_blank\" class=\"button is-primary\" data-v-580e7f40>View Chart</a></div></div><span class=\"address\" data-v-580e7f40>Contract Address:<span data-v-580e7f40>0x610C584F1275f0f7c982Af0aC7883Ff4Dba661Bd</span></span></div>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Token/HowDoesFx1Section.vue?vue&type=template&id=580e7f40&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/HowDoesFx1Section.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var HowDoesFx1Sectionvue_type_script_lang_js_ = ({
  name: 'HowDoesFX1Section',
  methods: {
    showAlertMessage() {
      this.$toast.success('$FX1 available to purchase mid to late April', {
        duration: 5000,
        position: 'bottom-left',
        className: 'fx1-success'
      });
    }
  }
});
// CONCATENATED MODULE: ./components/molecules/Token/HowDoesFx1Section.vue?vue&type=script&lang=js&
 /* harmony default export */ var Token_HowDoesFx1Sectionvue_type_script_lang_js_ = (HowDoesFx1Sectionvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/Token/HowDoesFx1Section.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1236)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Token_HowDoesFx1Sectionvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "580e7f40",
  "692b43a3"
  
)

/* harmony default export */ var HowDoesFx1Section = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 961:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1237);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("251e8ea8", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=130.js.map
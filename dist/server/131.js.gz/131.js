exports.ids = [131];
exports.modules = {

/***/ 1250:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_SocialsSection_vue_vue_type_style_index_0_id_556a3a3d_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(968);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_SocialsSection_vue_vue_type_style_index_0_id_556a3a3d_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_SocialsSection_vue_vue_type_style_index_0_id_556a3a3d_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_SocialsSection_vue_vue_type_style_index_0_id_556a3a3d_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_SocialsSection_vue_vue_type_style_index_0_id_556a3a3d_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1251:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".socials-section[data-v-556a3a3d]{margin-top:120px;position:relative;z-index:99}.socials-section .row[data-v-556a3a3d]{align-items:center}@media screen and (max-width:500px){.socials-section .row[data-v-556a3a3d]{flex-direction:column}}@media screen and (max-width:1025px){.socials-section[data-v-556a3a3d] .social-media{margin-top:30px}}@media screen and (max-width:767px){.socials-section[data-v-556a3a3d] .row{align-items:unset}.socials-section[data-v-556a3a3d] .xo-default-footer-connect,.socials-section[data-v-556a3a3d] .xo-default-footer-get-app{width:calc(50% - 15px)!important}.socials-section[data-v-556a3a3d] .xo-default-footer-connect h3,.socials-section[data-v-556a3a3d] .xo-default-footer-get-app h3{font-weight:700;font-size:28px;line-height:31px}.socials-section[data-v-556a3a3d] .xo-default-footer-get-app{padding:24px 0 0;margin-bottom:0}.socials-section[data-v-556a3a3d] .xo-default-footer-get-app .app-logo{flex-direction:column;margin-top:40px}.socials-section[data-v-556a3a3d] .xo-default-footer-get-app .app-logo a img{max-width:200px;margin-bottom:20px}.socials-section[data-v-556a3a3d] .xo-default-footer-connect{padding:24px 16px 0!important}.socials-section[data-v-556a3a3d] .xo-default-footer-connect .social-medias{justify-content:space-between}.socials-section[data-v-556a3a3d] .xo-default-footer-connect .social-medias .social-media{flex-basis:50%;margin-right:unset}}@media screen and (max-width:500px){.socials-section[data-v-556a3a3d]{margin-top:60px}.socials-section[data-v-556a3a3d] .xo-default-footer-connect,.socials-section[data-v-556a3a3d] .xo-default-footer-get-app{width:100%!important}.socials-section[data-v-556a3a3d] .xo-default-footer-connect h3,.socials-section[data-v-556a3a3d] .xo-default-footer-get-app h3{font-size:20px;line-height:22px}.socials-section[data-v-556a3a3d] .xo-default-footer-connect p,.socials-section[data-v-556a3a3d] .xo-default-footer-get-app p{max-width:80%;font-size:16px;line-height:28px}.socials-section[data-v-556a3a3d] .xo-default-footer-connect{padding:24px 16px!important;margin-top:60px}.socials-section[data-v-556a3a3d] .xo-default-footer-connect .social-medias{margin-top:20px}.socials-section[data-v-556a3a3d] .xo-default-footer-connect .social-medias .social-media{flex-basis:100%;justify-content:flex-start}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1415:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/SocialsSection.vue?vue&type=template&id=556a3a3d&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"socials-section row"},[_vm._ssrNode("<div class=\"container token-container\" data-v-556a3a3d>","</div>",[_vm._ssrNode("<div class=\"container is-max-widescreen\" data-v-556a3a3d>","</div>",[_vm._ssrNode("<div class=\"row justify-between\" data-v-556a3a3d>","</div>",[_c('XODefaultFooterGetApp'),_c('XODefaultFooterConnect',{attrs:{"background":'#0C353E',"padding":'24px 32px'}})],1)])])])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Token/SocialsSection.vue?vue&type=template&id=556a3a3d&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/SocialsSection.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//

/* harmony default export */ var SocialsSectionvue_type_script_lang_js_ = ({
  name: 'XTDefaultFooter',
  components: {
    XODefaultFooterGetApp: () => __webpack_require__.e(/* import() */ 6).then(__webpack_require__.bind(null, 1362)),
    XODefaultFooterConnect: () => __webpack_require__.e(/* import() */ 9).then(__webpack_require__.bind(null, 1363))
  }
});
// CONCATENATED MODULE: ./components/molecules/Token/SocialsSection.vue?vue&type=script&lang=js&
 /* harmony default export */ var Token_SocialsSectionvue_type_script_lang_js_ = (SocialsSectionvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/Token/SocialsSection.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1250)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Token_SocialsSectionvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "556a3a3d",
  "4e50dd7b"
  
)

/* harmony default export */ var SocialsSection = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 968:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1251);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("614012e2", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=131.js.map
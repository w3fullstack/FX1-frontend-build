exports.ids = [92];
exports.modules = {

/***/ 1218:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WhoIs_vue_vue_type_style_index_0_id_0e0d26de_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(952);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WhoIs_vue_vue_type_style_index_0_id_0e0d26de_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WhoIs_vue_vue_type_style_index_0_id_0e0d26de_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WhoIs_vue_vue_type_style_index_0_id_0e0d26de_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WhoIs_vue_vue_type_style_index_0_id_0e0d26de_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1219:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xo-home-what-is[data-v-0e0d26de]{background:#000;padding:100px 0 0;position:relative}.xo-home-what-is[data-v-0e0d26de] h1{margin-bottom:50px}.xo-home-what-is[data-v-0e0d26de] .who-is-container{display:grid;grid-template-columns:repeat(3,1fr);grid-gap:24px;gap:24px;grid-auto-flow:row;grid-template-areas:\"excitement experience new-way\" \"excitement winning winning\"}.xo-home-what-is[data-v-0e0d26de] .who-is-container .content-section{position:relative;padding:32px 40px;border-radius:20px;grid-gap:24px;gap:24px}.xo-home-what-is[data-v-0e0d26de] .who-is-container .content-section p.txt-subtitle-1{letter-spacing:.84px}.xo-home-what-is[data-v-0e0d26de] .who-is-container .content-section p.txt-intro{line-height:2.28rem;font-weight:300}.xo-home-what-is[data-v-0e0d26de] .who-is-container .excitement{grid-area:excitement;background:#ffaf23;background:var(--accent-orange,#ffaf23);color:#212121;z-index:11}.xo-home-what-is[data-v-0e0d26de] .who-is-container .excitement .txt-group{display:flex;flex-flow:column;grid-gap:24px;gap:24px}.xo-home-what-is[data-v-0e0d26de] .who-is-container .excitement .ball-img-group{position:relative}.xo-home-what-is[data-v-0e0d26de] .who-is-container .excitement .ball-img-group .football-img{width:220px;margin-top:100px;margin-left:0}.xo-home-what-is[data-v-0e0d26de] .who-is-container .excitement .ball-img-group .basketball-img{position:absolute;bottom:-80px;right:-35px;left:unset}.xo-home-what-is[data-v-0e0d26de] .who-is-container .experience{grid-area:experience;border:1px solid hsla(0,0%,100%,.2);background:rgba(0,0,0,.01);box-shadow:inset 0 1px 30px -5px rgba(227,222,255,.07),inset 0 4px 18px 0 rgba(146,156,210,.1),inset 0 98px 100px -48px rgba(170,188,204,.2);-webkit-backdrop-filter:blur(30px);backdrop-filter:blur(30px);z-index:11}.xo-home-what-is[data-v-0e0d26de] .who-is-container .new-way{grid-area:new-way;background:#4f3b98;background:var(--accent-purple-700,#4f3b98);box-shadow:0 2.10125px 6.01713px 0 rgba(79,59,152,.05),0 5.34051px 16.31415px 0 rgba(79,59,152,.08),0 10.5116px 33.00966px 0 rgba(79,59,152,.11),0 19.51257px 60.26942px 0 rgba(79,59,152,.14),0 38.73399px 108.73195px 0 rgba(79,59,152,.18),0 96px 244px 0 rgba(79,59,152,.3);z-index:11}.xo-home-what-is[data-v-0e0d26de] .who-is-container .winning{position:relative;grid-area:winning;grid-gap:unset;gap:unset;justify-content:space-between;border:1px solid hsla(0,0%,100%,.2);background:rgba(0,0,0,.01);box-shadow:inset 0 1px 30px -5px rgba(227,222,255,.07),inset 0 4px 18px 0 rgba(146,156,210,.1),inset 0 98px 100px -48px rgba(170,188,204,.2);-webkit-backdrop-filter:blur(30px);backdrop-filter:blur(30px);z-index:11}.xo-home-what-is[data-v-0e0d26de] .who-is-container .winning .fxl-log{position:absolute;bottom:0;right:0;border-bottom-right-radius:20px;width:453px}.xo-home-what-is[data-v-0e0d26de] .who-is-container .winning .txt-intro{max-width:405px}@media screen and (max-width:1439px){.xo-home-what-is[data-v-0e0d26de]{padding:80px 0 0}.xo-home-what-is[data-v-0e0d26de] h1{margin-bottom:32px}.xo-home-what-is[data-v-0e0d26de] .who-is-container{grid-gap:12px;gap:12px;grid-template-columns:1fr 1fr;grid-template-areas:\"excitement experience\" \"excitement new-way\" \"winning winning\"}.xo-home-what-is[data-v-0e0d26de] .who-is-container .content-section{grid-gap:20px;gap:20px;padding:36px 28px}.xo-home-what-is[data-v-0e0d26de] .who-is-container .excitement .ball-img-group .football-img{margin-top:85px;margin-left:10px}.xo-home-what-is[data-v-0e0d26de] .who-is-container .excitement .ball-img-group .basketball-img{left:150px;right:unset}.xo-home-what-is[data-v-0e0d26de] .who-is-container .winning .fxl-log{width:540px}.xo-home-what-is[data-v-0e0d26de] .who-is-container .winning .txt-intro{max-width:405px}}@media screen and (max-width:1023px){.xo-home-what-is[data-v-0e0d26de] .who-is-container{grid-template-areas:\"excitement excitement\" \"experience new-way\" \"winning winning\"}.xo-home-what-is[data-v-0e0d26de] .who-is-container .excitement{flex-flow:row}.xo-home-what-is[data-v-0e0d26de] .who-is-container .excitement .ball-img-group{min-width:230px}.xo-home-what-is[data-v-0e0d26de] .who-is-container .excitement .ball-img-group .football-img{width:190px;margin-right:30px}.xo-home-what-is[data-v-0e0d26de] .who-is-container .excitement .ball-img-group .basketball-img{left:unset;right:-45px;bottom:-78px;width:150px}.xo-home-what-is[data-v-0e0d26de] .who-is-container .winning .fxl-log{width:330px}.xo-home-what-is[data-v-0e0d26de] .who-is-container .winning .txt-intro{max-width:430px}}@media screen and (max-width:767px){.xo-home-what-is[data-v-0e0d26de]{padding:50px 0 0}.xo-home-what-is[data-v-0e0d26de] h1{margin-bottom:20px}.xo-home-what-is[data-v-0e0d26de] .who-is-container{grid-template-columns:1fr;grid-gap:20px;gap:20px;grid-template-areas:\"excitement\" \"experience\" \"new-way\" \"winning\"}.xo-home-what-is[data-v-0e0d26de] .who-is-container .content-section{padding:30px 20px;grid-gap:10px;gap:10px}.xo-home-what-is[data-v-0e0d26de] .who-is-container .content-section p.txt-subtitle-1{letter-spacing:.64px}.xo-home-what-is[data-v-0e0d26de] .who-is-container .excitement{flex-flow:column}.xo-home-what-is[data-v-0e0d26de] .who-is-container .excitement .ball-img-group{min-width:unset;max-width:100%}.xo-home-what-is[data-v-0e0d26de] .who-is-container .excitement .ball-img-group .football-img{margin-top:45px}.xo-home-what-is[data-v-0e0d26de] .who-is-container .excitement .ball-img-group .basketball-img{right:unset;left:130px}.xo-home-what-is[data-v-0e0d26de] .who-is-container .winning{padding-bottom:140px}.xo-home-what-is[data-v-0e0d26de] .who-is-container .winning .fxl-log{width:326px;margin-bottom:15px}.xo-home-what-is[data-v-0e0d26de] .who-is-container .winning .txt-intro{max-width:unset}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1390:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/v2/Home/WhoIs.vue?vue&type=template&id=0e0d26de&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xo-home-what-is"},[_vm._ssrNode("<div class=\"container is-max-widescreen\" data-v-0e0d26de><h1 data-v-0e0d26de>Who is FX1 Sports</h1><div class=\"who-is-container\" data-v-0e0d26de><div class=\"content-section experience flex-column justify-start\" data-v-0e0d26de><p class=\"txt-subtitle-1 text-weight-bold\" data-v-0e0d26de>A better experience</p><p class=\"txt-intro text-weight-light\" data-v-0e0d26de>The problem with sports betting platforms is how they’re not designed for the novice bettor using jargon or acronyms many don’t understand. They are also a zero-sum game in which you either win, or you loose.</p></div><div class=\"content-section new-way flex-column justify-start\" data-v-0e0d26de><p class=\"txt-subtitle-1 text-weight-bold\" data-v-0e0d26de>A new way to bet</p><p class=\"txt-intro text-weight-light\" data-v-0e0d26de>Community leaderboards, medals, trophies and the ability to climb conferences. Throw in sports betting and you have a new sporting social experience that you’ll only find at FX1.</p></div><div class=\"content-section winning flex-column justify-start\" data-v-0e0d26de><p class=\"txt-subtitle-1 text-weight-bold\" data-v-0e0d26de>The winning feeling</p><p class=\"txt-intro text-weight-light\" data-v-0e0d26de>We aim to completely revolutionize sports betting, placing a focus on fun and entertainment over profit and loss. We’re here to help provide you with that “winning feeling”, even when you loose.</p><img"+(_vm._ssrAttr("src",__webpack_require__(476)))+" class=\"fxl-log\" data-v-0e0d26de></div><div class=\"content-section excitement flex-column justify-start\" data-v-0e0d26de><div class=\"txt-group\" data-v-0e0d26de><p class=\"txt-subtitle-1 text-weight-bold\" data-v-0e0d26de>More excitement</p><p class=\"txt-intro text-weight-light\" data-v-0e0d26de>Part of our vision at FX1 has always been to make sports more exciting for the common fan. Research shows that placing a bet on a sports game increases the likelihood of watching it, and makes it more exciting as well.</p></div><div class=\"ball-img-group\" data-v-0e0d26de><img"+(_vm._ssrAttr("src",__webpack_require__(658)))+" class=\"football-img\" data-v-0e0d26de><img"+(_vm._ssrAttr("src",__webpack_require__(657)))+" class=\"basketball-img\" data-v-0e0d26de></div></div></div></div>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/v2/Home/WhoIs.vue?vue&type=template&id=0e0d26de&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/v2/Home/WhoIs.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var WhoIsvue_type_script_lang_js_ = ({
  name: 'XOHomeWhoIs'
});
// CONCATENATED MODULE: ./components/organisms/v2/Home/WhoIs.vue?vue&type=script&lang=js&
 /* harmony default export */ var Home_WhoIsvue_type_script_lang_js_ = (WhoIsvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/organisms/v2/Home/WhoIs.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1218)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Home_WhoIsvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "0e0d26de",
  "1ecc6216"
  
)

/* harmony default export */ var WhoIs = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 476:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDk0IiBoZWlnaHQ9IjE4OSIgdmlld0JveD0iMCAwIDQ5NCAxODkiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxnIG9wYWNpdHk9IjAuMDgiPgo8cGF0aCBkPSJNNDI5LjgwOSA3NS43NjQxSDQ2Ni4yMkw0MzYuMTI5IDIzMi41MTZINTA1LjkzOEw1NDYuODYyIDIwLjM4NTNINDQwLjM0TDQyOS44MDkgNzUuNzY0MVoiIGZpbGw9IiNGNzU0NTQiLz4KPHBhdGggZD0iTTQwMi4wNTkgMjMyLjgxOUgzMDkuMjcyTDI4Ny4yMTEgMTg2LjkzOUwyNTAuNjAzIDIzMi44MTlIMTU3LjMyOEwyNDkuMzk1IDEyNC4xNkwyMjkuMDc5IDgzLjQzNjFIMTQ2LjE3MUwxNDEuOTQ0IDEwNC45ODhIMjE5LjM2NUwyMDYuOTg4IDE2Ny45NDVIMTI5LjU1NUwxMTYuNjEzIDIzMi44MTlIMzguMTY4TDgwLjExMjggMjAuNDcxOUgyODguMjU3TDMwNi42NTQgNjEuNDAxN0wzMzguMyAyMC40NzE5SDQzMi4xMDNMMzQ2LjM0MSAxMjIuODI5TDQwMi4wNTkgMjMyLjgxOVpNMzE3LjQwNCAyMTkuOTM0SDM4MS4wNTJMMzMwLjk3MiAxMjEuMDc3TDQwNC40NjYgMzMuMzYwOUgzNDQuNjVMMzAzLjY5OSA4Ni4zMjQ1TDI3OS44OTEgMzMuMzU2Mkg5MC43MzM1TDUzLjg5IDIxOS45MzRIMTA2LjAxMkwxMTguOTU1IDE1NS4wNjFIMTk2LjM0OEwyMDMuNjYyIDExNy44NjVIMTI2LjI1OUwxMzUuNTM5IDcwLjU0NDhIMjM3LjA4MUwyNjQuNzM3IDEyNS45OTlMMTg1LjE1NyAyMTkuOTM3SDI0NC4zODFMMjg5Ljk0MyAxNjIuODFMMzE3LjQwNCAyMTkuOTM0WiIgZmlsbD0id2hpdGUiLz4KPC9nPgo8L3N2Zz4K"

/***/ }),

/***/ 657:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/excitement-basketball-img.0927749.png";

/***/ }),

/***/ 658:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/excitement-football-img.7b7c480.png";

/***/ }),

/***/ 952:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1219);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("175461dc", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=92.js.map
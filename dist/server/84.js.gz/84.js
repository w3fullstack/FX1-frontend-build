exports.ids = [84];
exports.modules = {

/***/ 1238:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_NFTfanSection_vue_vue_type_style_index_0_id_1a47566b_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(962);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_NFTfanSection_vue_vue_type_style_index_0_id_1a47566b_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_NFTfanSection_vue_vue_type_style_index_0_id_1a47566b_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_NFTfanSection_vue_vue_type_style_index_0_id_1a47566b_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_NFTfanSection_vue_vue_type_style_index_0_id_1a47566b_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1239:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(24);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(631);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".token-nft-fan-section[data-v-1a47566b]{background:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");background-repeat:no-repeat;background-position:0 100%;width:100%;position:relative;overflow:hidden;padding:150px 0;z-index:2;background-position-y:280px}.token-nft-fan-section[data-v-1a47566b] .top-margin-a{margin-top:25px}.token-nft-fan-section[data-v-1a47566b] .top-margin-b{margin-top:70px}.token-nft-fan-section[data-v-1a47566b] .left-side{padding-right:0}.token-nft-fan-section[data-v-1a47566b] .right-side{position:relative}.token-nft-fan-section[data-v-1a47566b] .right-side img{width:100%;top:-22%;right:-10%;position:absolute}@media screen and (max-width:1800px){.token-nft-fan-section[data-v-1a47566b] .right-side img{top:-18%}}@media screen and (max-width:1705px){.token-nft-fan-section[data-v-1a47566b] .right-side img{top:-5%}}@media screen and (max-width:1480px){.token-nft-fan-section[data-v-1a47566b] .right-side img{top:7%}}@media screen and (max-width:1280px){.token-nft-fan-section[data-v-1a47566b] .right-side img{top:18%}}@media screen and (max-width:1260px){.token-nft-fan-section[data-v-1a47566b] .right-side img{top:22%}}@media screen and (max-width:1025px){.token-nft-fan-section[data-v-1a47566b] .right-side img{right:0}}.token-nft-fan-section[data-v-1a47566b] .what-can-you-do-h2{margin-top:216px;font-family:\"Rotunda\";font-style:normal;font-weight:700;font-size:44px;line-height:49px;letter-spacing:.02em}.token-nft-fan-section[data-v-1a47566b] .what-can-you-do{margin-top:50px;justify-content:space-around}.token-nft-fan-section[data-v-1a47566b] .what-can-you-do .fan-avatar-box{padding:20px;grid-gap:20px;gap:20px;width:406px;height:231px;margin-top:30px;background:#0c353e;border-radius:20px}@media screen and (max-width:1463px){.token-nft-fan-section[data-v-1a47566b] .what-can-you-do .fan-avatar-box{width:350px;height:221px}}@media screen and (max-width:1388px){.token-nft-fan-section[data-v-1a47566b] .what-can-you-do .fan-avatar-box{width:330px;height:211px}}@media screen and (max-width:1313px){.token-nft-fan-section[data-v-1a47566b] .what-can-you-do .fan-avatar-box{width:315px;height:211px;width:290px;height:200px}}@media screen and (max-width:767px){.token-nft-fan-section[data-v-1a47566b] .what-can-you-do .fan-avatar-box{width:270px;height:200px}}@media screen and (max-width:619px){.token-nft-fan-section[data-v-1a47566b] .what-can-you-do .fan-avatar-box{width:250px;height:200px}}@media screen and (max-width:560px){.token-nft-fan-section[data-v-1a47566b] .what-can-you-do .fan-avatar-box{width:100%;height:200px}}.token-nft-fan-section[data-v-1a47566b] .what-can-you-do .fan-avatar-box p{font-family:\"Rotunda\";font-style:normal;font-weight:300;font-size:22px;line-height:32px;letter-spacing:.02em;color:#fff}@media screen and (max-width:1463px){.token-nft-fan-section[data-v-1a47566b] .what-can-you-do .fan-avatar-box p{font-size:20px}}@media screen and (max-width:1400px){.token-nft-fan-section[data-v-1a47566b] .what-can-you-do .fan-avatar-box p{font-size:18px}}@media screen and (max-width:1350px){.token-nft-fan-section[data-v-1a47566b] .what-can-you-do .fan-avatar-box p{font-size:16px}}@media screen and (max-width:767px){.token-nft-fan-section[data-v-1a47566b] .what-can-you-do .fan-avatar-box p{font-size:14px}}@media screen and (max-width:619px){.token-nft-fan-section[data-v-1a47566b] .what-can-you-do .fan-avatar-box p{font-size:13px}}@media screen and (max-width:500px){.token-nft-fan-section[data-v-1a47566b]{padding:50px 0}.token-nft-fan-section[data-v-1a47566b] .top-margin-b{margin-top:0!important}.token-nft-fan-section[data-v-1a47566b] .right-side img{top:0;position:relative;margin-top:25px}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1409:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/NFTfanSection.vue?vue&type=template&id=1a47566b&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"token-nft-fan-section row"},[_vm._ssrNode("<div class=\"container token-container\" data-v-1a47566b><div class=\"row\" data-v-1a47566b><div class=\"col left-side\" data-v-1a47566b><h1 data-v-1a47566b>Fan Avatar Drop</h1><div class=\"top-margin-a\" data-v-1a47566b></div><div class=\"top-margin-b\" data-v-1a47566b></div><p class=\"token-p\" data-v-1a47566b>By becoming one of the early holders of the $FX1 token, you’ll be in the draw to win your very own Fan Avatar from the first release of the FX1 Fan Avatar series.</p><div class=\"top-margin-a\" data-v-1a47566b></div><ul class=\"token-u\" data-v-1a47566b><li class=\"token-p\" data-v-1a47566b>Be one of 30 potential holders of the first Fan Avatars to be released</li><li class=\"token-p\" data-v-1a47566b>The more $FX1 you buy on launch, the better chance you’ll have</li><li class=\"token-p\" data-v-1a47566b>If drawn, you’ll receive your NFT by way of a drop by July 2023</li></ul></div><div class=\"col right-side text-center\" data-v-1a47566b><img"+(_vm._ssrAttr("src",__webpack_require__(646)))+" alt=\"NFT Fan Avatar\" data-v-1a47566b></div></div><h2 class=\"what-can-you-do-h2\" data-v-1a47566b>What you can do with your Fan Avatar</h2><div class=\"row justify-content-center what-can-you-do\" data-v-1a47566b><div class=\"col-3 fan-avatar-box\" data-v-1a47566b><img"+(_vm._ssrAttr("src",__webpack_require__(651)))+" alt=\"NFT Fan Avatar\" data-v-1a47566b><p data-v-1a47566b>Your Fan Avatar will give you special social powers on FX1</p></div><div class=\"col-3 fan-avatar-box\" data-v-1a47566b><img"+(_vm._ssrAttr("src",__webpack_require__(643)))+" alt=\"NFT Fan Avatar\" data-v-1a47566b><p data-v-1a47566b>Access to early releases on Fan Avatar NFT collections</p></div><div class=\"col-3 fan-avatar-box\" data-v-1a47566b><img"+(_vm._ssrAttr("src",__webpack_require__(649)))+" alt=\"NFT Fan Avatar\" data-v-1a47566b><p data-v-1a47566b>Access to private Event Rooms featuring special guests</p></div><div class=\"col-3 fan-avatar-box\" data-v-1a47566b><img"+(_vm._ssrAttr("src",__webpack_require__(644)))+" alt=\"NFT Fan Avatar\" data-v-1a47566b><p data-v-1a47566b>Display and promote your Fan Avatar on your FX1 profile</p></div></div></div>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Token/NFTfanSection.vue?vue&type=template&id=1a47566b&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/NFTfanSection.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var NFTfanSectionvue_type_script_lang_js_ = ({
  name: 'NFTfanSection'
});
// CONCATENATED MODULE: ./components/molecules/Token/NFTfanSection.vue?vue&type=script&lang=js&
 /* harmony default export */ var Token_NFTfanSectionvue_type_script_lang_js_ = (NFTfanSectionvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/Token/NFTfanSection.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1238)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Token_NFTfanSectionvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "1a47566b",
  "3ca21d22"
  
)

/* harmony default export */ var NFTfanSection = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 631:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/FanAvatarBackground.6423867.svg";

/***/ }),

/***/ 643:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/gift.7d07165.svg";

/***/ }),

/***/ 644:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/message.f4d83b9.svg";

/***/ }),

/***/ 646:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/nft-fan-avatar.a918f40.svg";

/***/ }),

/***/ 649:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/rocket.bf40370.svg";

/***/ }),

/***/ 651:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/special-power.f0d9e72.svg";

/***/ }),

/***/ 962:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1239);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("aec0f4e6", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=84.js.map
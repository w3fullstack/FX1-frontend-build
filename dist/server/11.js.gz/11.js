exports.ids = [11];
exports.modules = {

/***/ 1202:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WaitingFor_vue_vue_type_style_index_0_id_19549a92_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(944);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WaitingFor_vue_vue_type_style_index_0_id_19549a92_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WaitingFor_vue_vue_type_style_index_0_id_19549a92_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WaitingFor_vue_vue_type_style_index_0_id_19549a92_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WaitingFor_vue_vue_type_style_index_0_id_19549a92_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1203:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(24);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(477);
var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(660);
var ___CSS_LOADER_URL_IMPORT_2___ = __webpack_require__(479);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
var ___CSS_LOADER_URL_REPLACEMENT_2___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_2___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xo-home-waiting-for[data-v-19549a92]{height:1464px;overflow:hidden;background:#000;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");background-position:100%;background-repeat:no-repeat;position:relative;margin-top:-360px}.xo-home-waiting-for .right-img-content[data-v-19549a92]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ");width:826px;height:1228px;background-repeat:no-repeat;position:absolute;right:0;top:85px}.xo-home-waiting-for .left-section[data-v-19549a92]{position:relative;max-width:568px}.xo-home-waiting-for .left-section h1[data-v-19549a92]{margin-bottom:28px}.xo-home-waiting-for .left-section h3[data-v-19549a92]{text-shadow:0 4px 12px rgba(0,0,0,.4)}.xo-home-waiting-for .left-section .actions[data-v-19549a92]{margin-top:28px}.xo-home-waiting-for .left-section .actions .button[data-v-19549a92]{width:251px!important;height:76px!important;font-size:20px;line-height:28px;text-transform:uppercase;border-radius:10px;box-shadow:0 1.06592px 2.80384px 0 rgba(248,84,84,.08),0 2.47835px 6.51914px 0 rgba(248,84,84,.12),0 4.45054px 11.70687px 0 rgba(248,84,84,.15),0 7.38625px 19.42906px 0 rgba(248,84,84,.17),0 12.1686px 32.00872px 0 rgba(248,84,84,.2),0 21.26719px 55.94197px 0 rgba(248,84,84,.24),0 46px 121px 0 rgba(248,84,84,.32);margin-right:unset!important;margin-left:unset!important}@media screen and (max-width:1439px){.xo-home-waiting-for[data-v-19549a92]{background-size:1000px}.xo-home-waiting-for .right-img-content[data-v-19549a92]{background-size:755px;right:-90px;top:166px}.xo-home-waiting-for .left-section[data-v-19549a92]{max-width:530px}}@media screen and (max-width:1023px){.xo-home-waiting-for[data-v-19549a92]{background-size:800px}.xo-home-waiting-for .right-img-content[data-v-19549a92]{background-size:550px;right:-260px;top:301px}.xo-home-waiting-for .left-section[data-v-19549a92]{max-width:368px}}@media screen and (max-width:767px){.xo-home-waiting-for[data-v-19549a92]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ");background-size:cover;background-position:50%;margin-top:-155px;align-items:flex-start;justify-content:center}.xo-home-waiting-for .right-img-content[data-v-19549a92]{background-size:500px;right:-160px;top:unset;bottom:-115px}.xo-home-waiting-for .container[data-v-19549a92]{display:flex;flex-flow:row;justify-content:center;margin-top:250px}.xo-home-waiting-for .container .left-section h3[data-v-19549a92]{font-size:1rem;line-height:20px}.xo-home-waiting-for .container .left-section .actions .button[data-v-19549a92]{width:205px!important;height:46px!important;font-size:1rem}}@media screen and (min-width:420px)and (max-width:767px){.xo-home-waiting-for[data-v-19549a92]{background-image:none;background:#000}}@media screen and (max-width:700px){.xo-home-waiting-for .right-img-content[data-v-19549a92]{right:-200px}}@media screen and (max-width:600px){.xo-home-waiting-for .right-img-content[data-v-19549a92]{right:-260px}}@media screen and (max-width:540px){.xo-home-waiting-for[data-v-19549a92]{background-size:contain}.xo-home-waiting-for .right-img-content[data-v-19549a92]{right:-289px}}@media screen and (max-width:450px){.xo-home-waiting-for .right-img-content[data-v-19549a92]{right:-305px}}@media screen and (max-width:375px){.xo-home-waiting-for .right-img-content[data-v-19549a92]{right:-343px}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1382:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/v2/Home/WaitingFor.vue?vue&type=template&id=19549a92&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xo-home-waiting-for row items-center justify-start"},[_vm._ssrNode("<div class=\"right-img-content\" data-v-19549a92></div>"),_vm._ssrNode("<div class=\"container is-max-widescreen\" data-v-19549a92>","</div>",[_vm._ssrNode("<div class=\"left-section\" data-v-19549a92>","</div>",[_vm._ssrNode("<h1 data-v-19549a92>What are you waiting for?</h1><h3 class=\"text-weight-light\" data-v-19549a92>Sign up for free and join a small but growing community of avid sports fans. Stay up to date on feature releases.</h3>"),_vm._ssrNode("<div class=\"actions\" data-v-19549a92>","</div>",[_c('b-button',{staticClass:"items-center justify-center text-weight-medium",attrs:{"type":"is-primary","tag":"router-link","to":"/signup?step=1"}},[_vm._v("Create Account")])],1)],2)])],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/v2/Home/WaitingFor.vue?vue&type=template&id=19549a92&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/v2/Home/WaitingFor.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var WaitingForvue_type_script_lang_js_ = ({
  name: 'XOHomeWaitingFor'
});
// CONCATENATED MODULE: ./components/organisms/v2/Home/WaitingFor.vue?vue&type=script&lang=js&
 /* harmony default export */ var Home_WaitingForvue_type_script_lang_js_ = (WaitingForvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/organisms/v2/Home/WaitingFor.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1202)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Home_WaitingForvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "19549a92",
  "7dea30c4"
  
)

/* harmony default export */ var WaitingFor = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 477:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/circles-and-light-1.c93372d.svg";

/***/ }),

/***/ 479:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/circles-and-light-mobile.339c3d1.svg";

/***/ }),

/***/ 660:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/waiting-for_man.1f16256.png";

/***/ }),

/***/ 944:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1203);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("43475792", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=11.js.map
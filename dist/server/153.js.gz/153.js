exports.ids = [153];
exports.modules = {

/***/ 1045:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_style_index_0_id_4bd4a9c0_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(866);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_style_index_0_id_4bd4a9c0_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_style_index_0_id_4bd4a9c0_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_style_index_0_id_4bd4a9c0_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_style_index_0_id_4bd4a9c0_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1046:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xt-default-footer[data-v-4bd4a9c0]{background-color:#000;min-height:130px}.xt-default-footer[data-v-4bd4a9c0] .get-app-connect-container{padding:70px 0 0}@media screen and (max-width:1025px){.row[data-v-4bd4a9c0] .social-media{margin-top:30px}}@media screen and (max-width:769px){.row[data-v-4bd4a9c0]{align-items:unset}.row[data-v-4bd4a9c0] .xo-default-footer-connect,.row[data-v-4bd4a9c0] .xo-default-footer-get-app{width:calc(50% - 15px)!important}.row[data-v-4bd4a9c0] .xo-default-footer-connect h3,.row[data-v-4bd4a9c0] .xo-default-footer-get-app h3{font-weight:700;font-size:28px;line-height:31px}.row[data-v-4bd4a9c0] .xo-default-footer-get-app{padding:24px 0 0;margin-bottom:0}.row[data-v-4bd4a9c0] .xo-default-footer-get-app .app-logo{flex-direction:column;margin-top:40px}.row[data-v-4bd4a9c0] .xo-default-footer-get-app .app-logo a img{max-width:200px;margin-bottom:20px}.row[data-v-4bd4a9c0] .xo-default-footer-connect{padding:24px 16px 0!important}.row[data-v-4bd4a9c0] .xo-default-footer-connect .social-medias{justify-content:space-between}.row[data-v-4bd4a9c0] .xo-default-footer-connect .social-medias .social-media{flex-basis:50%;margin-right:unset!important}}@media screen and (max-width:500px){.row[data-v-4bd4a9c0]{margin-top:60px}.row[data-v-4bd4a9c0] .xo-default-footer-connect,.row[data-v-4bd4a9c0] .xo-default-footer-get-app{width:100%!important}.row[data-v-4bd4a9c0] .xo-default-footer-connect h3,.row[data-v-4bd4a9c0] .xo-default-footer-get-app h3{font-size:20px;line-height:22px}.row[data-v-4bd4a9c0] .xo-default-footer-connect p,.row[data-v-4bd4a9c0] .xo-default-footer-get-app p{max-width:80%;font-size:16px;line-height:28px}.row[data-v-4bd4a9c0] .xo-default-footer-connect{padding:24px 16px!important;margin-top:60px}.row[data-v-4bd4a9c0] .xo-default-footer-connect .social-medias{margin-top:20px}.row[data-v-4bd4a9c0] .xo-default-footer-connect .social-medias .social-media{flex-basis:100%;justify-content:flex-start}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1341:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/templates/Jackpot/Footer.vue?vue&type=template&id=4bd4a9c0&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xt-default-footer"},[(_vm.$route.path != '/error')?_vm._ssrNode("<div class=\"get-app-connect-container\" data-v-4bd4a9c0>","</div>",[_c('FooterBase')],1):_vm._e(),_c('XODefaultFooterCopyright')],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/templates/Jackpot/Footer.vue?vue&type=template&id=4bd4a9c0&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/templates/Jackpot/Footer.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//

/* harmony default export */ var Footervue_type_script_lang_js_ = ({
  name: 'XTDefaultFooter',
  components: {
    XODefaultFooterGetApp: () => __webpack_require__.e(/* import() */ 6).then(__webpack_require__.bind(null, 1362)),
    XODefaultFooterConnect: () => __webpack_require__.e(/* import() */ 9).then(__webpack_require__.bind(null, 1363)),
    FooterBase: () => __webpack_require__.e(/* import() */ 77).then(__webpack_require__.bind(null, 1364)),
    XODefaultFooterCopyright: () => __webpack_require__.e(/* import() */ 125).then(__webpack_require__.bind(null, 1365))
  }
});
// CONCATENATED MODULE: ./components/templates/Jackpot/Footer.vue?vue&type=script&lang=js&
 /* harmony default export */ var Jackpot_Footervue_type_script_lang_js_ = (Footervue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/templates/Jackpot/Footer.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1045)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Jackpot_Footervue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "4bd4a9c0",
  "779bf72e"
  
)

/* harmony default export */ var Footer = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 866:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1046);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("3b2f5802", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=153.js.map
exports.ids = [17];
exports.modules = {

/***/ 1198:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Clubs_vue_vue_type_style_index_0_id_1fb2b7dc_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(942);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Clubs_vue_vue_type_style_index_0_id_1fb2b7dc_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Clubs_vue_vue_type_style_index_0_id_1fb2b7dc_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Clubs_vue_vue_type_style_index_0_id_1fb2b7dc_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Clubs_vue_vue_type_style_index_0_id_1fb2b7dc_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1199:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(24);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(484);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xo-home-clubs[data-v-1fb2b7dc]{background-color:#000;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");background-repeat:no-repeat;background-position:left 0 top -150px;padding:100px 0}@media screen and (max-width:1439px){.xo-home-clubs[data-v-1fb2b7dc]{padding:80px 0}.xo-home-clubs[data-v-1fb2b7dc] h1{margin-bottom:0}.xo-home-clubs[data-v-1fb2b7dc] .xm-live-slider{margin:0}}@media screen and (max-width:767px){.xo-home-clubs[data-v-1fb2b7dc]{padding:50px 0}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1380:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/Home/Clubs.vue?vue&type=template&id=1fb2b7dc&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xo-home-clubs"},[_vm._ssrNode("<div class=\"container is-max-widescreen\" data-v-1fb2b7dc>","</div>",[_vm._ssrNode("<h1 data-v-1fb2b7dc>Upcoming Games</h1>"),_c('XOLiveRecommendedSlider',{attrs:{"status":"upcoming"}})],2)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/Home/Clubs.vue?vue&type=template&id=1fb2b7dc&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/Home/Clubs.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//

/* harmony default export */ var Clubsvue_type_script_lang_js_ = ({
  name: 'XOHomeClubs',
  components: {
    XOLiveRecommendedSlider: () => __webpack_require__.e(/* import() */ 60).then(__webpack_require__.bind(null, 1416))
  }
});
// CONCATENATED MODULE: ./components/organisms/Home/Clubs.vue?vue&type=script&lang=js&
 /* harmony default export */ var Home_Clubsvue_type_script_lang_js_ = (Clubsvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/organisms/Home/Clubs.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1198)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Home_Clubsvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "1fb2b7dc",
  "1529d536"
  
)

/* harmony default export */ var Clubs = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 484:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDU1IiBoZWlnaHQ9Ijg2NiIgdmlld0JveD0iMCAwIDQ1NSA4NjYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxnIGZpbHRlcj0idXJsKCNmaWx0ZXIwX2ZfOTY5Ml81MjQ4MSkiPgo8cGF0aCBkPSJNNzUuMzA3MSAyMDEuNzFDMTQ1LjA1OSAxOTYuNjI5IDI0NC4zMiAyMTEuNyAyNTMuNjkxIDM0MC4zNDFDMjYzLjA2MiA0NjguOTgzIDEzNi4zNzIgNjYwLjQ4NiA2Ni42MTk4IDY2NS41NjdDLTMuMTMyNTQgNjcwLjY0OCAtMTI1LjM3NCA0NzcuMTA5IC0xMzQuNzQ1IDM0OC40NjdDLTE0NC4xMTcgMjE5LjgyNSA1LjU1NDc4IDIwNi43OTEgNzUuMzA3MSAyMDEuNzFaIiBmaWxsPSIjMDI4Q0E3IiBmaWxsLW9wYWNpdHk9IjAuMiIvPgo8L2c+CjxkZWZzPgo8ZmlsdGVyIGlkPSJmaWx0ZXIwX2ZfOTY5Ml81MjQ4MSIgeD0iLTMzNS4xNjYiIHk9IjAuODgzMTQ4IiB3aWR0aD0iNzg5LjM1IiBoZWlnaHQ9Ijg2NC43ODIiIGZpbHRlclVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgY29sb3ItaW50ZXJwb2xhdGlvbi1maWx0ZXJzPSJzUkdCIj4KPGZlRmxvb2QgZmxvb2Qtb3BhY2l0eT0iMCIgcmVzdWx0PSJCYWNrZ3JvdW5kSW1hZ2VGaXgiLz4KPGZlQmxlbmQgbW9kZT0ibm9ybWFsIiBpbj0iU291cmNlR3JhcGhpYyIgaW4yPSJCYWNrZ3JvdW5kSW1hZ2VGaXgiIHJlc3VsdD0ic2hhcGUiLz4KPGZlR2F1c3NpYW5CbHVyIHN0ZERldmlhdGlvbj0iMTAwIiByZXN1bHQ9ImVmZmVjdDFfZm9yZWdyb3VuZEJsdXJfOTY5Ml81MjQ4MSIvPgo8L2ZpbHRlcj4KPC9kZWZzPgo8L3N2Zz4K"

/***/ }),

/***/ 942:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1199);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("9f024444", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=17.js.map
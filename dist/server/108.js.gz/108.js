exports.ids = [108];
exports.modules = {

/***/ 1212:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_AfterBanner_vue_vue_type_style_index_0_id_7dc00c3a_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(949);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_AfterBanner_vue_vue_type_style_index_0_id_7dc00c3a_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_AfterBanner_vue_vue_type_style_index_0_id_7dc00c3a_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_AfterBanner_vue_vue_type_style_index_0_id_7dc00c3a_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_AfterBanner_vue_vue_type_style_index_0_id_7dc00c3a_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1213:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xo-home-after-banner[data-v-7dc00c3a]{margin-top:-400px}.xo-home-after-banner .mobile-after-banner[data-v-7dc00c3a]{display:none}.xo-home-after-banner .deskop-after-banner .feature-content .container[data-v-7dc00c3a]{flex-flow:row;justify-content:space-between;grid-gap:102px;gap:102px}.xo-home-after-banner .deskop-after-banner .feature-content .container .sub-content p.txt-intro[data-v-7dc00c3a]{margin-top:12px;opacity:.8}.xo-home-after-banner .deskop-after-banner .img-feature-group[data-v-7dc00c3a]{margin-top:62px;padding-bottom:110px;background:linear-gradient(0deg,#000,transparent 71.01%),#08252c}.xo-home-after-banner .deskop-after-banner .img-feature-group .container[data-v-7dc00c3a]{flex-flow:row;justify-content:space-between;grid-gap:102px;gap:102px}.xo-home-after-banner .deskop-after-banner .img-feature-group .container .sub-group[data-v-7dc00c3a]{position:relative}.xo-home-after-banner .deskop-after-banner .img-feature-group .container .sub-group .img-feature-1[data-v-7dc00c3a]{max-width:380px;margin-left:120px}@media screen and (min-width:1024px)and (max-width:1215px){.xo-home-after-banner .deskop-after-banner .feature-content .container[data-v-7dc00c3a],.xo-home-after-banner .deskop-after-banner .img-feature-group .container[data-v-7dc00c3a]{max-width:1024px}}@media screen and (max-width:1439px){.xo-home-after-banner[data-v-7dc00c3a]{margin-top:-430px}.xo-home-after-banner .deskop-after-banner .feature-content .container[data-v-7dc00c3a]{grid-gap:84px;gap:84px}.xo-home-after-banner .deskop-after-banner .img-feature-group[data-v-7dc00c3a]{margin-top:45px}.xo-home-after-banner .deskop-after-banner .img-feature-group .container[data-v-7dc00c3a]{grid-gap:84px;gap:84px}.xo-home-after-banner .deskop-after-banner .img-feature-group .container .sub-group .img-feature-1[data-v-7dc00c3a]{max-width:348px;margin-left:103px}}@media screen and (max-width:1023px){.xo-home-after-banner .deskop-after-banner .feature-content .container[data-v-7dc00c3a]{grid-gap:50px;gap:50px}.xo-home-after-banner .deskop-after-banner .img-feature-group[data-v-7dc00c3a]{margin-top:50px}.xo-home-after-banner .deskop-after-banner .img-feature-group .container[data-v-7dc00c3a]{grid-gap:50px;gap:50px}.xo-home-after-banner .deskop-after-banner .img-feature-group .container .sub-group .img-feature-1[data-v-7dc00c3a]{max-width:251px;margin-left:50px}}@media screen and (max-width:767px){.xo-home-after-banner .deskop-after-banner[data-v-7dc00c3a]{display:none}.xo-home-after-banner .mobile-after-banner[data-v-7dc00c3a]{display:block;margin-top:-480px;width:100%;height:100%}.xo-home-after-banner .mobile-after-banner .banner-1[data-v-7dc00c3a]{display:flex;flex-flow:column;grid-gap:12px;gap:12px;width:100%}.xo-home-after-banner .mobile-after-banner .banner-1 .sub-group[data-v-7dc00c3a]{width:100%;display:flex;justify-content:center}.xo-home-after-banner .mobile-after-banner .banner-1 .sub-group .feature-group[data-v-7dc00c3a]{margin-top:18px;position:relative;width:345px}.xo-home-after-banner .mobile-after-banner .banner-1 .sub-group .feature-group .img-feature-1[data-v-7dc00c3a]{width:279px;margin-left:60px}.xo-home-after-banner .mobile-after-banner .banner-2[data-v-7dc00c3a]{margin-top:28px;background:linear-gradient(0deg,#000,transparent 71.01%),#08252c}.xo-home-after-banner .mobile-after-banner .banner-2 .container[data-v-7dc00c3a]{padding-top:130px;display:flex;flex-flow:column;grid-gap:12px;gap:12px;width:100%}.xo-home-after-banner .mobile-after-banner .banner-2 .container .sub-group[data-v-7dc00c3a]{width:100%;display:flex;justify-content:center}.xo-home-after-banner .mobile-after-banner .banner-2 .container .sub-group .feature-group[data-v-7dc00c3a]{margin-top:18px;position:relative;width:345px;z-index:1}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1387:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/v2/Home/AfterBanner.vue?vue&type=template&id=7dc00c3a&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xo-home-after-banner"},[_vm._ssrNode("<div class=\"deskop-after-banner\" data-v-7dc00c3a>","</div>",[_vm._ssrNode("<div class=\"feature-content\" data-v-7dc00c3a><div class=\"container is-max-widescreen row\" data-v-7dc00c3a><div class=\"sub-content\" data-v-7dc00c3a><p class=\"txt-subtitle text-weight-regular\" data-v-7dc00c3a>Live game scores and progress updates</p><p class=\"txt-intro text-weight-light\" data-v-7dc00c3a>Find our growing list of sports and follow along with live scores and game progress updates.</p></div><div class=\"sub-content\" data-v-7dc00c3a><p class=\"txt-subtitle text-weight-regular\" data-v-7dc00c3a>Create private groups and invite your friends</p><p class=\"txt-intro text-weight-light\" data-v-7dc00c3a>Engage with fans or create your own private groups and chat using text, audio and video.</p></div></div></div>"),_vm._ssrNode("<div class=\"img-feature-group\" data-v-7dc00c3a>","</div>",[_vm._ssrNode("<div class=\"container is-max-widescreen row\" data-v-7dc00c3a>","</div>",[_vm._ssrNode("<div class=\"sub-group\" data-v-7dc00c3a>","</div>",[_vm._ssrNode("<img"+(_vm._ssrAttr("src",__webpack_require__(569)))+" class=\"img-feature-1\" data-v-7dc00c3a>"),_c('HomeAfterBannerProgressUpdates')],2),_vm._ssrNode("<div class=\"sub-group\" data-v-7dc00c3a>","</div>",[_c('HomeAfterBannerChatView'),_c('HomeAfterBannerEncrypted'),_c('HomeAfterBannerInvited'),_c('HomeAfterBannerPrivateGroup')],1)])])],2),_vm._ssrNode("<div class=\"mobile-after-banner\" data-v-7dc00c3a>","</div>",[_vm._ssrNode("<div class=\"container is-max-widescreen banner-1\" data-v-7dc00c3a>","</div>",[_vm._ssrNode("<p class=\"txt-subtitle text-weight-regular\" data-v-7dc00c3a>Live game scores and progress updates</p><p class=\"txt-intro text-weight-light\" data-v-7dc00c3a>Find our growing list of sports and follow along with live scores and game progress updates.</p>"),_vm._ssrNode("<div class=\"sub-group\" data-v-7dc00c3a>","</div>",[_vm._ssrNode("<div class=\"feature-group\" data-v-7dc00c3a>","</div>",[_vm._ssrNode("<img"+(_vm._ssrAttr("src",__webpack_require__(569)))+" class=\"img-feature-1\" data-v-7dc00c3a>"),_c('HomeAfterBannerProgressUpdates')],2)])],2),_vm._ssrNode("<div class=\"banner-2\" data-v-7dc00c3a>","</div>",[_vm._ssrNode("<div class=\"container is-max-widescreen\" data-v-7dc00c3a>","</div>",[_vm._ssrNode("<p class=\"txt-subtitle text-weight-regular\" data-v-7dc00c3a>Create private groups and invite your friends</p><p class=\"txt-intro text-weight-light\" data-v-7dc00c3a>Engage with fans or create your own private groups and chat using text, audio and video.</p>"),_vm._ssrNode("<div class=\"sub-group\" data-v-7dc00c3a>","</div>",[_vm._ssrNode("<div class=\"feature-group\" data-v-7dc00c3a>","</div>",[_c('HomeAfterBannerChatView'),_c('HomeAfterBannerEncrypted'),_c('HomeAfterBannerInvited'),_c('HomeAfterBannerPrivateGroup')],1)])],2)])])])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/v2/Home/AfterBanner.vue?vue&type=template&id=7dc00c3a&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/v2/Home/AfterBanner.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var AfterBannervue_type_script_lang_js_ = ({
  name: 'XOHomeAfterBanner',
  components: {
    HomeAfterBannerProgressUpdates: () => __webpack_require__.e(/* import() */ 74).then(__webpack_require__.bind(null, 1418)),
    HomeAfterBannerInvited: () => __webpack_require__.e(/* import() */ 106).then(__webpack_require__.bind(null, 1419)),
    HomeAfterBannerEncrypted: () => __webpack_require__.e(/* import() */ 105).then(__webpack_require__.bind(null, 1420)),
    HomeAfterBannerChatView: () => __webpack_require__.e(/* import() */ 72).then(__webpack_require__.bind(null, 1421)),
    HomeAfterBannerPrivateGroup: () => __webpack_require__.e(/* import() */ 73).then(__webpack_require__.bind(null, 1422))
  }
});
// CONCATENATED MODULE: ./components/organisms/v2/Home/AfterBanner.vue?vue&type=script&lang=js&
 /* harmony default export */ var Home_AfterBannervue_type_script_lang_js_ = (AfterBannervue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/organisms/v2/Home/AfterBanner.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1212)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Home_AfterBannervue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "7dc00c3a",
  "d2e7ff94"
  
)

/* harmony default export */ var AfterBanner = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 569:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/feature-1.ad904d2.png";

/***/ }),

/***/ 949:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1213);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("47a0e8e5", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=108.js.map
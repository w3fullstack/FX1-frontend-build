exports.ids = [27];
exports.modules = {

/***/ 1137:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Unsupported_vue_vue_type_style_index_0_id_8cba7970_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(912);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Unsupported_vue_vue_type_style_index_0_id_8cba7970_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Unsupported_vue_vue_type_style_index_0_id_8cba7970_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Unsupported_vue_vue_type_style_index_0_id_8cba7970_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Unsupported_vue_vue_type_style_index_0_id_8cba7970_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1138:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xt-locker-room-unsupported[data-v-8cba7970]{width:100%}.xt-locker-room-unsupported[data-v-8cba7970] .h100vh{height:100vh!important;border-left:1px solid #385860!important}.xt-locker-room-unsupported[data-v-8cba7970] .chat-container,.xt-locker-room-unsupported[data-v-8cba7970] .xo-locker-room-channels{height:calc(100vh - 170px)}@media screen and (max-width:767px){.xt-locker-room-unsupported[data-v-8cba7970] .chat-container,.xt-locker-room-unsupported[data-v-8cba7970] .xo-locker-room-channels{height:calc(100vh - 70px)}}@media screen and (max-width:767px){.xt-locker-room-unsupported[data-v-8cba7970] .chat-container .xo-channels-chat-header{background-color:#f85454}}@media screen and (max-width:767px){.xt-locker-room-unsupported[data-v-8cba7970] .chat-container .xo-channels-chat-header .right-chat-header{display:none}}.xt-locker-room-unsupported[data-v-8cba7970] .chat-container .xo-channels-chat-header .support{display:none}@media screen and (max-width:767px){.xt-locker-room-unsupported[data-v-8cba7970] .chat-container .xo-channels-chat-header .support{display:block}}.xt-locker-room-unsupported[data-v-8cba7970] .chat-container .chat-history-container.vb>.vb-dragger{z-index:5;width:12px;right:0;opacity:0}.xt-locker-room-unsupported[data-v-8cba7970] .chat-container .chat-history-container.vb>.vb-dragger>.vb-dragger-styler{backface-visibility:hidden;transform:rotate3d(0,0,0,0);transition:background-color .1s ease-out,margin .1s ease-out,height .1s ease-out;background-color:#08252c;margin:5px 2px 0;border-radius:20px;height:calc(100% - 10px);display:block}.xt-locker-room-unsupported[data-v-8cba7970] .chat-container .chat-history-container.vb>.vb-dragger:hover>.vb-dragger-styler{background-color:#08252c;height:100%}.xt-locker-room-unsupported[data-v-8cba7970] .chat-container .chat-history-container.vb.vb-scrolling-phantom>.vb-dragger>.vb-dragger-styler{background-color:#08252c}.xt-locker-room-unsupported[data-v-8cba7970] .chat-container .chat-history-container.vb.vb-dragging>.vb-dragger>.vb-dragger-styler{background-color:#08252c;height:100%}.xt-locker-room-unsupported[data-v-8cba7970] .chat-container .chat-history-container.vb.vb-dragging-phantom>.vb-dragger>.vb-dragger-styler{background-color:#08252c}.xt-locker-room-unsupported[data-v-8cba7970] .chat-container .chat-history-container.vb:hover>.vb-dragger{opacity:.8}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1354:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/templates/LockerRoom/Unsupported.vue?vue&type=template&id=8cba7970&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xt-locker-room-unsupported"},[(!_vm.isLive)?_c('XOChannelsPreviewBanner'):_vm._e(),_vm._ssrNode("<div class=\"row\" data-v-8cba7970>","</div>",[(!_vm.isLive)?_c('XOLockerRoomChannels'):_vm._e(),_vm._ssrNode("<div"+(_vm._ssrClass("chat-container col flex-column",{ 'h100vh' : _vm.isLive}))+" data-v-8cba7970>","</div>",[_c('XOChannelsChatHeader',{attrs:{"is-supporting":false,"isLive":_vm.isLive}}),_c('div',{directives:[{name:"bar",rawName:"v-bar"}],staticClass:"chat-history-container col"},[_vm._ssrNode("<div class=\"vuebar\" data-v-8cba7970>","</div>",[_c('XOChannelsChatHistory',{attrs:{"chats":_vm.chats}})],1)]),_c('XOChannelsChatInput',{attrs:{"isLive":_vm.isLive}})],1)],1),_c('XMChannelsChatLightbox')],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/templates/LockerRoom/Unsupported.vue?vue&type=template&id=8cba7970&scoped=true&lang=pug&

// EXTERNAL MODULE: external "vuex"
var external_vuex_ = __webpack_require__(4);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/templates/LockerRoom/Unsupported.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var Unsupportedvue_type_script_lang_js_ = ({
  name: 'XTLockerRoomUnsupported',
  components: {
    XOChannelsPreviewBanner: () => __webpack_require__.e(/* import() */ 65).then(__webpack_require__.bind(null, 1384)),
    XOLockerRoomChannels: () => __webpack_require__.e(/* import() */ 8).then(__webpack_require__.bind(null, 570)),
    XAChannelsAccount: () => __webpack_require__.e(/* import() */ 19).then(__webpack_require__.bind(null, 1385)),
    XAChannelOptions: () => __webpack_require__.e(/* import() */ 68).then(__webpack_require__.bind(null, 1299)),
    XOChannelsChatHeader: () => __webpack_require__.e(/* import() */ 69).then(__webpack_require__.bind(null, 1298)),
    XOChannelsChatHistory: () => __webpack_require__.e(/* import() */ 12).then(__webpack_require__.bind(null, 677)),
    XOChannelsChatInput: () => __webpack_require__.e(/* import() */ 63).then(__webpack_require__.bind(null, 571)),
    XMChannelsChatLightbox: () => __webpack_require__.e(/* import() */ 5).then(__webpack_require__.bind(null, 1383))
  },
  data() {
    return {
      media: []
    };
  },
  computed: {
    ...Object(external_vuex_["mapGetters"])({
      getMediaLightbox: 'media/getMediaLightbox'
    }),
    chats() {
      var _this$$parent;
      return ((_this$$parent = this.$parent) === null || _this$$parent === void 0 ? void 0 : _this$$parent.chats) || [];
    },
    channel() {
      var _this$$parent2;
      return ((_this$$parent2 = this.$parent) === null || _this$$parent2 === void 0 ? void 0 : _this$$parent2.channel) || {};
    },
    isLive() {
      var _this$$parent3;
      return ((_this$$parent3 = this.$parent) === null || _this$$parent3 === void 0 ? void 0 : _this$$parent3.isLive) || false;
    }
  },
  mounted() {
    this.$root.$on('evtRtScrollToBottom', () => {
      this.fnScrollToBottom();
    });
    this.fnScrollToBottom();
    this.$root.$on('evtRtSetLightboxMedia', value => {
      this.media = value;
    });
    this.$root.$on('evtRtShowLightbox', index => {
      if (this.media.length) {
        var _this$$refs$lightboxG;
        (_this$$refs$lightboxG = this.$refs.lightboxGallery) === null || _this$$refs$lightboxG === void 0 ? void 0 : _this$$refs$lightboxG.showImage(index);
      }
    });
  },
  methods: {
    fnScrollToBottom() {
      const element = document.querySelector('.chat-history-container .vuebar');
      element.scrollTop = element.scrollHeight;
    }
  }
});
// CONCATENATED MODULE: ./components/templates/LockerRoom/Unsupported.vue?vue&type=script&lang=js&
 /* harmony default export */ var LockerRoom_Unsupportedvue_type_script_lang_js_ = (Unsupportedvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/templates/LockerRoom/Unsupported.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1137)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  LockerRoom_Unsupportedvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "8cba7970",
  "252da639"
  
)

/* harmony default export */ var Unsupported = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 912:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1138);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("1a048734", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=27.js.map
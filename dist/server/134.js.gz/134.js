exports.ids = [134];
exports.modules = {

/***/ 1268:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FanLeaderBoard_vue_vue_type_style_index_0_id_4fa18ac7_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(977);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FanLeaderBoard_vue_vue_type_style_index_0_id_4fa18ac7_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FanLeaderBoard_vue_vue_type_style_index_0_id_4fa18ac7_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FanLeaderBoard_vue_vue_type_style_index_0_id_4fa18ac7_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FanLeaderBoard_vue_vue_type_style_index_0_id_4fa18ac7_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1269:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7]{position:relative}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .small-tags{position:absolute;width:-moz-max-content;width:max-content;border-radius:4px;padding:14px 18px;-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);text-align:center;font-size:16px;line-height:1.25;letter-spacing:-.28px;background-color:hsla(0,0%,100%,.6);color:#08252c;border:1px solid hsla(0,0%,100%,.8);box-shadow:0 6px 20px rgba(0,0,0,.13)}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .small-tags.light-green{background-color:rgba(12,53,62,.7);color:#fff;border-color:#385960}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .news{top:38%;right:-5%}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .live-score{top:3%;left:-8%}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .event-invites{bottom:-1%;left:-4%}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .team-rivalries{top:35%;left:-5%}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .epic-games{bottom:11%;left:-20%}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .statistics{top:10%;right:-5%}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .frame-people{position:absolute;bottom:-30%;right:-5%;padding:8px;display:flex;flex-direction:column;grid-gap:8px;gap:8px;width:-moz-max-content;width:max-content;background-color:hsla(0,0%,100%,.4);border:1px solid hsla(0,0%,100%,.6);box-shadow:0 6px 20px rgba(0,0,0,.13);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);border-radius:10px}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard{position:relative}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard img{border-radius:12px}@media screen and (max-width:1439px){.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard .small-tags{font-size:14px;line-height:1.1;padding:12px 14px}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard .frame-people{padding:6px}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard .frame-people img{width:44px}}@media screen and (max-width:1023px){.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard .small-tags{font-size:12px;padding:10px}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard .frame-people{padding:5px;right:4%;bottom:-27%}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard .frame-people img{width:35px}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard .live-score{left:-7%;top:-6%}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard .epic-games{left:-7%}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard .team-rivalries{left:-2%}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard .statistics{right:-3%}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard .news{right:-2%}}@media screen and (max-width:767px){.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard .small-tags{padding:10px 12px}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard .frame-people img{width:35px}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard .live-score{left:-5%}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard .epic-games{left:-6%}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard .team-rivalries{left:-2%}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard .statistics{right:-3%}.xm-home-catalogs-fan-leaderboard[data-v-4fa18ac7] .fan-leaderboard .news{right:-2%}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1423:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/v2/Home/Catalogs/FanLeaderBoard.vue?vue&type=template&id=4fa18ac7&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xm-home-catalogs-fan-leaderboard row justify-center"},[_vm._ssrNode("<div class=\"fan-leaderboard\" data-v-4fa18ac7>","</div>",[_c('nuxt-img',{attrs:{"src":"/v2/Home/shutterstock.svg","format":"webp"}}),_vm._ssrNode("<div class=\"live-score small-tags light-green\" data-v-4fa18ac7># live score</div><div class=\"team-rivalries small-tags\" data-v-4fa18ac7># team rivalries</div><div class=\"event-invites small-tags light-green\" data-v-4fa18ac7># event invites</div><div class=\"epic-games small-tags\" data-v-4fa18ac7># epic games</div><div class=\"statistics small-tags light-green\" data-v-4fa18ac7># statistics</div><div class=\"news small-tags\" data-v-4fa18ac7># news</div>"),_vm._ssrNode("<div class=\"frame-people\" data-v-4fa18ac7>","</div>",_vm._l((_vm.frameAvatarUrls),function(url,index){return _c('nuxt-img',{key:index,attrs:{"src":url,"format":"webp","width":"56","height":"56"}})}),1)],2)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/v2/Home/Catalogs/FanLeaderBoard.vue?vue&type=template&id=4fa18ac7&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/v2/Home/Catalogs/FanLeaderBoard.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var FanLeaderBoardvue_type_script_lang_js_ = ({
  name: 'XMHomeCatalogsFanLeaderboard',
  data() {
    return {
      frameAvatarUrls: ['/v2/Home/frame-person-1.png', '/v2/Home/frame-person-2.png', '/v2/Home/frame-person-3.png']
    };
  }
});
// CONCATENATED MODULE: ./components/molecules/v2/Home/Catalogs/FanLeaderBoard.vue?vue&type=script&lang=js&
 /* harmony default export */ var Catalogs_FanLeaderBoardvue_type_script_lang_js_ = (FanLeaderBoardvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/v2/Home/Catalogs/FanLeaderBoard.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1268)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Catalogs_FanLeaderBoardvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "4fa18ac7",
  "11fc86e6"
  
)

/* harmony default export */ var FanLeaderBoard = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 977:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1269);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("24f7df24", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=134.js.map
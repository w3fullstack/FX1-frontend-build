exports.ids = [91];
exports.modules = {

/***/ 1214:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ConnectAPP_vue_vue_type_style_index_0_id_73888e40_prod_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(950);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ConnectAPP_vue_vue_type_style_index_0_id_73888e40_prod_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ConnectAPP_vue_vue_type_style_index_0_id_73888e40_prod_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ConnectAPP_vue_vue_type_style_index_0_id_73888e40_prod_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ConnectAPP_vue_vue_type_style_index_0_id_73888e40_prod_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1215:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".get-app-connect-container[data-v-73888e40]{background:#000;padding-top:80px;padding-bottom:130px;position:relative}.get-app-connect-container .container .get-app-connect[data-v-73888e40]{border-radius:10px;background:linear-gradient(276deg,#3416a3 2.92%,rgba(41,14,139,0) 69.22%),#4f3b98;box-shadow:0 1.4113px 3.95718px 0 rgba(79,59,152,.12),0 3.39155px 9.50965px 0 rgba(79,59,152,.17),0 6.38599px 17.90582px 0 rgba(79,59,152,.21),0 11.39152px 31.94092px 0 rgba(79,59,152,.25),0 21.30658px 59.74198px 0 rgba(79,59,152,.3),0 51px 143px 0 rgba(79,59,152,.42);padding:45px 80px 75px;grid-gap:12px;gap:12px}.get-app-connect-container .container .get-app-connect .happy-smile-img .happy-smiling[data-v-73888e40]{position:absolute;right:-10%;bottom:0}.get-app-connect-container .container .get-app-connect p.txt-intro[data-v-73888e40]{max-width:382px;letter-spacing:.18px;z-index:1}.get-app-connect-container .container .get-app-connect .app-logo[data-v-73888e40]{margin-top:28px;grid-gap:32px;gap:32px;z-index:1}.get-app-connect-container .container .get-app-connect .app-logo img[data-v-73888e40]:hover{opacity:.8}@media screen and (max-width:1439px){.get-app-connect-container[data-v-73888e40]{padding:55px 0}.get-app-connect-container .container .get-app-connect[data-v-73888e40]{padding:65px 40px}.get-app-connect-container .container .get-app-connect .happy-smile-img .happy-smiling[data-v-73888e40]{width:635px;right:-4%}.get-app-connect-container .container .get-app-connect p.txt-title[data-v-73888e40]{letter-spacing:.36px}.get-app-connect-container .container .get-app-connect .app-logo[data-v-73888e40]{margin-top:18px}.get-app-connect-container .container .get-app-connect .app-logo a img[data-v-73888e40]{width:152px;height:44px}}@media screen and (max-width:1023px){.get-app-connect-container .container .get-app-connect[data-v-73888e40]{padding:46px 40px}.get-app-connect-container .container .get-app-connect p.txt-intro[data-v-73888e40]{max-width:284px}.get-app-connect-container .container .get-app-connect .app-logo[data-v-73888e40]{flex-flow:column;grid-gap:12px;gap:12px}}@media screen and (max-width:767px){.get-app-connect-container[data-v-73888e40]{padding:145px 0 50px}.get-app-connect-container .container .get-app-connect[data-v-73888e40]{padding:30px 20px 0;justify-content:flex-start;overflow:hidden}.get-app-connect-container .container .get-app-connect .happy-smile-img[data-v-73888e40]{width:431px}.get-app-connect-container .container .get-app-connect .happy-smile-img .happy-smiling[data-v-73888e40]{position:unset;margin-bottom:-7px;margin-left:-68px}.get-app-connect-container .container .get-app-connect p.txt-title[data-v-73888e40]{letter-spacing:.28 px}.get-app-connect-container .container .get-app-connect p.txt-intro[data-v-73888e40]{max-width:100%}.get-app-connect-container .container .get-app-connect .app-logo[data-v-73888e40]{margin-top:8px;flex-flow:row;grid-gap:20px;gap:20px}.get-app-connect-container .container .get-app-connect .app-logo a img[data-v-73888e40]{width:110px;height:40px}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1388:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/v2/Home/ConnectAPP.vue?vue&type=template&id=73888e40&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return (_vm.$route.path != '/error')?_c('div',{staticClass:"get-app-connect-container"},[_vm._ssrNode("<div class=\"container is-max-widescreen\" data-v-73888e40><div class=\"get-app-connect flex-column\" data-v-73888e40><p class=\"txt-title text-weight-regular\" data-v-73888e40>Get App</p><p class=\"txt-intro text-weight-light\" data-v-73888e40>We worked hard building our app to ensure you'll love using it</p><div class=\"app-logo row\" data-v-73888e40><a href=\"https://apps.apple.com/us/app/fx1/id1626034650\" target=\"_blank\" data-v-73888e40><img"+(_vm._ssrAttr("src",__webpack_require__(451)))+" alt=\"App Store\" data-v-73888e40></a><a href=\"https://play.google.com/store/apps/details?id=io.fx1.sports\" target=\"_blank\" data-v-73888e40><img"+(_vm._ssrAttr("src",__webpack_require__(452)))+" alt=\"Playstore\" data-v-73888e40></a></div><div class=\"happy-smile-img\" data-v-73888e40><img"+(_vm._ssrAttr("src",__webpack_require__(659)))+" class=\"happy-smiling\" data-v-73888e40></div></div></div>")]):_vm._e()}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/v2/Home/ConnectAPP.vue?vue&type=template&id=73888e40&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/v2/Home/ConnectAPP.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var ConnectAPPvue_type_script_lang_js_ = ({
  name: 'XOConnectAPP'
});
// CONCATENATED MODULE: ./components/organisms/v2/Home/ConnectAPP.vue?vue&type=script&lang=js&
 /* harmony default export */ var Home_ConnectAPPvue_type_script_lang_js_ = (ConnectAPPvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/organisms/v2/Home/ConnectAPP.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1214)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Home_ConnectAPPvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "73888e40",
  "b1dc708e"
  
)

/* harmony default export */ var ConnectAPP = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 451:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/appstore.2854c99.svg";

/***/ }),

/***/ 452:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/googleplay.9921262.svg";

/***/ }),

/***/ 659:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/happy-young.8764fa3.png";

/***/ }),

/***/ 950:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1215);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("0d093ae2", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=91.js.map
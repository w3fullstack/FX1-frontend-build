exports.ids = [16];
exports.modules = {

/***/ 1176:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_style_index_0_id_daf32356_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(931);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_style_index_0_id_daf32356_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_style_index_0_id_daf32356_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_style_index_0_id_daf32356_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_style_index_0_id_daf32356_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1177:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(24);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(642);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".token-banner[data-v-daf32356]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");background-size:100% 100%;background-repeat:no-repeat;min-height:950px;width:auto;position:relative;overflow:hidden;padding:200px 0}@media screen and (max-width:1700px){.token-banner[data-v-daf32356]{padding:150px 0 200px}}@media screen and (max-width:1400px){.token-banner[data-v-daf32356]{padding:120px 0 200px}}@media screen and (max-width:1215px){.token-banner[data-v-daf32356]{padding:200px 0}}@media screen and (max-width:700px){.token-banner[data-v-daf32356]{background-size:cover;background-position:40% 50%}}@media screen and (max-width:500px){.token-banner[data-v-daf32356]{padding:170px 0 0;min-height:100vh;background-position:40% 50%}}.token-banner[data-v-daf32356] .overlay{width:100%;height:100%;top:0;background-color:rgba(24,120,141,.25);z-index:1;position:absolute}.token-banner[data-v-daf32356] .content-middle{position:relative;z-index:1;width:100%;margin:auto;max-width:962px}.token-banner[data-v-daf32356] .content-middle .actions{margin:50px 0 25px}.token-banner[data-v-daf32356] .content-middle .actions .button{width:235px;height:82px;text-transform:uppercase;margin-left:10px;margin-right:10px}.token-banner[data-v-daf32356] .content-middle .actions .button:last-child{background-color:#0c353e}.token-banner[data-v-daf32356] .content-middle h2{font-size:1.5714rem;line-height:2.4286rem;letter-spacing:-.66px;max-width:700px;margin:auto}.token-banner[data-v-daf32356] .content-middle .launch-text span{color:hsla(0,0%,100%,.8)}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1373:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/Banner.vue?vue&type=template&id=daf32356&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"token-banner row"},[_vm._ssrNode("<div class=\"overlay\" data-v-daf32356></div><div class=\"container is-max-widescreen\" data-v-daf32356><div class=\"content-middle text-center\" data-v-daf32356><h1 class=\"token-h1\" data-v-daf32356>Invite your friends, get paid in $FX1</h1><h2 class=\"token-h2-c\" data-v-daf32356>The $FX1 token serves as a central piece to the FX1 ecosystem. You use $FX1 for purchases, and you’ll be able to earn it by introducing us to your friends, family and existing communities.</h2><div class=\"actions\" data-v-daf32356><a href=\"https://app.uniswap.org/#/swap?outputCurrency=0x610C584F1275f0f7c982Af0aC7883Ff4Dba661Bd\" target=\"_blank\" class=\"button is-primary\" data-v-daf32356>Buy $FX1</a><a href=\"https://www.dextools.io/app/en/ether/pair-explorer/0x87B958067FD665f3937de4439450B4950Eb68e15\" target=\"_blank\" class=\"button is-primary\" data-v-daf32356>View Chart</a></div><span class=\"address\" data-v-daf32356>Contract Address:<span data-v-daf32356>0x610C584F1275f0f7c982Af0aC7883Ff4Dba661Bd</span></span></div></div>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Token/Banner.vue?vue&type=template&id=daf32356&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/Banner.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Bannervue_type_script_lang_js_ = ({
  name: 'TokenBanner',
  methods: {
    showAlertMessage() {
      this.$toast.success('$FX1 available to purchase mid to late April', {
        duration: 5000,
        position: 'bottom-left',
        className: 'fx1-success'
      });
    }
  }
});
// CONCATENATED MODULE: ./components/molecules/Token/Banner.vue?vue&type=script&lang=js&
 /* harmony default export */ var Token_Bannervue_type_script_lang_js_ = (Bannervue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/Token/Banner.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1176)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Token_Bannervue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "daf32356",
  "464c58c8"
  
)

/* harmony default export */ var Banner = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 642:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/empty-boxing-arena.2197abf.png";

/***/ }),

/***/ 931:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1177);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("957f6d9e", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=16.js.map
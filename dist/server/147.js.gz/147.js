exports.ids = [147];
exports.modules = {

/***/ 1099:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_LeaguesAndClubs_vue_vue_type_style_index_0_id_3a628702_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(893);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_LeaguesAndClubs_vue_vue_type_style_index_0_id_3a628702_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_LeaguesAndClubs_vue_vue_type_style_index_0_id_3a628702_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_LeaguesAndClubs_vue_vue_type_style_index_0_id_3a628702_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_LeaguesAndClubs_vue_vue_type_style_index_0_id_3a628702_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1100:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".page-content[data-v-3a628702]{min-height:calc(100vh - 406px);border-bottom:1px solid #1c3e45;background-color:#0c353e;padding:50px 0}.page-content[data-v-3a628702] a{color:#15c!important}.page-content[data-v-3a628702] .bottom-border{border-bottom:1px solid #1c3e45}.page-content[data-v-3a628702] h1{font-size:3rem;line-height:1.2;margin-bottom:30px;letter-spacing:0}.page-content[data-v-3a628702] h2{font-size:1.5714rem;font-weight:500;margin-bottom:.75rem}.page-content[data-v-3a628702] h3{font-size:1.5714rem;line-height:1.2;margin:40px 0 20px}.page-content[data-v-3a628702] p{font-size:1.1429rem;font-weight:300;margin-bottom:20px}.page-content[data-v-3a628702] ul{margin:0;padding:0}.page-content[data-v-3a628702] ul li{font-size:1.1429rem;font-weight:300;margin-bottom:15px;margin-left:15px;list-style:disc}.page-content[data-v-3a628702] ul li ul li{list-style:circle}.page-content[data-v-3a628702] pre{display:block;padding:.7143rem;word-break:break-all;background-color:#f5f5f5;border:1px solid #ccc;border-radius:5px;font-size:12px;white-space:pre-line;margin-bottom:.7143rem}.page-content[data-v-3a628702] pre span{display:block}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1347:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/LeaguesAndClubs.vue?vue&type=template&id=3a628702&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"page-content"},[_vm._ssrNode("<div class=\"container is-max-desktop\" data-v-3a628702><h1 data-v-3a628702>A new way to engage with your fans and members</h1><p data-v-3a628702>The place for sports governing bodies, clubs, and leagues to generate increased revenue while at the same time growing fan engagement.</p><p data-v-3a628702>[ APPLY FOR EARLY ACCESS ]</p><h3 data-v-3a628702>Create your clubs Locker Room</h3><p data-v-3a628702>Locker Rooms are uniquely created by each club or league and offer their supporters a new digital experience only accessible on FX1.</p><h3 data-v-3a628702>Add &amp; customize channels to your liking</h3><p data-v-3a628702>Channels are the heartbeat of a Locker Room. Create as many channels as you feel is needed, and customize them how you see fit.</p><h3 data-v-3a628702>Invite your team and all your fans</h3><p data-v-3a628702>Easily share your Locker Room with all your fans, and with just a few clicks invite your staff and management team to help oversee the room.</p><h3 data-v-3a628702>Give your fans and members a new game or race day experience</h3><p data-v-3a628702>The day of the game (or event) is exciting, and now you can bring it to the next level by having a channel dedicated to the day where all your fans will be.</p><h3 data-v-3a628702>Your new #1 marketing channel</h3><p data-v-3a628702>For years sporting organizations and clubs have been forced to invest their time and hardearned money into social platforms that were never fit for purpose. FX1 changes all of that,\nnot only providing a home for your fans and supporters to talk and engage with each other,\nbut a way for you to generate additional income.</p><ul data-v-3a628702><li data-v-3a628702>Create digital membership tiers that your fans and supporters can purchase</li><li data-v-3a628702>Generate revenue from membership sales, including any secondary sales</li><li data-v-3a628702>Increase your percentage of supporters to paid members, especially from the ~95% of fans that never attend a game live</li><li data-v-3a628702>Earn new fans based on the number of supporters in your Locker Room and the engagement and noise those supporters generate</li><li data-v-3a628702>Use FX1 for your on ground ticketing, and benefit from every sale including any secondary sales from supporters, or even scalpers</li></ul><p data-v-3a628702><i data-v-3a628702>* Digital Membership &amp; Ticketing Offering - Coming Soon</i></p><h3 data-v-3a628702>Who is FX1?</h3><p data-v-3a628702>1. Register your interest using the form below</p><p data-v-3a628702>2. We’ll review and decide if your a good fit for our beta program</p><p data-v-3a628702>3. If approved, your Locker Room will be created, and you can start creating channels</p><p data-v-3a628702>4. Invite all your members and fans to come and be part of your Locker Room</p></div>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/pages/LeaguesAndClubs.vue?vue&type=template&id=3a628702&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/LeaguesAndClubs.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var LeaguesAndClubsvue_type_script_lang_js_ = ({
  name: 'XPLeaguesAndClubs'
});
// CONCATENATED MODULE: ./components/pages/LeaguesAndClubs.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_LeaguesAndClubsvue_type_script_lang_js_ = (LeaguesAndClubsvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/pages/LeaguesAndClubs.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1099)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pages_LeaguesAndClubsvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "3a628702",
  "ffbb56d0"
  
)

/* harmony default export */ var LeaguesAndClubs = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 893:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1100);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("0f6fe999", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=147.js.map
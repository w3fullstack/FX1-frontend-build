exports.ids = [2];
exports.modules = {

/***/ 1178:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_RightContent_vue_vue_type_style_index_0_id_8efb0108_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(932);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_RightContent_vue_vue_type_style_index_0_id_8efb0108_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_RightContent_vue_vue_type_style_index_0_id_8efb0108_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_RightContent_vue_vue_type_style_index_0_id_8efb0108_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_RightContent_vue_vue_type_style_index_0_id_8efb0108_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1179:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(24);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(593);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xm-signup-right-content[data-v-8efb0108]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");background-repeat:no-repeat;background-size:cover;position:relative;padding:50px}@media screen and (max-width:1023px){.xm-signup-right-content[data-v-8efb0108]{background-position:50%;padding:50px 50px 35px;min-height:345px;display:flex;flex-wrap:wrap;align-items:center}}@media screen and (max-width:767px){.xm-signup-right-content[data-v-8efb0108]{padding:30px 30px 15px}}.xm-signup-right-content[data-v-8efb0108]:after,.xm-signup-right-content[data-v-8efb0108]:before{content:\"\";position:absolute;left:0;width:100%;z-index:1}.xm-signup-right-content[data-v-8efb0108]:before{top:0;background-image:linear-gradient(#0c353e,rgba(12,53,62,0));height:300px}@media screen and (max-width:1023px){.xm-signup-right-content[data-v-8efb0108]:before{content:none}}.xm-signup-right-content[data-v-8efb0108]:after{bottom:0;background-image:linear-gradient(rgba(12,53,62,0) 20%,#0c353e 60%);height:500px}@media screen and (max-width:1023px){.xm-signup-right-content[data-v-8efb0108]:after{background-image:linear-gradient(0deg,rgba(12,53,62,.4),rgba(12,53,62,.4)),linear-gradient(180deg,rgba(12,53,62,0) 52.63%,#0c353e 76.9%);height:100%}}.xm-signup-right-content[data-v-8efb0108] .contents{position:relative;z-index:2;height:100%}@media screen and (max-width:1023px){.xm-signup-right-content[data-v-8efb0108] .contents{height:auto}}@media screen and (max-width:1023px){.xm-signup-right-content[data-v-8efb0108] .contents .logo{display:none}}.xm-signup-right-content[data-v-8efb0108] .contents .description .item{background-color:hsla(0,0%,100%,.2);border-radius:10px;padding:20px;width:calc(50% - 7.5px);color:#fff;font-size:16px;line-height:24px;letter-spacing:-.28px;font-weight:300;margin-bottom:15px}@media screen and (max-width:767px){.xm-signup-right-content[data-v-8efb0108] .contents .description .item{width:100%}}.xm-signup-right-content[data-v-8efb0108] .contents .description .item ._icon{opacity:.4;margin-right:20px}@media screen and (max-width:1023px){.xm-signup-right-content[data-v-8efb0108].create-new-password,.xm-signup-right-content[data-v-8efb0108].forgot-password,.xm-signup-right-content[data-v-8efb0108].signin{display:none}}.xm-signup-right-content[data-v-8efb0108].create-new-password:after,.xm-signup-right-content[data-v-8efb0108].forgot-password:after,.xm-signup-right-content[data-v-8efb0108].signin:after{display:none}.xm-signup-right-content[data-v-8efb0108].create-new-password:before,.xm-signup-right-content[data-v-8efb0108].forgot-password:before,.xm-signup-right-content[data-v-8efb0108].signin:before{background-image:linear-gradient(0deg,rgba(12,53,62,.2),rgba(12,53,62,.2));width:100%;height:100%}.xm-signup-right-content[data-v-8efb0108].create-new-password .contents .description,.xm-signup-right-content[data-v-8efb0108].forgot-password .contents .description,.xm-signup-right-content[data-v-8efb0108].signin .contents .description{display:none}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1374:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/SignUp/RightContent.vue?vue&type=template&id=8efb0108&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xm-signup-right-content",class:_vm.$route.name},[_vm._ssrNode("<div class=\"contents flex-column justify-between\" data-v-8efb0108>","</div>",[_c('nuxt-link',{staticClass:"logo",attrs:{"to":"/"}},[_c('img',{attrs:{"src":__webpack_require__(89),"width":"96","height":"40"}})]),_vm._ssrNode("<div class=\"description row justify-between\" data-v-8efb0108><div class=\"item row items-center\" data-v-8efb0108><div class=\"_icon\" data-v-8efb0108><img"+(_vm._ssrAttr("src",__webpack_require__(597)))+" data-v-8efb0108></div><div class=\"text col\" data-v-8efb0108>Show the world who you support</div></div><div class=\"item row items-center\" data-v-8efb0108><div class=\"_icon\" data-v-8efb0108><img"+(_vm._ssrAttr("src",__webpack_require__(595)))+" data-v-8efb0108></div><div class=\"text col\" data-v-8efb0108>Be there with your team on Game Day</div></div><div class=\"item row items-center\" data-v-8efb0108><div class=\"_icon\" data-v-8efb0108><img"+(_vm._ssrAttr("src",__webpack_require__(596)))+" data-v-8efb0108></div><div class=\"text col\" data-v-8efb0108>Level-up your rank in the fan leaderboard</div></div><div class=\"item row items-center\" data-v-8efb0108><div class=\"_icon\" data-v-8efb0108><img"+(_vm._ssrAttr("src",__webpack_require__(592)))+" data-v-8efb0108></div><div class=\"text col\" data-v-8efb0108>Access news, injury lists, player reports, and more</div></div></div>")],2)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/SignUp/RightContent.vue?vue&type=template&id=8efb0108&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/SignUp/RightContent.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var RightContentvue_type_script_lang_js_ = ({
  name: 'XMSignUpRightContent'
});
// CONCATENATED MODULE: ./components/molecules/SignUp/RightContent.vue?vue&type=script&lang=js&
 /* harmony default export */ var SignUp_RightContentvue_type_script_lang_js_ = (RightContentvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/SignUp/RightContent.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1178)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  SignUp_RightContentvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "8efb0108",
  "8ab64a50"
  
)

/* harmony default export */ var RightContent = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 592:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/access.ab4c15c.svg";

/***/ }),

/***/ 593:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/bg-right-content.dfa25ff.svg";

/***/ }),

/***/ 595:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/game-day.440a044.svg";

/***/ }),

/***/ 596:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/leaderboard.b93c900.svg";

/***/ }),

/***/ 597:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/support.850e507.svg";

/***/ }),

/***/ 932:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1179);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("579ec140", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=2.js.map
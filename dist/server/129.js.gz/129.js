exports.ids = [129];
exports.modules = {

/***/ 1043:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_LoggedInMobileView_vue_vue_type_style_index_0_id_52344ee1_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(865);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_LoggedInMobileView_vue_vue_type_style_index_0_id_52344ee1_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_LoggedInMobileView_vue_vue_type_style_index_0_id_52344ee1_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_LoggedInMobileView_vue_vue_type_style_index_0_id_52344ee1_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_LoggedInMobileView_vue_vue_type_style_index_0_id_52344ee1_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1044:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xm-locker-room-header-guest-menu[data-v-52344ee1]{position:fixed;top:0;left:0;width:100%;z-index:99;background-color:#2a4e55}.xm-locker-room-header-guest-menu[data-v-52344ee1] .close{position:absolute;top:20px;right:20px}.xm-locker-room-header-guest-menu[data-v-52344ee1] .btn-signin{text-transform:uppercase;width:125px;height:42px;cursor:pointer;color:#fff;display:inline!important;padding:9px 30px!important}.xm-locker-room-header-guest-menu[data-v-52344ee1] .logout{color:#f85454!important}.xm-locker-room-header-guest-menu[data-v-52344ee1] .menu-section{display:flex;align-items:center;text-transform:none;font-size:1.1429rem;font-weight:300;border-top:1px solid hsla(0,0%,100%,.2);padding:15px 30px 0;margin-top:15px;color:#fff}.xm-locker-room-header-guest-menu[data-v-52344ee1] .menu-section:first-child{margin-top:0}.xm-locker-room-header-guest-menu[data-v-52344ee1] .menu-section .marg-left{margin-left:10px}.xm-locker-room-header-guest-menu[data-v-52344ee1] .navigation-menu{padding:60px 0 25px}.xm-locker-room-header-guest-menu[data-v-52344ee1] .navigation-menu a{display:block;text-transform:none;font-size:1.1429rem;font-weight:300;border-top:1px solid hsla(0,0%,100%,.2);padding:15px 30px 0;margin-top:15px;color:#fff}.xm-locker-room-header-guest-menu[data-v-52344ee1] .navigation-menu a:first-child{margin-top:0}.xm-locker-room-header-guest-menu[data-v-52344ee1] .navigation-menu a.profile{display:flex;align-items:center;grid-gap:10px;gap:10px}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1395:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/LockerRoom/Header/LoggedInMobileView.vue?vue&type=template&id=52344ee1&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xm-locker-room-header-guest-menu"},[_vm._ssrNode("<div class=\"close\" data-v-52344ee1>","</div>",[_c('b-icon',{attrs:{"icon":"close","custom-size":"mdi-24px"}})],1),_vm._ssrNode("<div class=\"navigation-menu\" data-v-52344ee1>","</div>",[(_vm.isLoggedIn)?[_vm._ssrNode("<div class=\"menu-section\" data-v-52344ee1>","</div>",[_c('XAMyLocation',{attrs:{"inMobileMenu":true}})],1),_c('nuxt-link',{staticClass:"profile",attrs:{"to":"/account/settings"}},[_c('XAMyAvatar'),_c('p',{staticClass:"marg-left"},[_vm._v("My Account")])],1),(_vm.isHomePage)?_c('nuxt-link',{attrs:{"to":"/token"}},[_vm._v("$FX1 Token")]):_vm._e(),(_vm.isHomePage)?_c('nuxt-link',{attrs:{"to":"/locker-room/explore"}},[_vm._v("Customer Support")]):_vm._e(),(_vm.isHomePage)?_c('nuxt-link',{attrs:{"to":"/about"}},[_vm._v("About")]):_vm._e(),(_vm.isHomePage)?_c('nuxt-link',{attrs:{"to":"/contact"}},[_vm._v("Contact")]):_vm._e(),(_vm.isHomePage)?_c('nuxt-link',{attrs:{"to":"/business"}},[_vm._v("For Business")]):_vm._e(),_vm._ssrNode("<div class=\"menu-section\" data-v-52344ee1><img"+(_vm._ssrAttr("src",__webpack_require__(91)))+" data-v-52344ee1><div class=\"logout marg-left\" data-v-52344ee1>Log out</div></div>")]:[_vm._ssrNode("<div class=\"menu-section\" data-v-52344ee1>","</div>",[_c('XAMyLocation',{attrs:{"inMobileMenu":true}})],1),(_vm.isHomePage)?_c('nuxt-link',{attrs:{"to":"/token"}},[_vm._v("$FX1 Token")]):_vm._e(),(_vm.isHomePage)?_c('nuxt-link',{attrs:{"to":"/locker-room/explore"}},[_vm._v("Customer Support")]):_vm._e(),(_vm.isHomePage)?_c('nuxt-link',{attrs:{"to":"/about"}},[_vm._v("About")]):_vm._e(),(_vm.isHomePage)?_c('nuxt-link',{attrs:{"to":"/contact"}},[_vm._v("Contact")]):_vm._e(),(_vm.isHomePage)?_c('nuxt-link',{attrs:{"to":"/business"}},[_vm._v("For Business")]):_vm._e(),_vm._ssrNode("<div class=\"menu-section\" data-v-52344ee1>","</div>",[_c('b-button',{staticClass:"btn-signin",attrs:{"type":"is-primary","tag":"router-link","to":"/signin"}},[_vm._v("Sign In")])],1)]],2)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/LockerRoom/Header/LoggedInMobileView.vue?vue&type=template&id=52344ee1&scoped=true&lang=pug&

// EXTERNAL MODULE: external "vuex"
var external_vuex_ = __webpack_require__(4);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/LockerRoom/Header/LoggedInMobileView.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var LoggedInMobileViewvue_type_script_lang_js_ = ({
  name: 'XMLoggedInMobileView',
  components: {
    XAMyLocation: () => __webpack_require__.e(/* import() */ 120).then(__webpack_require__.bind(null, 1431)),
    XAMyAvatar: () => __webpack_require__.e(/* import() */ 4).then(__webpack_require__.bind(null, 1394))
  },
  computed: {
    isHomePage() {
      return this.$route.name === 'index';
    }
  },
  methods: {
    fnToggleMobileMenu() {
      this.$root.$emit('evtRtShowMobileMenu', false);
    },
    ...Object(external_vuex_["mapActions"])({
      authLogOut: 'auth/authLogOut',
      clearAuthDetails: 'auth/clearAuthDetails'
    }),
    async fnLogOut() {
      this.$fireMess.unSubscribeToTopic({
        topicName: this.userID
      });
      await this.authLogOut();
      const disconnect = this.$root.ChatSocket ? this.$root.ChatSocket.disconnect() : null;
      await this.$router.push({
        path: '/'
      });
      this.clearAuthDetails();
      this.$mixpanel.reset();
      return disconnect;
    }
  }
});
// CONCATENATED MODULE: ./components/molecules/LockerRoom/Header/LoggedInMobileView.vue?vue&type=script&lang=js&
 /* harmony default export */ var Header_LoggedInMobileViewvue_type_script_lang_js_ = (LoggedInMobileViewvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/LockerRoom/Header/LoggedInMobileView.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1043)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Header_LoggedInMobileViewvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "52344ee1",
  "2966c3ed"
  
)

/* harmony default export */ var LoggedInMobileView = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 865:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1044);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("2958ab82", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=129.js.map
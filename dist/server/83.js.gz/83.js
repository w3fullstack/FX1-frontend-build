exports.ids = [83];
exports.modules = {

/***/ 1196:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_AfterBanner_vue_vue_type_style_index_0_id_4a8de0db_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(941);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_AfterBanner_vue_vue_type_style_index_0_id_4a8de0db_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_AfterBanner_vue_vue_type_style_index_0_id_4a8de0db_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_AfterBanner_vue_vue_type_style_index_0_id_4a8de0db_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_AfterBanner_vue_vue_type_style_index_0_id_4a8de0db_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1197:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(24);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(610);
var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(627);
var ___CSS_LOADER_URL_IMPORT_2___ = __webpack_require__(629);
var ___CSS_LOADER_URL_IMPORT_3___ = __webpack_require__(636);
var ___CSS_LOADER_URL_IMPORT_4___ = __webpack_require__(635);
var ___CSS_LOADER_URL_IMPORT_5___ = __webpack_require__(630);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
var ___CSS_LOADER_URL_REPLACEMENT_2___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_2___);
var ___CSS_LOADER_URL_REPLACEMENT_3___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_3___);
var ___CSS_LOADER_URL_REPLACEMENT_4___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_4___);
var ___CSS_LOADER_URL_REPLACEMENT_5___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_5___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xp-token[data-v-4a8de0db]{background-color:#08252c;min-height:calc(100vh - 683px);position:relative}@media screen and (max-width:500px){.xp-token[data-v-4a8de0db]{overflow-x:hidden}}.xp-token[data-v-4a8de0db] .circle-1{top:-54.6%;position:absolute;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");background-position:50%;background-repeat:no-repeat;width:100%;height:100%;overflow:hidden;z-index:0;opacity:.4;zoom:1.3}@media screen and (max-width:1021px){.xp-token[data-v-4a8de0db] .circle-1{zoom:.9}}@media screen and (max-width:500px){.xp-token[data-v-4a8de0db] .circle-1{top:-55.4%;background-size:150%!important}}@media screen and (max-width:361px){.xp-token[data-v-4a8de0db] .circle-1{top:-54.4%;background-size:150%!important}}.xp-token[data-v-4a8de0db] .circle-2{top:3.4%;bottom:0;position:absolute;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ");background-repeat:no-repeat;width:100%;height:auto;overflow:hidden;z-index:1;opacity:.7}@media screen and (max-width:830px){.xp-token[data-v-4a8de0db] .circle-2{top:.5%;background-size:80%!important}}@media screen and (max-width:500px){.xp-token[data-v-4a8de0db] .circle-2{top:3.4%;background-size:100%!important}}.xp-token[data-v-4a8de0db] .circle-3{top:19.5%;left:27%;position:absolute;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ");background-repeat:no-repeat;width:100%;height:30%;overflow:hidden;z-index:1;zoom:1.2;opacity:.7}@media screen and (max-width:1920px){.xp-token[data-v-4a8de0db] .circle-3{top:23%;left:29%}}@media screen and (max-width:1650px){.xp-token[data-v-4a8de0db] .circle-3{top:23%;left:25%}}@media screen and (max-width:1500px){.xp-token[data-v-4a8de0db] .circle-3{top:22%;left:23%}}@media screen and (max-width:1480px){.xp-token[data-v-4a8de0db] .circle-3{top:21.7%}}@media screen and (max-width:1021px){.xp-token[data-v-4a8de0db] .circle-3{top:23%;background-size:100%!important}}@media screen and (max-width:953px){.xp-token[data-v-4a8de0db] .circle-3{top:23.2%;background-size:100%!important}}@media screen and (max-width:500px){.xp-token[data-v-4a8de0db] .circle-3{top:25.6%;left:0;background-size:100%!important}}@media screen and (max-width:400px){.xp-token[data-v-4a8de0db] .circle-3{top:25.9%;left:0;background-size:100%!important}}.xp-token[data-v-4a8de0db] .roadmap-background{top:52.2%;left:calc(50% - 1399px);right:calc(50% - 1399px);position:absolute;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ");background-position:50%;background-size:100%;background-repeat:no-repeat;width:2200px;margin:auto;height:2701px;overflow:hidden;z-index:1}@media screen and (max-width:1710px){.xp-token[data-v-4a8de0db] .roadmap-background{top:52%}}@media screen and (max-width:1550px){.xp-token[data-v-4a8de0db] .roadmap-background{top:52%}}@media screen and (max-width:1378px){.xp-token[data-v-4a8de0db] .roadmap-background{top:52%}}@media screen and (max-width:1368px){.xp-token[data-v-4a8de0db] .roadmap-background{top:52%}}@media screen and (max-width:1200px){.xp-token[data-v-4a8de0db] .roadmap-background{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ");background-size:35%;top:52%;right:20%}}@media screen and (max-width:1132px){.xp-token[data-v-4a8de0db] .roadmap-background{top:52%}}@media screen and (max-width:1056px){.xp-token[data-v-4a8de0db] .roadmap-background{top:52%}}@media screen and (max-width:1034px){.xp-token[data-v-4a8de0db] .roadmap-background{top:48.1%;left:calc(51% - 1399px)}}@media screen and (max-width:1020px){.xp-token[data-v-4a8de0db] .roadmap-background{top:52%;left:calc(51% - 1399px)}}@media screen and (max-width:930px){.xp-token[data-v-4a8de0db] .roadmap-background{top:52%;left:calc(55% - 1399px)}}@media screen and (max-width:914px){.xp-token[data-v-4a8de0db] .roadmap-background{top:52%;left:calc(55% - 1399px)}}@media screen and (max-width:840px){.xp-token[data-v-4a8de0db] .roadmap-background{top:52%;left:calc(57% - 1399px)}}@media screen and (max-width:808px){.xp-token[data-v-4a8de0db] .roadmap-background{left:calc(59% - 1399px)}}@media screen and (max-width:770px){.xp-token[data-v-4a8de0db] .roadmap-background{left:calc(61% - 1399px)}}@media screen and (max-width:734px){.xp-token[data-v-4a8de0db] .roadmap-background{background-image:none}}.xp-token[data-v-4a8de0db] .circle-4{top:89.7%;position:absolute;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_5___ + ");background-repeat:no-repeat;background-size:60%;width:100%;height:10%;background-position:center 0;overflow:hidden;z-index:1;opacity:.7}@media screen and (max-width:1820px){.xp-token[data-v-4a8de0db] .circle-4{background-size:59.6%}}@media screen and (max-width:1662px){.xp-token[data-v-4a8de0db] .circle-4{background-size:64.6%}}@media screen and (max-width:1566px){.xp-token[data-v-4a8de0db] .circle-4{background-size:69.6%}}@media screen and (max-width:1506px){.xp-token[data-v-4a8de0db] .circle-4{background-size:73.6%}}@media screen and (max-width:1402px){.xp-token[data-v-4a8de0db] .circle-4{background-size:81.6%}}@media screen and (max-width:500px){.xp-token[data-v-4a8de0db] .circle-4{top:89%;background-size:170%!important}}.xp-token[data-v-4a8de0db] h2.txt-lg{font-size:5rem;line-height:5.7143rem;letter-spacing:-2.1px}@media screen and (max-width:1023px){.xp-token[data-v-4a8de0db] h2.txt-lg{font-size:2.2857rem;line-height:3.2857rem}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1379:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/AfterBanner.vue?vue&type=template&id=4a8de0db&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xp-token"},[_vm._ssrNode("<div class=\"circle-1\" data-v-4a8de0db></div><div class=\"circle-2\" data-v-4a8de0db></div><div class=\"circle-3\" data-v-4a8de0db></div><div class=\"roadmap-background\" data-v-4a8de0db></div><div class=\"circle-4\" data-v-4a8de0db></div>"),_vm._ssrNode("<div class=\"all-other\" data-v-4a8de0db>","</div>",[_c('SocialsSection'),_c('VideoSection'),_c('HowToBuySection'),_c('WhyFx1Section'),_c('HowDoesFx1Section'),_c('NFTfanSection'),_c('ReferFriendSection'),_c('RoadmapSection'),_c('TeamSection'),_c('PartnersSection'),_c('WhitepaperSection'),_c('FAQSection')],1)],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Token/AfterBanner.vue?vue&type=template&id=4a8de0db&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/AfterBanner.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var AfterBannervue_type_script_lang_js_ = ({
  name: 'TokenAfterBanner',
  components: {
    VideoSection: () => __webpack_require__.e(/* import() */ 96).then(__webpack_require__.bind(null, 1405)),
    HowToBuySection: () => __webpack_require__.e(/* import() */ 86).then(__webpack_require__.bind(null, 1406)),
    WhyFx1Section: () => __webpack_require__.e(/* import() */ 104).then(__webpack_require__.bind(null, 1407)),
    HowDoesFx1Section: () => __webpack_require__.e(/* import() */ 130).then(__webpack_require__.bind(null, 1408)),
    NFTfanSection: () => __webpack_require__.e(/* import() */ 84).then(__webpack_require__.bind(null, 1409)),
    ReferFriendSection: () => __webpack_require__.e(/* import() */ 88).then(__webpack_require__.bind(null, 1410)),
    RoadmapSection: () => __webpack_require__.e(/* import() */ 90).then(__webpack_require__.bind(null, 1411)),
    TeamSection: () => __webpack_require__.e(/* import() */ 95).then(__webpack_require__.bind(null, 1412)),
    PartnersSection: () => __webpack_require__.e(/* import() */ 87).then(__webpack_require__.bind(null, 1413)),
    WhitepaperSection: () => __webpack_require__.e(/* import() */ 132).then(__webpack_require__.bind(null, 1414)),
    SocialsSection: () => __webpack_require__.e(/* import() */ 131).then(__webpack_require__.bind(null, 1415)),
    FAQSection: () => __webpack_require__.e(/* import() */ 85).then(__webpack_require__.bind(null, 1314))
  }
});
// CONCATENATED MODULE: ./components/molecules/Token/AfterBanner.vue?vue&type=script&lang=js&
 /* harmony default export */ var Token_AfterBannervue_type_script_lang_js_ = (AfterBannervue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/Token/AfterBanner.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1196)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Token_AfterBannervue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "4a8de0db",
  "4ac2e03c"
  
)

/* harmony default export */ var AfterBanner = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 610:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/bg-circles.68ed588.png";

/***/ }),

/***/ 627:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/CirclesAndLight1.0df72eb.png";

/***/ }),

/***/ 629:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/CirclesAndLight3.06ff873.png";

/***/ }),

/***/ 630:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/CirclesAndLight4.4b1b6e0.png";

/***/ }),

/***/ 635:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/Roadmap-Tablet.60d10c2.svg";

/***/ }),

/***/ 636:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/Roadmap.67da6b4.svg";

/***/ }),

/***/ 941:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1197);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("bce35842", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=83.js.map
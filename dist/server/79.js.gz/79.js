exports.ids = [79,1];
exports.modules = {

/***/ 1284:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Video_vue_vue_type_style_index_0_id_019f1a48_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(985);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Video_vue_vue_type_style_index_0_id_019f1a48_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Video_vue_vue_type_style_index_0_id_019f1a48_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Video_vue_vue_type_style_index_0_id_019f1a48_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Video_vue_vue_type_style_index_0_id_019f1a48_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1285:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xo-video[data-v-019f1a48]{overflow:hidden;border-radius:4px;transform:scaleX(-1);z-index:1}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1286:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_VideoBody_vue_vue_type_style_index_0_id_141c8088_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(986);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_VideoBody_vue_vue_type_style_index_0_id_141c8088_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_VideoBody_vue_vue_type_style_index_0_id_141c8088_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_VideoBody_vue_vue_type_style_index_0_id_141c8088_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_VideoBody_vue_vue_type_style_index_0_id_141c8088_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1287:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(24);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(306);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xo-video-body[data-v-141c8088]{display:grid;grid-template-columns:1fr;grid-auto-rows:190px;grid-gap:8px;gap:8px;padding:8px}.xo-video-body.more[data-v-141c8088]{grid-template-columns:repeat(2,1fr);grid-auto-rows:100px}.xo-video-body .member[data-v-141c8088]{position:relative;background-color:#242424;border-radius:4px}.xo-video-body .member[data-v-141c8088],.xo-video-body .member.placeholder[data-v-141c8088]{display:grid;align-content:center;justify-content:center;place-content:center}.xo-video-body .member.placeholder[data-v-141c8088]{background-color:#385960}.xo-video-body .member .avatar[data-v-141c8088]{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%)}.xo-video-body .member .name[data-v-141c8088]{position:absolute;bottom:0;left:0;z-index:2;padding:2px 5px 0;background-color:#000;border-bottom-left-radius:4px;font-size:12px;letter-spacing:-.48px;display:flex;grid-gap:4px;gap:4px;align-items:center}.xo-video-body .member .name .muted[data-v-141c8088]{background:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") no-repeat 50%;background-color:transparent;background-size:12px 12px;height:12px;width:12px;display:inline-block}.xo-video-body .audio[data-v-141c8088]{display:none}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1307:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/ExploreEvent/VideoBody.vue?vue&type=template&id=141c8088&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xo-video-body",class:{ more: _vm.isMore }},[(!_vm.visibleMembers.length)?_c('XALoader',{attrs:{"size":24}}):_vm._l((_vm.visibleMembers),function(ref){
var member = ref.member;
var participant = ref.participant;
return _c('div',{key:participant.sid,staticClass:"member"},[_c('XAAvatar',{staticClass:"avatar",attrs:{"name":member.username,"image":member.avatar,"size":_vm.isMore ? '62px' : '128px'}}),_c('XOVideo',{attrs:{"participant":participant}}),_c('div',{staticClass:"name"},[(_vm.isMuted(participant.sid))?_c('div',{staticClass:"muted"}):_vm._e(),_c('span',[_vm._v(_vm._s(member.username))])])],1)}),_vm._ssrNode(((_vm.hiddenCount > 0)?("<div class=\"member placeholder\" data-v-141c8088>"+_vm._ssrEscape("+"+_vm._s(_vm.hiddenCount))+"</div>"):"<!---->")),_vm._ssrNode("<div class=\"audio\" data-v-141c8088>","</div>",_vm._l((_vm.allParticipants),function(participant){return _c('XOAudio',{key:participant.sid,attrs:{"participant":participant},on:{"audioMute":function($event){return _vm.audioMute(participant.sid)},"audioUnmute":function($event){return _vm.audioUnmute(participant.sid)}}})}),1)],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/ExploreEvent/VideoBody.vue?vue&type=template&id=141c8088&scoped=true&lang=pug&

// EXTERNAL MODULE: external "core-js/modules/esnext.map.delete-all.js"
var esnext_map_delete_all_js_ = __webpack_require__(249);

// EXTERNAL MODULE: external "core-js/modules/esnext.map.every.js"
var esnext_map_every_js_ = __webpack_require__(250);

// EXTERNAL MODULE: external "core-js/modules/esnext.map.filter.js"
var esnext_map_filter_js_ = __webpack_require__(251);

// EXTERNAL MODULE: external "core-js/modules/esnext.map.find.js"
var esnext_map_find_js_ = __webpack_require__(252);

// EXTERNAL MODULE: external "core-js/modules/esnext.map.find-key.js"
var esnext_map_find_key_js_ = __webpack_require__(253);

// EXTERNAL MODULE: external "core-js/modules/esnext.map.includes.js"
var esnext_map_includes_js_ = __webpack_require__(254);

// EXTERNAL MODULE: external "core-js/modules/esnext.map.key-of.js"
var esnext_map_key_of_js_ = __webpack_require__(255);

// EXTERNAL MODULE: external "core-js/modules/esnext.map.map-keys.js"
var esnext_map_map_keys_js_ = __webpack_require__(256);

// EXTERNAL MODULE: external "core-js/modules/esnext.map.map-values.js"
var esnext_map_map_values_js_ = __webpack_require__(257);

// EXTERNAL MODULE: external "core-js/modules/esnext.map.merge.js"
var esnext_map_merge_js_ = __webpack_require__(258);

// EXTERNAL MODULE: external "core-js/modules/esnext.map.reduce.js"
var esnext_map_reduce_js_ = __webpack_require__(259);

// EXTERNAL MODULE: external "core-js/modules/esnext.map.some.js"
var esnext_map_some_js_ = __webpack_require__(260);

// EXTERNAL MODULE: external "core-js/modules/esnext.map.update.js"
var esnext_map_update_js_ = __webpack_require__(261);

// EXTERNAL MODULE: external "vuex-map-fields"
var external_vuex_map_fields_ = __webpack_require__(2);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/ExploreEvent/Audio.vue?vue&type=template&id=fd3f4628&lang=pug&
var Audiovue_type_template_id_fd3f4628_lang_pug_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{ref:"audio",staticClass:"xo-audio"},[])}
var Audiovue_type_template_id_fd3f4628_lang_pug_staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/ExploreEvent/Audio.vue?vue&type=template&id=fd3f4628&lang=pug&

// EXTERNAL MODULE: external "twilio-video"
var external_twilio_video_ = __webpack_require__(221);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/ExploreEvent/Audio.vue?vue&type=script&lang=js&
//
//
//
//



/* harmony default export */ var Audiovue_type_script_lang_js_ = ({
  name: 'XOAudio',
  props: {
    participant: {
      type: external_twilio_video_["Participant"],
      required: true
    }
  },
  data() {
    return {
      publication: null,
      track: null,
      audioElem: null
    };
  },
  computed: {
    ...Object(external_vuex_map_fields_["mapFields"])('chats', ['audioOutputDeviceId'])
  },
  watch: {
    publication(newPublication, oldPublication) {
      oldPublication === null || oldPublication === void 0 ? void 0 : oldPublication.off('subscribed', this.handlePublicationSubscribed);
      oldPublication === null || oldPublication === void 0 ? void 0 : oldPublication.off('unsubscribed', this.handlePublicationUnsubscribed);
      if (newPublication.track) {
        this.handlePublicationSubscribed(newPublication.track);
      }
      newPublication.on('subscribed', this.handlePublicationSubscribed);
      newPublication.on('unsubscribed', this.handlePublicationUnsubscribed);
    },
    track(newTrack, oldTrack) {
      oldTrack === null || oldTrack === void 0 ? void 0 : oldTrack.off('disabled', this.handleTrackDisabled);
      this.attachTrack(newTrack);
      newTrack.on('disabled', this.handleTrackDisabled);
    },
    audioOutputDeviceId(newVal) {
      this.setAudioOutput(newVal);
    }
  },
  mounted() {
    const publication = [...this.participant.audioTracks.values()][0];
    if (publication) {
      this.handleTrackPublished(publication);
    }
    this.participant.on('trackPublished', this.handleTrackPublished);
  },
  beforeDestroy() {
    this.detachTrack();
  },
  methods: {
    attachTrack(track) {
      this.audioElem = track.attach();
      this.setAudioOutput(this.audioOutputDeviceId);
      this.$refs.audio.replaceChildren(this.audioElem);
    },
    detachTrack() {
      var _this$audioElem;
      (_this$audioElem = this.audioElem) === null || _this$audioElem === void 0 ? void 0 : _this$audioElem.remove();
      this.audioElem = null;
    },
    handleTrackPublished(publication) {
      if (publication.kind !== 'audio') return;
      this.publication = publication;
    },
    handleTrackDisabled() {
      this.$emit('audioMute');
    },
    handlePublicationSubscribed(track) {
      this.$emit('audioUnmute');
      this.track = track;
    },
    handlePublicationUnsubscribed() {
      this.detachTrack();
    },
    setAudioOutput(deviceId) {
      var _this$audioElem2;
      // NOTE: setSinkId is currently not supported in Safari
      if ((_this$audioElem2 = this.audioElem) !== null && _this$audioElem2 !== void 0 && _this$audioElem2.setSinkId && deviceId) {
        this.audioElem.setSinkId(deviceId);
      }
    }
  }
});
// CONCATENATED MODULE: ./components/organisms/ExploreEvent/Audio.vue?vue&type=script&lang=js&
 /* harmony default export */ var ExploreEvent_Audiovue_type_script_lang_js_ = (Audiovue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/organisms/ExploreEvent/Audio.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  ExploreEvent_Audiovue_type_script_lang_js_,
  Audiovue_type_template_id_fd3f4628_lang_pug_render,
  Audiovue_type_template_id_fd3f4628_lang_pug_staticRenderFns,
  false,
  null,
  null,
  "dc07bbb4"
  
)

/* harmony default export */ var Audio = (component.exports);
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/ExploreEvent/Video.vue?vue&type=template&id=019f1a48&scoped=true&lang=pug&
var Videovue_type_template_id_019f1a48_scoped_true_lang_pug_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{directives:[{name:"show",rawName:"v-show",value:(!_vm.isHidden),expression:"!isHidden"}],ref:"video",staticClass:"xo-video"},[])}
var Videovue_type_template_id_019f1a48_scoped_true_lang_pug_staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/ExploreEvent/Video.vue?vue&type=template&id=019f1a48&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/ExploreEvent/Video.vue?vue&type=script&lang=js&
//
//
//
//


/* harmony default export */ var Videovue_type_script_lang_js_ = ({
  name: 'XOVideo',
  props: {
    participant: {
      type: external_twilio_video_["Participant"],
      required: true
    }
  },
  data() {
    return {
      isHidden: false,
      publication: null,
      track: null,
      videoElem: null
    };
  },
  watch: {
    publication(newPublication, oldPublication) {
      oldPublication === null || oldPublication === void 0 ? void 0 : oldPublication.off('subscribed', this.handlePublicationSubscribed);
      oldPublication === null || oldPublication === void 0 ? void 0 : oldPublication.off('unsubscribed', this.handlePublicationUnsubscribed);
      if (newPublication.track) {
        this.handlePublicationSubscribed(newPublication.track);
      }
      newPublication.on('subscribed', this.handlePublicationSubscribed);
      newPublication.on('unsubscribed', this.handlePublicationUnsubscribed);
    },
    track(newTrack, oldTrack) {
      oldTrack === null || oldTrack === void 0 ? void 0 : oldTrack.off('disabled', this.handleTrackDisabled);
      this.attachTrack(newTrack);
      newTrack.on('disabled', this.handleTrackDisabled);
    }
  },
  mounted() {
    const publication = [...this.participant.videoTracks.values()][0];
    if (publication) {
      this.handleTrackPublished(publication);
    }
    this.participant.on('trackPublished', this.handleTrackPublished);
  },
  beforeDestroy() {
    this.detachTrack();
  },
  methods: {
    attachTrack(track) {
      this.videoElem = track.attach();
      this.$refs.video.replaceChildren(this.videoElem);
    },
    detachTrack() {
      var _this$videoElem;
      (_this$videoElem = this.videoElem) === null || _this$videoElem === void 0 ? void 0 : _this$videoElem.remove();
      this.videoElem = null;
    },
    handleTrackPublished(publication) {
      if (publication.kind !== 'video') return;
      this.publication = publication;
    },
    handleTrackDisabled() {
      this.isHidden = true;
    },
    handlePublicationSubscribed(track) {
      this.isHidden = false;
      this.track = track;
    },
    handlePublicationUnsubscribed() {
      this.detachTrack();
    }
  }
});
// CONCATENATED MODULE: ./components/organisms/ExploreEvent/Video.vue?vue&type=script&lang=js&
 /* harmony default export */ var ExploreEvent_Videovue_type_script_lang_js_ = (Videovue_type_script_lang_js_); 
// CONCATENATED MODULE: ./components/organisms/ExploreEvent/Video.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1284)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var Video_component = Object(componentNormalizer["a" /* default */])(
  ExploreEvent_Videovue_type_script_lang_js_,
  Videovue_type_template_id_019f1a48_scoped_true_lang_pug_render,
  Videovue_type_template_id_019f1a48_scoped_true_lang_pug_staticRenderFns,
  false,
  injectStyles,
  "019f1a48",
  "53907f6a"
  
)

/* harmony default export */ var Video = (Video_component.exports);
// EXTERNAL MODULE: ./components/atoms/Avatar.vue + 4 modules
var Avatar = __webpack_require__(440);

// CONCATENATED MODULE: ./scripts/twilio/index.ts

function connectToRoom({
  token,
  roomName,
  audioDeviceId,
  videoDeviceId
}) {
  return Object(external_twilio_video_["connect"])(token, {
    name: roomName,
    audio: {
      deviceId: audioDeviceId || undefined
    },
    video: {
      deviceId: videoDeviceId || undefined,
      facingMode: 'user'
    }
  });
}
function connectToRoomWithoutDevices({
  token,
  roomName
}) {
  return Object(external_twilio_video_["connect"])(token, {
    name: roomName,
    audio: false,
    video: false
  });
}
// EXTERNAL MODULE: ./scripts/twilio/utils.ts
var utils = __webpack_require__(835);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/ExploreEvent/VideoBody.vue?vue&type=script&lang=js&













//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//







const MORE_LIMIT = 3;
const MAX_LIMIT = 10;
/* harmony default export */ var VideoBodyvue_type_script_lang_js_ = ({
  name: 'XOVideoBody',
  components: {
    XOAudio: Audio,
    XOVideo: Video,
    XAAvatar: Avatar["default"],
    XALoader: () => __webpack_require__.e(/* import() */ 3).then(__webpack_require__.bind(null, 275))
  },
  props: {
    privateChannel: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      allParticipants: [],
      unmuted: [],
      audioPermissionStatus: null,
      videoPermissionStatus: null
    };
  },
  computed: {
    members() {
      return new Map([...this.privateChannel.Roles.Owners, ...this.privateChannel.Roles.Joiners, ...this.newMembers].map(({
        User
      }) => {
        var _User$Avatar;
        return [User.id, {
          username: User.username,
          avatar: ((_User$Avatar = User.Avatar) === null || _User$Avatar === void 0 ? void 0 : _User$Avatar.PhotoURL) || ''
        }];
      }));
    },
    visibleMembers() {
      return this.enrichedAllParticipants.slice(0, this.enrichedAllParticipants.length > MAX_LIMIT ? MAX_LIMIT - 1 : MAX_LIMIT);
    },
    isMore() {
      return this.enrichedAllParticipants.length > MORE_LIMIT;
    },
    hiddenCount() {
      return this.enrichedAllParticipants.length - this.visibleMembers.length;
    },
    enrichedAllParticipants() {
      const participants = [];
      this.allParticipants.forEach(participant => {
        var _this$members$get;
        const member = (_this$members$get = this.members.get(participant.identity)) !== null && _this$members$get !== void 0 ? _this$members$get : {};
        participants.push({
          participant,
          member
        });
      });
      return participants;
    },
    ...Object(external_vuex_map_fields_["mapFields"])('chats', ['room', 'newMembers', 'audioDeviceId', 'audioDevices', 'audioPermissionsGranted', 'videoDeviceId', 'videoDevices', 'videoPermissionsGranted', 'audioOutputDevices'])
  },
  async mounted() {
    await this.mountVideoChat();
  },
  beforeDestroy() {
    var _this$room, _this$room2, _this$audioPermission, _this$videoPermission;
    (_this$room = this.room) === null || _this$room === void 0 ? void 0 : _this$room.localParticipant.tracks.forEach(publication => {
      publication.track.stop();
      this.room.localParticipant.unpublishTrack(publication.track);
    });
    (_this$room2 = this.room) === null || _this$room2 === void 0 ? void 0 : _this$room2.disconnect();
    this.room = null;
    (_this$audioPermission = this.audioPermissionStatus) === null || _this$audioPermission === void 0 ? void 0 : _this$audioPermission.removeEventListener('change', this.onAudioPermissionStatusChange);
    (_this$videoPermission = this.videoPermissionStatus) === null || _this$videoPermission === void 0 ? void 0 : _this$videoPermission.removeEventListener('change', this.onVideoPermissionStatusChange);
  },
  methods: {
    async mountVideoChat() {
      const {
        getAccessToken: {
          objectID
        }
      } = await this.$api.getAccessToken({
        privateGroup: this.privateChannel.id
      });
      try {
        this.room = await connectToRoomWithoutDevices({
          token: objectID,
          roomName: this.privateChannel.id
        });
      } catch (e) {
        this.$sentry.captureException(e);
      }
      try {
        this.audioPermissionStatus = await navigator.permissions.query({
          name: 'microphone'
        });
        this.onAudioPermissionStatusChange();
        this.audioPermissionStatus.addEventListener('change', this.onAudioPermissionStatusChange);
      } catch (error) {
        // NOTE: microphone/camera permission check currently not supported in Firefox
        if (error instanceof TypeError) {
          this.audioPermissionsGranted = true;
        }
        this.$sentry.captureException(error);
      }
      try {
        this.videoPermissionStatus = await navigator.permissions.query({
          name: 'camera'
        });
        this.onVideoPermissionStatusChange();
        this.videoPermissionStatus.addEventListener('change', this.onVideoPermissionStatusChange);
      } catch (error) {
        // NOTE: microphone/camera permission check currently not supported in Firefox
        if (error instanceof TypeError) {
          this.videoPermissionsGranted = true;
        }
        this.$sentry.captureException(error);
      }
      if (this.audioPermissionsGranted || this.videoPermissionsGranted) {
        await this.setDevicesList();
      }
      const {
        localParticipant,
        participants
      } = this.room;
      this.allParticipants.push(localParticipant, ...participants.values());

      // handle new connections
      this.room.on('participantConnected', async participant => {
        this.allParticipants.push(participant);
        if (!this.members.has(participant.identity)) {
          const member = await this.fetchMember(participant.identity);
          if (member) {
            this.newMembers.push(member);
          }
        }
      });

      // handle disconnects
      this.room.on('participantDisconnected', participant => {
        const participantIndex = this.allParticipants.findIndex(p => p.sid === participant.sid);
        if (participantIndex > -1) {
          this.allParticipants.splice(participantIndex, 1);
        }
        this.audioMute(participant.sid);
      });
    },
    async setDevicesList() {
      const groupedDevices = await Object(utils["a" /* getMediaDevices */])();
      if (groupedDevices.audioinput) {
        this.audioDevices = groupedDevices.audioinput;
      }
      if (groupedDevices.videoinput) {
        this.videoDevices = groupedDevices.videoinput;
      }
      if (groupedDevices.audiooutput) {
        this.audioOutputDevices = groupedDevices.audiooutput;
      }
    },
    audioMute(uId) {
      const unmutedIndex = this.unmuted.findIndex(id => id === uId);
      if (unmutedIndex > -1) {
        this.unmuted.splice(unmutedIndex, 1);
      }
    },
    audioUnmute(uId) {
      if (this.isMuted(uId)) {
        this.unmuted.push(uId);
      }
    },
    isMuted(uId) {
      return !this.unmuted.includes(uId);
    },
    onAudioPermissionStatusChange() {
      if (this.audioPermissionsGranted && this.audioPermissionStatus.state === 'denied') {
        this.$root.$emit('audioOff');
      }
      this.audioPermissionsGranted = this.audioPermissionStatus.state === 'granted';
    },
    onVideoPermissionStatusChange() {
      if (this.videoPermissionsGranted && this.videoPermissionStatus.state === 'denied') {
        this.$root.$emit('videoOff');
      }
      this.videoPermissionsGranted = this.videoPermissionStatus.state === 'granted';
    },
    async fetchMember(id) {
      const {
        getUser: User
      } = await this.$api.getUser({
        id
      });
      return {
        User
      };
    }
  }
});
// CONCATENATED MODULE: ./components/organisms/ExploreEvent/VideoBody.vue?vue&type=script&lang=js&
 /* harmony default export */ var ExploreEvent_VideoBodyvue_type_script_lang_js_ = (VideoBodyvue_type_script_lang_js_); 
// CONCATENATED MODULE: ./components/organisms/ExploreEvent/VideoBody.vue



function VideoBody_injectStyles (context) {
  
  var style0 = __webpack_require__(1286)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var VideoBody_component = Object(componentNormalizer["a" /* default */])(
  ExploreEvent_VideoBodyvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  VideoBody_injectStyles,
  "141c8088",
  "07f2ab8d"
  
)

/* harmony default export */ var VideoBody = __webpack_exports__["default"] = (VideoBody_component.exports);

/***/ }),

/***/ 306:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMyIgZmlsbD0ibm9uZSI+DQo8cGF0aCBzdHJva2U9IiNDRDNCMzMiIGQ9Ik02IDkuNXYyIi8+DQo8cmVjdCB3aWR0aD0iNCIgaGVpZ2h0PSIxIiB4PSI0IiB5PSIxMSIgZmlsbD0iI0NEM0IzMyIgcng9Ii41Ii8+DQo8cGF0aCBzdHJva2U9IiNDRDNCMzMiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgZD0iTTExLjkyIDEuMDggMS4wOCAxMS45MiIvPg0KPHBhdGggZmlsbD0iI0NEM0IzMyIgZmlsbC1ydWxlPSJldmVub2RkIiBkPSJNOCAzLjU5VjNhMiAyIDAgMSAwLTQgMHY0LjU5bDQtNFpNOCA2LjRsLTMuMiAzLjJBMiAyIDAgMCAwIDggOFY2LjRaIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 436:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(444);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("d2b30118", content, true, context)
};

/***/ }),

/***/ 440:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/atoms/Avatar.vue?vue&type=template&id=6f02151c&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xa-avatar row items-center justify-center",style:([_vm.avatarStyles])},[_vm._ssrNode(((_vm.image)?("<img"+(_vm._ssrAttr("src",_vm.image))+" alt=\"name\" data-v-6f02151c>"):("<div class=\"name\""+(_vm._ssrStyle(null,[_vm.nameStyles], null))+" data-v-6f02151c>"+_vm._ssrEscape(_vm._s(_vm.initials))+"</div>")))])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/atoms/Avatar.vue?vue&type=template&id=6f02151c&scoped=true&lang=pug&

// EXTERNAL MODULE: ./assets/json/colors.json
var colors = __webpack_require__(442);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/atoms/Avatar.vue?vue&type=script&lang=js&
//
//
//
//
//
//


/* harmony default export */ var Avatarvue_type_script_lang_js_ = ({
  name: 'XAAvatar',
  props: {
    name: {
      type: String,
      default: ''
    },
    image: {
      type: String,
      default: null
    },
    size: {
      type: String,
      default: '32px'
    }
  },
  data() {
    return {
      colors: colors
    };
  },
  computed: {
    initials() {
      const name = this.name || '';
      if (name.split(' ').length > 1) {
        return name.split(' ')[0].charAt(0) + name.split(' ').pop().charAt(0);
      }
      return name.charAt(0);
    },
    avatarStyles() {
      // set up background color
      const name = this.name || 'FX1 User';
      let hash = 0;
      for (let index = 0; index < name.length; index++) {
        hash = name.charCodeAt(index) + ((hash << 5) - hash);
      }
      const h = hash % 360;

      // set up avatar styles
      const avatarStyles = {
        width: this.size,
        height: this.size,
        backgroundColor: this.image ? null : `hsl(${h}, 50%, 90%)`
      };
      return avatarStyles;
    },
    nameStyles() {
      const nameStyles = {
        fontSize: `calc(${this.size} * 0.40)`
      };
      return nameStyles;
    }
  }
});
// CONCATENATED MODULE: ./components/atoms/Avatar.vue?vue&type=script&lang=js&
 /* harmony default export */ var atoms_Avatarvue_type_script_lang_js_ = (Avatarvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/atoms/Avatar.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(443)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  atoms_Avatarvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "6f02151c",
  "40d37e9d"
  
)

/* harmony default export */ var Avatar = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 442:
/***/ (function(module) {

module.exports = JSON.parse("[\"#1abc9c\",\"#2ecc71\",\"#3498db\",\"#9b59b6\",\"#34495e\",\"#16a085\",\"#27ae60\",\"#2980b9\",\"#8e44ad\",\"#2c3e50\",\"#f1c40f\",\"#e67e22\",\"#e74c3c\",\"#95a5a6\",\"#f39c12\",\"#d35400\",\"#c0392b\",\"#bdc3c7\",\"#7f8c8d\",\"#40076a\",\"#7d4f8a\",\"#2434c5\",\"#7c84fc\",\"#a23a7f\",\"#b55693\",\"#2e1529\",\"#12822c\"]");

/***/ }),

/***/ 443:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Avatar_vue_vue_type_style_index_0_id_6f02151c_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(436);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Avatar_vue_vue_type_style_index_0_id_6f02151c_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Avatar_vue_vue_type_style_index_0_id_6f02151c_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Avatar_vue_vue_type_style_index_0_id_6f02151c_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Avatar_vue_vue_type_style_index_0_id_6f02151c_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 444:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xa-avatar[data-v-6f02151c]{border-radius:50%;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;user-select:none}.xa-avatar[data-v-6f02151c] img{border-radius:50%;width:100%;height:100%;-o-object-fit:cover;object-fit:cover}.xa-avatar[data-v-6f02151c] .name{font-weight:300;margin-top:3px;color:#0c353e;text-transform:uppercase}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 835:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export getUserMedia */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getMediaDevices; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return switchAudioDevice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return switchVideoDevice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return muteLocalAudio; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return muteLocalVideo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return unmuteLocalAudio; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return unmuteLocalVideo; });
/* harmony import */ var twilio_video__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(221);
/* harmony import */ var twilio_video__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(twilio_video__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash_groupBy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(229);
/* harmony import */ var lodash_groupBy__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash_groupBy__WEBPACK_IMPORTED_MODULE_1__);


async function getUserMedia() {
  var _a, _b;
  try {
    const mediaStream = await navigator.mediaDevices.getUserMedia({
      audio: true,
      video: {
        facingMode: 'user'
      }
    });
    const audioId = (_a = mediaStream.getAudioTracks()) === null || _a === void 0 ? void 0 : _a[0].getSettings().deviceId;
    const videoId = (_b = mediaStream.getVideoTracks()) === null || _b === void 0 ? void 0 : _b[0].getSettings().deviceId;
    return {
      audioId,
      videoId
    };
  } catch (e) {
    return {
      audioId: null,
      videoId: null
    };
  }
}
async function getMediaDevices() {
  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    return lodash_groupBy__WEBPACK_IMPORTED_MODULE_1___default()(devices, device => device.kind);
  } catch (e) {
    return {};
  }
}
async function switchAudioDevice(room, deviceId) {
  const track = await Object(twilio_video__WEBPACK_IMPORTED_MODULE_0__["createLocalAudioTrack"])(deviceId ? {
    deviceId: {
      exact: deviceId
    }
  } : {});
  room.localParticipant.audioTracks.forEach(publication => {
    publication.track.stop();
    room.localParticipant.unpublishTrack(publication.track);
  });
  await room.localParticipant.publishTrack(track);
  return track.mediaStreamTrack.getSettings().deviceId;
}
async function switchVideoDevice(room, deviceId) {
  const track = await Object(twilio_video__WEBPACK_IMPORTED_MODULE_0__["createLocalVideoTrack"])(deviceId ? {
    deviceId: {
      exact: deviceId
    }
  } : {
    facingMode: 'user'
  });
  room.localParticipant.videoTracks.forEach(publication => {
    publication.track.stop();
    room.localParticipant.unpublishTrack(publication.track);
  });
  await room.localParticipant.publishTrack(track);
  return track.mediaStreamTrack.getSettings().deviceId;
}
function muteLocalAudio(room) {
  room.localParticipant.audioTracks.forEach(publication => {
    publication.track.disable();
  });
}
function muteLocalVideo(room) {
  room.localParticipant.videoTracks.forEach(publication => {
    publication.track.disable();
  });
}
function unmuteLocalAudio(room) {
  room.localParticipant.audioTracks.forEach(publication => {
    publication.track.enable();
  });
}
function unmuteLocalVideo(room) {
  room.localParticipant.videoTracks.forEach(publication => {
    publication.track.enable();
  });
}

/***/ }),

/***/ 985:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1285);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("ebbe62a2", content, true, context)
};

/***/ }),

/***/ 986:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1287);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("37239cfa", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=79.js.map
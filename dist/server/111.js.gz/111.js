exports.ids = [111];
exports.modules = {

/***/ 1113:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_SignIn_vue_vue_type_style_index_0_id_efce236e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(900);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_SignIn_vue_vue_type_style_index_0_id_efce236e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_SignIn_vue_vue_type_style_index_0_id_efce236e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_SignIn_vue_vue_type_style_index_0_id_efce236e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_SignIn_vue_vue_type_style_index_0_id_efce236e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1114:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, "@media screen and (max-width:1023px){.xp-sign-in[data-v-efce236e] .step-content .left-content{min-height:calc(100vh - 60px)!important;align-items:flex-start}}.xp-sign-in[data-v-efce236e] .step-content .left-content .form-container form .forgot-password a{font-weight:400;color:#0c353e}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1349:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/SignIn.vue?vue&type=template&id=efce236e&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xp-sign-in auth-page"},[_vm._ssrNode("<div class=\"step-content row\" data-v-efce236e>","</div>",[_vm._ssrNode("<div class=\"left-content row items-center justify-center\" data-v-efce236e>","</div>",[_vm._ssrNode("<div class=\"form-container\" data-v-efce236e>","</div>",[_vm._ssrNode("<div class=\"form-header\" data-v-efce236e>","</div>",[_vm._ssrNode("<h1 data-v-efce236e>Sign In</h1>"),_vm._ssrNode("<h4 class=\"text-weight-light\" data-v-efce236e>","</h4>",[_vm._ssrNode("New user? "),_c('nuxt-link',{attrs:{"to":"/signup?step=1"}},[_vm._v("Create an account")])],2)],2),_vm._ssrNode("<form action=\"#\" autocomplete=\"off\" data-v-efce236e>","</form>",[_vm._ssrNode("<div class=\"mb-5\" data-v-efce236e>","</div>",[_c('XAFormsInput',{attrs:{"id":"IEmail","placeholder":"Email","disabled":_vm.isSubmitting,"error":_vm.validation.firstError('email')},on:{"enter":function($event){return _vm.fnLoginViaEmail()}},model:{value:(_vm.email),callback:function ($$v) {_vm.email=$$v},expression:"email"}})],1),_vm._ssrNode("<div class=\"mb-3\" data-v-efce236e>","</div>",[_c('XAFormsInput',{attrs:{"id":"IPassword","type":"password","placeholder":"Password","disabled":_vm.isSubmitting,"error":_vm.validation.firstError('password')},on:{"enter":function($event){return _vm.fnLoginViaEmail()}},model:{value:(_vm.password),callback:function ($$v) {_vm.password=$$v},expression:"password"}})],1),_vm._ssrNode("<div class=\"forgot-password mb-6\" data-v-efce236e>","</div>",[_c('nuxt-link',{attrs:{"to":"/forgot-password"}},[_vm._v("Forgot Password?")])],1),_vm._ssrNode("<div class=\"actions\" data-v-efce236e>","</div>",[_vm._ssrNode("<div class=\"mb-4\" data-v-efce236e>","</div>",[_c('b-button',{staticClass:"btn-next",attrs:{"id":"BSubmit","type":"is-primary","loading":_vm.isSubmitting},on:{"click":function($event){$event.preventDefault();return _vm.fnLoginViaEmail()}}},[_vm._v("Sign In")])],1),_vm._ssrNode("<div class=\"row\" data-v-efce236e><div"+(_vm._ssrClass("btn-google row items-center justify-center",[_vm.isSubmitting && 'disabled']))+" data-v-efce236e><div class=\"_icon row\" data-v-efce236e><img"+(_vm._ssrAttr("src",__webpack_require__(558)))+" data-v-efce236e></div><div class=\"value\" data-v-efce236e>Sign In with Google</div></div></div>")],2)])])]),_c('XMSignUpRightContent')],1)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/pages/SignIn.vue?vue&type=template&id=efce236e&scoped=true&lang=pug&

// EXTERNAL MODULE: external "vuex-map-fields"
var external_vuex_map_fields_ = __webpack_require__(2);

// EXTERNAL MODULE: external "vuex"
var external_vuex_ = __webpack_require__(4);

// EXTERNAL MODULE: external "simple-vue-validator"
var external_simple_vue_validator_ = __webpack_require__(37);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/SignIn.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ var SignInvue_type_script_lang_js_ = ({
  name: 'XPSignIn',
  validators: {
    email(value) {
      return external_simple_vue_validator_["Validator"].value(value).required('Sorry, we need a email to send you important updates').email(`Hmmm, that email doesn't look right, maybe try again?`);
    },
    password(value) {
      return external_simple_vue_validator_["Validator"].value(value).required('Sorry, please enter a secure password');
    }
  },
  components: {
    XAFormsInput: () => __webpack_require__.e(/* import() */ 0).then(__webpack_require__.bind(null, 991)),
    XMSignUpRightContent: () => __webpack_require__.e(/* import() */ 2).then(__webpack_require__.bind(null, 1374))
  },
  data() {
    return {
      isSubmitting: false,
      isNewUser: false,
      loginMethod: null,
      substringUrl: null,
      acceptInProcess: false
    };
  },
  computed: {
    ...Object(external_vuex_map_fields_["mapFields"])('signup', ['username', 'email', 'password', 'firstName', 'lastName', 'avatarSocial', 'signupOwnerManagerInvite', 'signupLockerRoomSupporting', 'signupMethod']),
    ...Object(external_vuex_map_fields_["mapFields"])('user', ['userID'])
  },
  methods: {
    ...Object(external_vuex_["mapActions"])({
      authLoginWithEmail: 'auth/authLoginWithEmail',
      authLoginWithGoogle: 'auth/authLoginWithGoogle'
    }),
    async fnLoginViaEmail() {
      try {
        this.isSubmitting = true;
        this.loginMethod = 'Email';
        const success = await this.$validate();
        if (success) {
          const {
            email,
            password
          } = this;
          await this.authLoginWithEmail({
            email,
            password
          });
          await this.fnAfterLogin();
        }
      } catch (error) {
        this.showError(error);
      } finally {
        this.isSubmitting = false;
      }
    },
    async fnLoginViaGoogle() {
      this.validation.reset();
      this.email = null;
      this.password = null;
      this.isSubmitting = true;
      this.signupMethod = 'google';
      try {
        var _result$additionalUse;
        const result = await this.authLoginWithGoogle();
        if (!result) return;
        if (result !== null && result !== void 0 && (_result$additionalUse = result.additionalUserInfo) !== null && _result$additionalUse !== void 0 && _result$additionalUse.isNewUser) {
          const {
            additionalUserInfo: {
              profile: {
                family_name: familyName,
                given_name: givenName,
                picture,
                email
              }
            }
          } = result;
          this.email = email;
          this.firstName = familyName;
          this.lastName = givenName;
          this.avatarSocial = picture;
        }
        await this.fnCreateUser(result);
        this.loginMethod = 'Google';
        await this.fnAfterLogin();
      } catch (error) {
        var _error$response;
        error === null || error === void 0 ? void 0 : (_error$response = error.response) === null || _error$response === void 0 ? void 0 : _error$response.errors.forEach(error => {
          this.$toast.success(error.message, {
            duration: 5000,
            position: 'bottom-left',
            className: 'fx1-success',
            iconPack: 'mdi',
            icon: 'alert-circle-outline'
          });
        });
      } finally {
        this.isSubmitting = false;
      }
    },
    async fnCreateUser(result) {
      const {
        additionalUserInfo: {
          profile: {
            family_name: familyName,
            given_name: givenName
          }
        },
        result: {
          user: {
            accessToken
          }
        }
      } = result;
      const input = {
        username: null,
        firstName: givenName,
        lastName: familyName,
        Avatar: null
      };
      try {
        await this.$api.createUser({
          input
        }, {
          Authorization: `Bearer ${accessToken}`
        });
      } catch (error) {
        var _error$response2;
        error === null || error === void 0 ? void 0 : (_error$response2 = error.response) === null || _error$response2 === void 0 ? void 0 : _error$response2.errors.forEach(error => {
          this.$toast.success(error.message, {
            duration: 5000,
            position: 'bottom-left',
            className: 'fx1-success',
            iconPack: 'mdi',
            icon: 'alert-circle-outline'
          });
        });
      }
    },
    async fnAfterLogin() {
      const {
        accept
      } = this.$route.query;
      const params = {
        loginMethod: this.loginMethod,
        pageName: 'Sign-in'
      };
      this.$mixpanelClient.trackLogin(params);
      if (!accept) {
        await this.fnAcceptInvite();
      } else {
        await this.fnAcceptPrivateInvitation();
      }
      await this.fnRetrieveUserDetails();
    },
    async fnAcceptInvite() {
      if (!this.signupOwnerManagerInvite) return;
      try {
        var _this$signupOwnerMana;
        const {
          respondUserManagerialRoleInvite
        } = await this.$api.respondUserManagerialRoleInvite({
          id: (_this$signupOwnerMana = this.signupOwnerManagerInvite) === null || _this$signupOwnerMana === void 0 ? void 0 : _this$signupOwnerMana.id
        });
        await this.$router.push({
          path: respondUserManagerialRoleInvite === null || respondUserManagerialRoleInvite === void 0 ? void 0 : respondUserManagerialRoleInvite.objectID
        });
      } catch (error) {
        var _error$response3;
        error === null || error === void 0 ? void 0 : (_error$response3 = error.response) === null || _error$response3 === void 0 ? void 0 : _error$response3.errors.forEach(error => {
          this.$toast.success(error.message, {
            duration: 5000,
            position: 'bottom-left',
            className: 'fx1-success',
            iconPack: 'mdi',
            icon: 'alert-circle-outline'
          });
        });
      } finally {
        this.signupOwnerManagerInvite = null;
      }
    },
    async fnRetrieveUserDetails() {
      if (this.acceptInProcess) return;
      try {
        const {
          next
        } = this.$route.query;
        const {
          Me: {
            id,
            uid
          }
        } = await this.$api.getMyProfile();
        this.userID = id;
        this.$mixpanel.identify(uid);
        if (this.signupLockerRoomSupporting) {
          const {
            urlSupport
          } = await this.fnSupportClub();
          await this.$router.push({
            path: urlSupport
          });
          return;
        }
        if (next) {
          const redirectUrl = typeof next === 'object' && next.length > 0 ? next[0] : next;
          await this.$router.push({
            path: redirectUrl
          });
        } else if (this.substringUrl) {
          await this.$router.push(this.substringUrl);
        } else if (!this.substring && !this.acceptInProcess) {
          await this.$router.push({
            path: '/explore'
          });
        }
      } catch (error) {
        var _error$response4;
        error === null || error === void 0 ? void 0 : (_error$response4 = error.response) === null || _error$response4 === void 0 ? void 0 : _error$response4.errors.forEach(error => {
          this.$toast.success(error.message, {
            duration: 5000,
            position: 'bottom-left',
            className: 'fx1-success',
            iconPack: 'mdi',
            icon: 'alert-circle-outline'
          });
        });
      }
    },
    async fnSupportClub() {
      const {
        signupLockerRoomSupporting: {
          id,
          slug,
          defaultChannelSlug
        }
      } = this;
      try {
        await this.$api.supportClub({
          lockerRoomID: id
        });
        this.signupLockerRoomSupporting = null;
        return {
          urlSupport: `/locker-room/${slug}/${defaultChannelSlug}` || null
        };
      } catch (error) {
        var _error$response5;
        error === null || error === void 0 ? void 0 : (_error$response5 = error.response) === null || _error$response5 === void 0 ? void 0 : _error$response5.errors.forEach(error => {
          this.$toast.success(error.message, {
            duration: 5000,
            position: 'bottom-left',
            className: 'fx1-success',
            iconPack: 'mdi',
            icon: 'alert-circle-outline'
          });
        });
      }
    },
    async fnAcceptPrivateInvitation() {
      this.acceptInProcess = true;
      try {
        const {
          acceptInvitationToPrivateChannel
        } = await this.$api.acceptInvitationToPrivateChannel({
          token: this.$route.query.accept
        });
        const redirectUrl = acceptInvitationToPrivateChannel.objectID;
        const startIndex = redirectUrl.indexOf('io') + 2;
        this.substringUrl = redirectUrl.substring(startIndex);
        this.acceptInProcess = false;
      } catch (e) {
        this.showError(e);
      } finally {
        this.isSubmitting = false;
        this.acceptInProcess = false;
      }
    },
    showError(e) {
      const message = e.toString();
      const findError = error => {
        if (message.includes(error)) {
          return message;
        }
      };
      switch (message) {
        case findError('user-not-found'):
          this.$toast.error('There is no user record found.', {
            duration: 5000,
            position: 'top-center'
          });
          break;
        case findError('wrong-password'):
          this.$toast.error('The password is invalid or the user does not have a password.', {
            duration: 5000,
            position: 'top-center'
          });
          break;
        case findError('cannot create or join more'):
          this.$toast.error('You cannot create or join more than one private group per game.', {
            duration: 5000,
            position: 'top-center'
          });
          break;
        case findError('you must be logged in'):
          this.$toast.error('Sorry, you must be logged in to take this action.', {
            duration: 5000,
            position: 'top-center'
          });
          break;
        case findError('Invite does not exist'):
          this.$toast.error('User Invite does not exist.', {
            duration: 5000,
            position: 'top-center'
          });
          break;
        case findError('invitation is not valid'):
          this.$toast.error('The invitation is not valid.', {
            duration: 5000,
            position: 'top-center'
          });
          break;
        case findError('Channel does not exist'):
          this.$toast.error('The Private Channel does not exist.', {
            duration: 5000,
            position: 'top-center'
          });
          break;
        default:
          break;
      }
    }
  }
});
// CONCATENATED MODULE: ./components/pages/SignIn.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_SignInvue_type_script_lang_js_ = (SignInvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/pages/SignIn.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1113)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pages_SignInvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "efce236e",
  "0f152e78"
  
)

/* harmony default export */ var SignIn = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 558:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/google.605f953.svg";

/***/ }),

/***/ 900:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1114);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("7cd0645d", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=111.js.map
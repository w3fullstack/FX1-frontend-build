exports.ids = [75];
exports.modules = {

/***/ 1292:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_EventChatHistory_vue_vue_type_style_index_0_id_3bad8fe6_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(989);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_EventChatHistory_vue_vue_type_style_index_0_id_3bad8fe6_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_EventChatHistory_vue_vue_type_style_index_0_id_3bad8fe6_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_EventChatHistory_vue_vue_type_style_index_0_id_3bad8fe6_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_EventChatHistory_vue_vue_type_style_index_0_id_3bad8fe6_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1293:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".buttons[data-v-3bad8fe6]{display:flex;justify-content:center;align-items:center}.toggle-open[data-v-3bad8fe6]{order:1;border-bottom:4px solid #557278;width:45px;position:relative;top:20px;opacity:0;border-radius:10px;pointer-events:none}@media screen and (max-width:500px){.toggle-open[data-v-3bad8fe6]{opacity:1;pointer-events:all}}.close[data-v-3bad8fe6]{order:3;margin-left:auto;width:100%;display:flex;align-items:center;cursor:pointer}.xo-channel-chat-history[data-v-3bad8fe6]{min-height:100%}.xo-channel-chat-history[data-v-3bad8fe6] .navigation{display:flex;align-items:center;justify-content:space-evenly;position:relative;width:100%;min-height:70px;background-color:#08252c;border-top:1px solid #2a4e55;z-index:2}.xo-channel-chat-history[data-v-3bad8fe6] .navigation .nav-button{max-width:20px;max-height:20px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;opacity:.5}.xo-channel-chat-history[data-v-3bad8fe6] .navigation .nav-button span{margin-top:7px;font-weight:400;font-size:14px;line-height:15px;color:#fff}.xo-channel-chat-history[data-v-3bad8fe6] .navigation .nav-button-active{opacity:1}.xo-channel-chat-history[data-v-3bad8fe6] .emoji{position:relative;background-color:#08252c;overflow:hidden;border-top-left-radius:30px;border-top-right-radius:30px;width:100%!important}.xo-channel-chat-history[data-v-3bad8fe6] .emoji-mart{height:270px!important}@media screen and (min-width:1400px){.xo-channel-chat-history[data-v-3bad8fe6] .emoji-mart{height:400px!important}}@media screen and (max-width:767px){.xo-channel-chat-history[data-v-3bad8fe6] .emoji-mart{height:175px!important}}@media screen and (max-width:767px){.xo-channel-chat-history[data-v-3bad8fe6] .emoji{top:0!important}}.xo-channel-chat-history[data-v-3bad8fe6] .emoji .emoji-mart-search input{min-height:36px!important;border:1px solid #2a4e55;border-radius:4px;width:96%;margin:15px;background-color:#0c353e;color:#94a6aa;font-weight:400;font-size:14px;line-height:15px}@media screen and (min-width:1150px){.xo-channel-chat-history[data-v-3bad8fe6] .emoji .emoji-mart-search input{width:93%}}.xo-channel-chat-history[data-v-3bad8fe6] .emoji .emoji-mart-scroll{height:-moz-fit-content!important;height:fit-content!important;padding:0 6px 6px 18px;-ms-overflow-style:none;scrollbar-width:none}.xo-channel-chat-history[data-v-3bad8fe6] .emoji .emoji-mart-scroll::-webkit-scrollbar,.xo-channel-chat-history[data-v-3bad8fe6] .emoji .emoji-mart-scroll::-webkit-scrollbar-track{display:none}.xo-channel-chat-history[data-v-3bad8fe6] [id^=tippy-]{width:100%!important;pointer-events:inherit!important;z-index:100!important}.xo-channel-chat-history[data-v-3bad8fe6] .infinite-loading-container{margin-bottom:20px}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1440:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/Channels/EventChatHistory.vue?vue&type=template&id=3bad8fe6&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{ref:"historyChatContainer",staticClass:"xo-channel-chat-history flex-column",on:{"contextmenu":function($event){$event.preventDefault();}}},[_c('infinite-loading',{directives:[{name:"show",rawName:"v-show",value:((_vm.chats.length >= 10 && _vm.showInfiniteLoading) || !_vm.filteredLocalChats.length),expression:"(chats.length >= 10 && showInfiniteLoading) || !filteredLocalChats.length"}],ref:"infiniteLoading",attrs:{"direction":"top","distance":300},on:{"infinite":_vm.fnRetrieveNextChats}},[_c('div',{attrs:{"slot":"spinner"},slot:"spinner"},[_c('XAChannelsChatLoader')],1),_c('div',{attrs:{"slot":"no-more"},slot:"no-more"}),_c('div',{attrs:{"slot":"no-results"},slot:"no-results"})]),_vm._l((_vm.filteredAddedChats),function(addedChat,index){return _c('XMChannelsChatItem',{key:(index + "-added-chat"),attrs:{"chat":addedChat,"scroll-to-bottom":false,"small":true}})}),_vm._l((_vm.filteredLocalChats),function(chat,index){return _c('XMChannelsChatItem',{key:(index + "-chat"),attrs:{"chat":chat,"is-last":index === _vm.filteredLocalChats.length - 1,"small":true}})}),_c('XAChannelsTyping',{directives:[{name:"show",rawName:"v-show",value:(_vm.usersTyping.length),expression:"usersTyping.length"}],attrs:{"users-typing":_vm.usersTyping}}),(_vm.isLoggedIn)?_vm._ssrNode("<div class=\"emoji\" data-v-3bad8fe6>","</div>",[_vm._ssrNode("<div class=\"buttons\" data-v-3bad8fe6><div data-v-3bad8fe6><div class=\"toggle-open\" data-v-3bad8fe6></div></div><div class=\"close\" data-v-3bad8fe6><span data-v-3bad8fe6>Close</span><img"+(_vm._ssrAttr("src",__webpack_require__(448)))+" alt=\"close\" data-v-3bad8fe6></div></div>"),_c('EmojiPicker',{directives:[{name:"show",rawName:"v-show",value:(_vm.activeNav === 'Emoji'),expression:"activeNav === 'Emoji'"}],attrs:{"fullScreen":_vm.fullScreen},on:{"updateMessage":function($event){return _vm.$emit('updateMessage', $event)}}}),_c('GifsComponent',{directives:[{name:"show",rawName:"v-show",value:(_vm.activeNav !== 'Emoji'),expression:"activeNav !== 'Emoji'"}],ref:"gifsComponentRef",attrs:{"gifsToRender":_vm.gifsToRender,"search":_vm.search,"activeNav":_vm.activeNav,"fullScreen":_vm.fullScreen},on:{"updateSearch":function($event){return _vm.$emit('updateSearch', $event)},"handleScroll":function($event){return _vm.$emit('handleScrollGifs', $event)}}}),_vm._ssrNode("<div class=\"navigation\" data-v-3bad8fe6>"+(_vm._ssrList((_vm.navButtons),function(item){return ("<div"+(_vm._ssrClass("nav-button",{ 'nav-button-active': item.label === _vm.activeNav }))+" data-v-3bad8fe6><img"+(_vm._ssrAttr("src",__webpack_require__(545)("./" + (item.icon) + ".svg")))+(_vm._ssrAttr("alt",item.label))+" data-v-3bad8fe6><span data-v-3bad8fe6>"+_vm._ssrEscape(_vm._s(item.label))+"</span></div>")}))+"</div>")],2):_vm._e()],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/Channels/EventChatHistory.vue?vue&type=template&id=3bad8fe6&scoped=true&lang=pug&

// EXTERNAL MODULE: external "vuex-map-fields"
var external_vuex_map_fields_ = __webpack_require__(2);

// EXTERNAL MODULE: external "vuex"
var external_vuex_ = __webpack_require__(4);

// EXTERNAL MODULE: external "tippy.js"
var external_tippy_js_ = __webpack_require__(216);
var external_tippy_js_default = /*#__PURE__*/__webpack_require__.n(external_tippy_js_);

// EXTERNAL MODULE: ./node_modules/tippy.js/animations/shift-away-extreme.css
var shift_away_extreme = __webpack_require__(827);

// EXTERNAL MODULE: ./components/templates/LockerRoom/EmojiPicker.vue + 4 modules
var EmojiPicker = __webpack_require__(567);

// EXTERNAL MODULE: ./components/templates/LockerRoom/GifsComponent.vue + 4 modules
var GifsComponent = __webpack_require__(537);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/Channels/EventChatHistory.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//







/* harmony default export */ var EventChatHistoryvue_type_script_lang_js_ = ({
  name: 'XOChannelsChatHistory',
  components: {
    GifsComponent: GifsComponent["a" /* default */],
    EmojiPicker: EmojiPicker["a" /* default */],
    XMChannelsChatItem: () => __webpack_require__.e(/* import() */ 82).then(__webpack_require__.bind(null, 1296)),
    XAChannelsChatLoader: () => __webpack_require__.e(/* import() */ 20).then(__webpack_require__.bind(null, 1396)),
    XAChannelsTyping: () => __webpack_require__.e(/* import() */ 21).then(__webpack_require__.bind(null, 1397))
  },
  props: {
    chats: {
      type: Array,
      default: () => []
    },
    showInfiniteLoading: {
      type: Boolean,
      default: false
    },
    usersTyping: {
      type: Array,
      default: () => []
    },
    channelSlug: {
      type: String,
      default: ''
    },
    activeChat: {
      type: [String, undefined],
      default: ''
    },
    search: {
      type: String,
      default: ''
    },
    privateChannel: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      cursor: 10,
      addedChats: [],
      localChats: this.chats || [],
      navButtons: [{
        id: 1,
        label: 'Emoji',
        icon: 'emoji-icon'
      }, {
        id: 2,
        label: 'Sticker',
        icon: 'sticker-icon'
      }, {
        id: 3,
        label: 'GIF',
        icon: 'gif-icon'
      }],
      activeNav: 'Emoji',
      fullScreen: false
    };
  },
  computed: {
    ...Object(external_vuex_map_fields_["mapFields"])('messages', ['messageNext']),
    ...Object(external_vuex_map_fields_["mapFields"])('user', ['userID']),
    ...Object(external_vuex_["mapGetters"])({
      getChatDeletedForEveryone: 'chats/getChatDeletedForEveryone',
      getChatDeletedForSelf: 'chats/getChatDeletedForSelf',
      gifs: 'giphy/getGifs',
      filteredGifs: 'giphy/getFilteredGifs'
    }),
    gifsToRender() {
      var _this$search;
      return (_this$search = this.search) !== null && _this$search !== void 0 && _this$search.length && this.filteredGifs.length ? this.filteredGifs : this.gifs;
    },
    filteredLocalChats() {
      const deletedEveryoneChats = this.localChats.filter(x => {
        return !(x !== null && x !== void 0 && x.isDeletedEveryone) && !this.getChatDeletedForEveryone.includes(x === null || x === void 0 ? void 0 : x.chatID);
      });
      const deletedSelfChats = deletedEveryoneChats.filter(x => {
        var _x$User;
        if ((x === null || x === void 0 ? void 0 : (_x$User = x.User) === null || _x$User === void 0 ? void 0 : _x$User.id) === this.userID) {
          return !(x !== null && x !== void 0 && x.isDeletedSelf) && !this.getChatDeletedForSelf.includes(x === null || x === void 0 ? void 0 : x.chatID);
        }
        return x;
      });
      return deletedSelfChats;
    },
    filteredAddedChats() {
      const deletedEveryoneChats = this.addedChats.filter(x => {
        return !(x !== null && x !== void 0 && x.isDeletedEveryone) && !this.getChatDeletedForEveryone.includes(x === null || x === void 0 ? void 0 : x.chatID);
      });
      const deletedSelfChats = deletedEveryoneChats.filter(x => {
        var _x$User2;
        if ((x === null || x === void 0 ? void 0 : (_x$User2 = x.User) === null || _x$User2 === void 0 ? void 0 : _x$User2.id) === this.userID) {
          return !(x !== null && x !== void 0 && x.isDeletedSelf) && !this.getChatDeletedForSelf.includes(x === null || x === void 0 ? void 0 : x.chatID);
        }
        return x;
      });
      return deletedSelfChats;
    }
  },
  watch: {
    activeNav(newValue) {
      this.$emit('updateNav', newValue);
    },
    usersTyping() {
      this.$nextTick(() => {
        const wrapper = this.$refs.historyChatContainer.closest('.vuebar');
        const typingEl = document.querySelector('.xa-channels-typing');
        if (Math.floor(wrapper.scrollHeight - wrapper.offsetHeight - wrapper.scrollTop - typingEl.offsetHeight) <= 0) {
          this.$root.$emit('evtRtScrollToBottom');
        }
      });
    },
    chats: {
      deep: true,
      handler(newV) {
        this.cursor = 10;
        this.addedChats = [];
        this.localChats = newV;
        this.fnRetrieveNextChats(this.$refs.infiniteLoading.stateChanger, true);
      }
    }
  },
  mounted() {
    external_tippy_js_default()('#iconEmoji', {
      content: this.$refs.privateChatEmoji,
      animation: 'shift-away-extreme',
      maxWidth: 'none',
      interactive: true,
      touch: true,
      duration: [200, 300],
      trigger: 'click',
      hideOnClick: 'toggle',
      allowHTML: true
    });
    this.$root.$on('evtRtUpdateChatList', chat => {
      const indexLocalChats = this.localChats.findIndex(x => {
        return (x === null || x === void 0 ? void 0 : x.chatID) === (chat === null || chat === void 0 ? void 0 : chat.chatID);
      });
      const indexAddedChats = this.addedChats.findIndex(x => {
        return (x === null || x === void 0 ? void 0 : x.chatID) === (chat === null || chat === void 0 ? void 0 : chat.chatID);
      });
      if (this.localChats[indexLocalChats]) {
        this.localChats[indexLocalChats].text = chat === null || chat === void 0 ? void 0 : chat.text;
        this.localChats[indexLocalChats].isEdited = chat === null || chat === void 0 ? void 0 : chat.isEdited;
      }
      if (this.addedChats[indexAddedChats]) {
        this.addedChats[indexAddedChats].text = chat === null || chat === void 0 ? void 0 : chat.text;
        this.addedChats[indexAddedChats].isEdited = chat === null || chat === void 0 ? void 0 : chat.isEdited;
      }
    });
  },
  methods: {
    hide() {
      Object(external_tippy_js_["hideAll"])();
    },
    toggleEmoji() {
      this.fullScreen = !this.fullScreen;
    },
    async fnRetrieveNextChats($state, reset = false) {
      if (reset) {
        $state.reset();
        return;
      }
      try {
        var _this$privateChannel;
        const params = {
          channelSlug: this.activeChat === 'private' ? (_this$privateChannel = this.privateChannel) === null || _this$privateChannel === void 0 ? void 0 : _this$privateChannel.slug : this.channelSlug,
          count: 10,
          cursor: this.cursor
        };
        const {
          getMessagesByChannelSlug: {
            items,
            next
          }
        } = await this.$api.getMessagesByChannelSlug(params);
        this.cursor = next;
        if (items.length) {
          if (this.filteredLocalChats.length) {
            this.addedChats.unshift(...items);
          } else {
            this.localChats.unshift(...items);
          }
          $state.loaded();
          return;
        }
        $state.complete();
      } catch (error) {
        var _error$response;
        error === null || error === void 0 ? void 0 : (_error$response = error.response) === null || _error$response === void 0 ? void 0 : _error$response.errors.forEach(error => {
          this.$toast.success(error.message, {
            duration: 5000,
            position: 'bottom-left',
            className: 'fx1-success',
            iconPack: 'mdi',
            icon: 'alert-circle-outline'
          });
        });
      }
    }
  }
});
// CONCATENATED MODULE: ./components/organisms/Channels/EventChatHistory.vue?vue&type=script&lang=js&
 /* harmony default export */ var Channels_EventChatHistoryvue_type_script_lang_js_ = (EventChatHistoryvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/organisms/Channels/EventChatHistory.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1292)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Channels_EventChatHistoryvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "3bad8fe6",
  "4d8b5019"
  
)

/* harmony default export */ var EventChatHistory = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 447:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTciIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAxNyAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0wIDBIMTYuNVYyNEMxMi43Mzg4IDEwLjc2NTMgOS4wOTc0NCA1LjQ3Mjg4IDAgMFoiIGZpbGw9IiMyQTRFNTUiLz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 448:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTQiIGhlaWdodD0iMTQiIHZpZXdCb3g9IjAgMCAxNCAxNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0xNCAxLjQxTDEyLjU5IDBMNyA1LjU5TDEuNDEgMEwwIDEuNDFMNS41OSA3TDAgMTIuNTlMMS40MSAxNEw3IDguNDFMMTIuNTkgMTRMMTQgMTIuNTlMOC40MSA3TDE0IDEuNDFaIiBmaWxsPSJ3aGl0ZSIvPg0KPC9zdmc+DQo="

/***/ }),

/***/ 449:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0xNiA3SDMuODNMOS40MiAxLjQxTDggMEwwIDhMOCAxNkw5LjQxIDE0LjU5TDMuODMgOUgxNlY3WiIgZmlsbD0id2hpdGUiLz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 450:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHZpZXdCb3g9IjAgMCAxOCAxOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNOC45OTk4NCAwLjY2NjUwNEM0LjM5OTg0IDAuNjY2NTA0IDAuNjY2NTA0IDQuMzk5ODQgMC42NjY1MDQgOC45OTk4NEMwLjY2NjUwNCAxMy41OTk4IDQuMzk5ODQgMTcuMzMzMiA4Ljk5OTg0IDE3LjMzMzJDMTMuNTk5OCAxNy4zMzMyIDE3LjMzMzIgMTMuNTk5OCAxNy4zMzMyIDguOTk5ODRDMTcuMzMzMiA0LjM5OTg0IDEzLjU5OTggMC42NjY1MDQgOC45OTk4NCAwLjY2NjUwNFpNOC45OTk4NCAxNS42NjY1QzUuMzI0ODQgMTUuNjY2NSAyLjMzMzE3IDEyLjY3NDggMi4zMzMxNyA4Ljk5OTg0QzIuMzMzMTcgNS4zMjQ4NCA1LjMyNDg0IDIuMzMzMTcgOC45OTk4NCAyLjMzMzE3QzEyLjY3NDggMi4zMzMxNyAxNS42NjY1IDUuMzI0ODQgMTUuNjY2NSA4Ljk5OTg0QzE1LjY2NjUgMTIuNjc0OCAxMi42NzQ4IDE1LjY2NjUgOC45OTk4NCAxNS42NjY1Wk03LjMzMzE3IDEwLjgwODJMMTIuODI0OCA1LjMxNjVMMTMuOTk5OCA2LjQ5OTg0TDcuMzMzMTcgMTMuMTY2NUwzLjk5OTg0IDkuODMzMTdMNS4xNzQ4NCA4LjY1ODE3TDcuMzMzMTcgMTAuODA4MloiIGZpbGw9IndoaXRlIi8+DQo8L3N2Zz4NCg=="

/***/ }),

/***/ 457:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4NCjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+DQo8c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHZlcnNpb249IjEuMSIgIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0Ij4NCiAgIDxwYXRoIGZpbGw9IiMwNTA1MDUiIGQ9Ik0xMiw0QTQsNCAwIDAsMSAxNiw4QTQsNCAwIDAsMSAxMiwxMkE0LDQgMCAwLDEgOCw4QTQsNCAwIDAsMSAxMiw0TTEyLDE0QzE2LjQyLDE0IDIwLDE1Ljc5IDIwLDE4VjIwSDRWMThDNCwxNS43OSA3LjU4LDE0IDEyLDE0WiIgLz4NCjwvc3ZnPg=="

/***/ }),

/***/ 458:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/distance.2e8b927.svg";

/***/ }),

/***/ 459:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/emoji-icon.ada9ed9.svg";

/***/ }),

/***/ 460:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTEiIGhlaWdodD0iMjIiIHZpZXdCb3g9IjAgMCAxMSAyMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik05LjUgNVYxNi41QzkuNSAxOC43MSA3LjcxIDIwLjUgNS41IDIwLjVDMy4yOSAyMC41IDEuNSAxOC43MSAxLjUgMTYuNVY0QzEuNSAyLjYyIDIuNjIgMS41IDQgMS41QzUuMzggMS41IDYuNSAyLjYyIDYuNSA0VjE0LjVDNi41IDE1LjA1IDYuMDUgMTUuNSA1LjUgMTUuNUM0Ljk1IDE1LjUgNC41IDE1LjA1IDQuNSAxNC41VjVIM1YxNC41QzMgMTUuODggNC4xMiAxNyA1LjUgMTdDNi44OCAxNyA4IDE1Ljg4IDggMTQuNVY0QzggMS43OSA2LjIxIDAgNCAwQzEuNzkgMCAwIDEuNzkgMCA0VjE2LjVDMCAxOS41NCAyLjQ2IDIyIDUuNSAyMkM4LjU0IDIyIDExIDE5LjU0IDExIDE2LjVWNUg5LjVaIiBmaWxsPSJ3aGl0ZSIvPg0KPC9zdmc+DQo="

/***/ }),

/***/ 461:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgZmlsbD0ibm9uZSIgdmlld0JveD0iMCAwIDI0IDI0IiBpZD0iZ2lmIj4NCiAgPHBhdGggc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCINCiAgICAgICAgZD0iTTIgNkMyIDMuNzkwODYgMy43OTA4NiAyIDYgMkgxOEMyMC4yMDkxIDIgMjIgMy43OTA4NiAyMiA2VjE4QzIyIDIwLjIwOTEgMjAuMjA5MSAyMiAxOCAyMkg2QzMuNzkwODYgMjIgMiAyMC4yMDkxIDIgMThWNloiPjwvcGF0aD4NCiAgPHBhdGggc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCINCiAgICAgICAgZD0iTTEyIDhWMTZNMTUgMTZWMTJNMTkgOEgxNS41QzE1LjIyMzkgOCAxNSA4LjIyMzg2IDE1IDguNVYxMk0xNSAxMkgxOE05IDhINy41QzYuMTE5MjkgOCA1IDkuMTE5MjkgNSAxMC41VjEyIDEzLjc3NzhDNSAxNS4wMDUxIDUuOTk0OTIgMTYgNy4yMjIyMiAxNlYxNkM4LjIwNDA2IDE2IDkgMTUuMjA0MSA5IDE0LjIyMjJWMTIuNUM5IDEyLjIyMzkgOC43NzYxNCAxMiA4LjUgMTJINy41Ij48L3BhdGg+DQo8L3N2Zz4NCg=="

/***/ }),

/***/ 462:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTQiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNCAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik03LjU3MDMxIDE2TDEwLjE5NTMgLTQuNzY4MzdlLTA3SDEyLjA3MDNMOS40NDUzMSAxNkg3LjU3MDMxWk0wLjMyODEyNSAxMS43MTg3TDAuNjMyODEzIDkuODQzNzVIMTIuNzU3OEwxMi40NTMxIDExLjcxODdIMC4zMjgxMjVaTTEuOTQ1MzEgMTZMNC41NzAzMSAtNC43NjgzN2UtMDdINi40NDUzMUwzLjgyMDMxIDE2SDEuOTQ1MzFaTTEuMjU3ODEgNi4xNTYyNUwxLjU2MjUgNC4yODEyNUgxMy42ODc1TDEzLjM4MjggNi4xNTYyNUgxLjI1NzgxWiIgZmlsbD0iIzBDMzUzRSIvPg0KPC9zdmc+DQo="

/***/ }),

/***/ 463:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/place.9eae76e.svg";

/***/ }),

/***/ 464:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTQiIGhlaWdodD0iMTQiIHZpZXdCb3g9IjAgMCAxNCAxNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNMC4zMzIwMzEgNi45OTk5MkMwLjMzMjAzMSAzLjMxOTkyIDMuMzE4NyAwLjMzMzI1MiA2Ljk5ODcgMC4zMzMyNTJDMTAuNjc4NyAwLjMzMzI1MiAxMy42NjU0IDMuMzE5OTIgMTMuNjY1NCA2Ljk5OTkyQzEzLjY2NTQgMTAuNjc5OSAxMC42Nzg3IDEzLjY2NjYgNi45OTg3IDEzLjY2NjZDMy4zMTg3IDEzLjY2NjYgMC4zMzIwMzEgMTAuNjc5OSAwLjMzMjAzMSA2Ljk5OTkyWk05LjY2NTM3IDYuOTk5OTJMNS42NjUzNiAzLjk5OTkyVjkuOTk5OTJMOS42NjUzNyA2Ljk5OTkyWiIgZmlsbD0id2hpdGUiLz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 465:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTIiIGhlaWdodD0iMTIiIHZpZXdCb3g9IjAgMCAxMiAxMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNOC41Nzg0NSAwTDIuNjM1ODkgNS45NDI1NkwyLjY5MzMzIDZMMi42MzU4OSA2LjA1NzQ0TDguNTc4NDUgMTJMOS4zNjMyOCAxMS4yMTUyTDQuMTQ4MTEgNkw5LjM2MzI4IDAuNzg0ODI4TDguNTc4NDUgMFoiIGZpbGw9IiMwQzM1M0UiLz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 466:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTIiIGhlaWdodD0iMTIiIHZpZXdCb3g9IjAgMCAxMiAxMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNMy40MjE1NSAwTDkuMzY0MTEgNS45NDI1Nkw5LjMwNjY3IDZMOS4zNjQxMSA2LjA1NzQ0TDMuNDIxNTUgMTJMMi42MzY3MiAxMS4yMTUyTDcuODUxODkgNkwyLjYzNjcyIDAuNzg0ODI4TDMuNDIxNTUgMFoiIGZpbGw9IndoaXRlIi8+DQo8L3N2Zz4NCg=="

/***/ }),

/***/ 467:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjIiIGhlaWdodD0iMjIiIHZpZXdCb3g9IjAgMCAyMiAyMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0yMSAxMUMyMSAxNi41MjMgMTYuNTIzIDIxIDExIDIxQzUuNDc3IDIxIDEgMTYuNTIzIDEgMTFDMSA1LjQ3NyA1LjQ3NyAxIDExIDFNMjEgMTFDMjEgMTEgMTUuNzUgMTIuNSAxMi41IDlDOS4yNSA1LjUgMTEgMSAxMSAxTTIxIDExTDExIDEiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS13aWR0aD0iMS41IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 468:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/time.6620a0e.svg";

/***/ }),

/***/ 469:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/trending.e9241d6.svg";

/***/ }),

/***/ 470:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(549);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("11ebea78", content, true, context)
};

/***/ }),

/***/ 545:
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./account.svg": 457,
	"./add-secondary.svg": 304,
	"./arrow-left.svg": 449,
	"./channel.svg": 441,
	"./chat-border.svg": 447,
	"./chat.svg": 445,
	"./check-secondary.svg": 305,
	"./close-icon.svg": 448,
	"./distance.svg": 458,
	"./emoji-icon.svg": 459,
	"./emoji.svg": 439,
	"./file.svg": 460,
	"./gif-icon.svg": 461,
	"./hash-tag.svg": 462,
	"./place.svg": 463,
	"./play.svg": 464,
	"./reply.svg": 437,
	"./send.svg": 438,
	"./slider-navigation-left.svg": 465,
	"./slider-navigation-right.svg": 466,
	"./sticker-icon.svg": 467,
	"./supported.svg": 450,
	"./time.svg": 468,
	"./trending.svg": 469
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 545;

/***/ }),

/***/ 546:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(547);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
__webpack_require__(7).default("072b2f8a", content, true)

/***/ }),

/***/ 547:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".emoji-mart,.emoji-mart *{-webkit-box-sizing:border-box;box-sizing:border-box;line-height:1.15}.emoji-mart{font-family:-apple-system,BlinkMacSystemFont,\"Helvetica Neue\",sans-serif;font-size:16px;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;height:420px;color:#222427;border:1px solid #d9d9d9;border-radius:5px;background:#fff}.emoji-mart-emoji{padding:6px;border:none;background:none;-webkit-box-shadow:none;box-shadow:none}.emoji-mart-emoji span{display:inline-block}.emoji-mart-preview-emoji .emoji-mart-emoji span{width:38px;height:38px;font-size:32px}.emoji-type-native{font-family:\"Segoe UI Emoji\",\"Segoe UI Symbol\",\"Segoe UI\",\"Apple Color Emoji\",\"Twemoji Mozilla\",\"Noto Color Emoji\",\"EmojiOne Color\",\"Android Emoji\";word-break:keep-all}.emoji-type-image{background-size:6100%}.emoji-type-image.emoji-set-apple{background-image:url(https://unpkg.com/emoji-datasource-apple@15.0.1/img/apple/sheets-256/64.png)}.emoji-type-image.emoji-set-facebook{background-image:url(https://unpkg.com/emoji-datasource-facebook@15.0.1/img/facebook/sheets-256/64.png)}.emoji-type-image.emoji-set-google{background-image:url(https://unpkg.com/emoji-datasource-google@15.0.1/img/google/sheets-256/64.png)}.emoji-type-image.emoji-set-twitter{background-image:url(https://unpkg.com/emoji-datasource-twitter@15.0.1/img/twitter/sheets-256/64.png)}.emoji-mart-bar{border:0 solid #d9d9d9}.emoji-mart-bar:first-child{border-bottom-width:1px;border-top-left-radius:5px;border-top-right-radius:5px}.emoji-mart-bar:last-child{border-top-width:1px;border-bottom-left-radius:5px;border-bottom-right-radius:5px}.emoji-mart-scroll{position:relative;overflow-y:scroll;-webkit-box-flex:1;-ms-flex:1;flex:1;padding:0 6px 6px;z-index:0;will-change:transform;-webkit-overflow-scrolling:touch}.emoji-mart-anchors{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:horizontal;-webkit-box-direction:normal;-ms-flex-direction:row;flex-direction:row;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;padding:0 6px;color:#858585;line-height:0}.emoji-mart-anchor{position:relative;display:block;-webkit-box-flex:1;-ms-flex:1 1 auto;flex:1 1 auto;text-align:center;padding:12px 4px;overflow:hidden;-webkit-transition:color .1s ease-out;transition:color .1s ease-out;border:none;background:none;-webkit-box-shadow:none;box-shadow:none}.emoji-mart-anchor-selected,.emoji-mart-anchor:hover{color:#464646}.emoji-mart-anchor-selected .emoji-mart-anchor-bar{bottom:0}.emoji-mart-anchor-bar{position:absolute;bottom:-3px;left:0;width:100%;height:3px;background-color:#464646}.emoji-mart-anchors i{display:inline-block;width:100%;max-width:22px}.emoji-mart-anchors svg{fill:currentColor;max-height:18px}.emoji-mart .scroller{height:250px;position:relative;-webkit-box-flex:1;-ms-flex:1;flex:1;padding:0 6px 6px;z-index:0;will-change:transform;-webkit-overflow-scrolling:touch}.emoji-mart-search{margin-top:6px;padding:0 6px}.emoji-mart-search input{font-size:16px;display:block;width:100%;padding:.2em .6em;border-radius:25px;border:1px solid #d9d9d9;outline:0}.emoji-mart-search-results{height:250px;overflow-y:scroll}.emoji-mart-category{position:relative}.emoji-mart-category .emoji-mart-emoji span{z-index:1;position:relative;text-align:center;cursor:default}.emoji-mart-category .emoji-mart-emoji:hover:before,.emoji-mart-emoji-selected:before{z-index:0;content:\"\";position:absolute;top:0;left:0;width:100%;height:100%;background-color:#f4f4f4;border-radius:100%;opacity:0;opacity:1}.emoji-mart-category-label{position:-webkit-sticky;position:sticky;top:0}.emoji-mart-static .emoji-mart-category-label{z-index:2;position:relative}.emoji-mart-category-label h3{display:block;font-size:16px;width:100%;font-weight:500;padding:5px 6px;background-color:#fff;background-color:hsla(0,0%,100%,.95)}.emoji-mart-emoji{position:relative;display:inline-block;font-size:0}.emoji-mart-no-results{font-size:14px;text-align:center;padding-top:70px;color:#858585}.emoji-mart-no-results .emoji-mart-category-label{display:none}.emoji-mart-no-results .emoji-mart-no-results-label{margin-top:.2em}.emoji-mart-no-results .emoji-mart-emoji:hover:before{content:none}.emoji-mart-preview{position:relative;height:70px}.emoji-mart-preview-data,.emoji-mart-preview-emoji,.emoji-mart-preview-skins{position:absolute;top:50%;-webkit-transform:translateY(-50%);-ms-transform:translateY(-50%);transform:translateY(-50%)}.emoji-mart-preview-emoji{left:12px}.emoji-mart-preview-data{left:68px;right:12px;word-break:break-all}.emoji-mart-preview-skins{right:30px;text-align:right}.emoji-mart-preview-name{font-size:14px}.emoji-mart-preview-shortname{font-size:12px;color:#888}.emoji-mart-preview-emoticon+.emoji-mart-preview-emoticon,.emoji-mart-preview-shortname+.emoji-mart-preview-emoticon,.emoji-mart-preview-shortname+.emoji-mart-preview-shortname{margin-left:.5em}.emoji-mart-preview-emoticon{font-size:11px;color:#bbb}.emoji-mart-title span{display:inline-block;vertical-align:middle}.emoji-mart-title .emoji-mart-emoji{padding:0}.emoji-mart-title-label{color:#999a9c;font-size:21px;font-weight:300}.emoji-mart-skin-swatches{font-size:0;padding:2px 0;border:1px solid #d9d9d9;border-radius:12px;background-color:#fff}.emoji-mart-skin-swatches-opened .emoji-mart-skin-swatch{width:16px;padding:0 2px}.emoji-mart-skin-swatches-opened .emoji-mart-skin-swatch-selected:after{opacity:.75}.emoji-mart-skin-swatch{display:inline-block;width:0;vertical-align:middle;-webkit-transition-property:width,padding;transition-property:width,padding;-webkit-transition-duration:.125s;transition-duration:.125s;-webkit-transition-timing-function:ease-out;transition-timing-function:ease-out}.emoji-mart-skin-swatch:first-child{-webkit-transition-delay:0s;transition-delay:0s}.emoji-mart-skin-swatch:nth-child(2){-webkit-transition-delay:.03s;transition-delay:.03s}.emoji-mart-skin-swatch:nth-child(3){-webkit-transition-delay:.06s;transition-delay:.06s}.emoji-mart-skin-swatch:nth-child(4){-webkit-transition-delay:.09s;transition-delay:.09s}.emoji-mart-skin-swatch:nth-child(5){-webkit-transition-delay:.12s;transition-delay:.12s}.emoji-mart-skin-swatch:nth-child(6){-webkit-transition-delay:.15s;transition-delay:.15s}.emoji-mart-skin-swatch-selected{position:relative;width:16px;padding:0 2px}.emoji-mart-skin-swatch-selected:after{content:\"\";position:absolute;top:50%;left:50%;width:4px;height:4px;margin:-2px 0 0 -2px;background-color:#fff;border-radius:100%;pointer-events:none;opacity:0;-webkit-transition:opacity .2s ease-out;transition:opacity .2s ease-out}.emoji-mart-skin{display:inline-block;width:100%;padding-top:100%;max-width:12px;border-radius:100%}.emoji-mart-skin-tone-1{background-color:#ffc93a}.emoji-mart-skin-tone-2{background-color:#fadcbc}.emoji-mart-skin-tone-3{background-color:#e0bb95}.emoji-mart-skin-tone-4{background-color:#bf8f68}.emoji-mart-skin-tone-5{background-color:#9b643d}.emoji-mart-skin-tone-6{background-color:#594539}.emoji-mart .vue-recycle-scroller{position:relative}.emoji-mart .vue-recycle-scroller.direction-vertical:not(.page-mode){overflow-y:auto}.emoji-mart .vue-recycle-scroller.direction-horizontal:not(.page-mode){overflow-x:auto}.emoji-mart .vue-recycle-scroller.direction-horizontal{display:-webkit-box;display:-ms-flexbox;display:flex}.emoji-mart .vue-recycle-scroller__slot{-webkit-box-flex:1;-ms-flex:auto 0 0px;flex:auto 0 0}.emoji-mart .vue-recycle-scroller__item-wrapper{-webkit-box-flex:1;-ms-flex:1;flex:1;-webkit-box-sizing:border-box;box-sizing:border-box;overflow:hidden;position:relative}.emoji-mart .vue-recycle-scroller.ready .vue-recycle-scroller__item-view{position:absolute;top:0;left:0;will-change:transform}.emoji-mart .vue-recycle-scroller.direction-vertical .vue-recycle-scroller__item-wrapper{width:100%}.emoji-mart .vue-recycle-scroller.direction-horizontal .vue-recycle-scroller__item-wrapper{height:100%}.emoji-mart .vue-recycle-scroller.ready.direction-vertical .vue-recycle-scroller__item-view{width:100%}.emoji-mart .vue-recycle-scroller.ready.direction-horizontal .vue-recycle-scroller__item-view{height:100%}.emoji-mart .resize-observer[data-v-b329ee4c]{border:none;background-color:transparent;opacity:0}.emoji-mart .resize-observer[data-v-b329ee4c],.emoji-mart .resize-observer[data-v-b329ee4c] object{position:absolute;top:0;left:0;z-index:-1;width:100%;height:100%;pointer-events:none;display:block;overflow:hidden}.emoji-mart-search .hidden{display:none;visibility:hidden}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 548:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_EmojiPicker_vue_vue_type_style_index_0_id_11aadd58_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(470);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_EmojiPicker_vue_vue_type_style_index_0_id_11aadd58_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_EmojiPicker_vue_vue_type_style_index_0_id_11aadd58_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_EmojiPicker_vue_vue_type_style_index_0_id_11aadd58_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_EmojiPicker_vue_vue_type_style_index_0_id_11aadd58_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 549:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".emoji-mart[data-v-11aadd58]{background-color:transparent!important;width:100%!important;height:350px!important;border:none!important}.emoji-mart[data-v-11aadd58] .emoji-mart-category-label{display:none}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 567:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/templates/LockerRoom/EmojiPicker.vue?vue&type=template&id=11aadd58&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('picker',{attrs:{"data":_vm.emojiIndex,"showCategories":false,"showPreview":false,"pickerStyles":_vm.isFullScreen && _vm.windowWidth < 427 ? _vm.pickerStyles : null},on:{"select":_vm.onEmojiSelect}})}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/templates/LockerRoom/EmojiPicker.vue?vue&type=template&id=11aadd58&scoped=true&lang=pug&

// EXTERNAL MODULE: external "emoji-mart-vue-fast/data/all.json"
var all_json_ = __webpack_require__(222);
var all_json_default = /*#__PURE__*/__webpack_require__.n(all_json_);

// EXTERNAL MODULE: external "emoji-mart-vue-fast"
var external_emoji_mart_vue_fast_ = __webpack_require__(223);

// EXTERNAL MODULE: ./node_modules/emoji-mart-vue-fast/css/emoji-mart.css
var emoji_mart = __webpack_require__(546);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/templates/LockerRoom/EmojiPicker.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//




const emojiIndex = new external_emoji_mart_vue_fast_["EmojiIndex"](all_json_default.a);
/* harmony default export */ var EmojiPickervue_type_script_lang_js_ = ({
  name: 'EmojiPicker',
  components: {
    Picker: external_emoji_mart_vue_fast_["Picker"]
  },
  props: {
    pickerStyles: {
      type: Object,
      default: () => ({
        height: 'calc(100vh - 240px) !important'
      })
    },
    fullScreen: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      emojiIndex,
      isFullScreen: false,
      windowWidth: null
    };
  },
  watch: {
    fullScreen: {
      deep: true,
      handler(value) {
        this.isFullScreen = value;
      }
    }
  },
  mounted() {
    window.addEventListener('resize', this.onResize);
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.onResize);
  },
  methods: {
    onEmojiSelect(emoji) {
      this.$emit('updateMessage', emoji.native);
    },
    onResize() {
      this.windowWidth = window.innerWidth;
    }
  }
});
// CONCATENATED MODULE: ./components/templates/LockerRoom/EmojiPicker.vue?vue&type=script&lang=js&
 /* harmony default export */ var LockerRoom_EmojiPickervue_type_script_lang_js_ = (EmojiPickervue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/templates/LockerRoom/EmojiPicker.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(548)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  LockerRoom_EmojiPickervue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "11aadd58",
  "df461610"
  
)

/* harmony default export */ var EmojiPicker = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ 827:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(828);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
__webpack_require__(7).default("05bfffe6", content, true)

/***/ }),

/***/ 828:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".tippy-box[data-animation=shift-away-extreme][data-state=hidden]{opacity:0}.tippy-box[data-animation=shift-away-extreme][data-state=hidden][data-placement^=top]{transform:translateY(20px)}.tippy-box[data-animation=shift-away-extreme][data-state=hidden][data-placement^=bottom]{transform:translateY(-20px)}.tippy-box[data-animation=shift-away-extreme][data-state=hidden][data-placement^=left]{transform:translateX(20px)}.tippy-box[data-animation=shift-away-extreme][data-state=hidden][data-placement^=right]{transform:translateX(-20px)}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 989:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1293);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("7d8d31f2", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=75.js.map
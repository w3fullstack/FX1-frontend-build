exports.ids = [77];
exports.modules = {

/***/ 1156:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FooterBase_vue_vue_type_style_index_0_id_a795a14e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(921);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FooterBase_vue_vue_type_style_index_0_id_a795a14e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FooterBase_vue_vue_type_style_index_0_id_a795a14e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FooterBase_vue_vue_type_style_index_0_id_a795a14e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_FooterBase_vue_vue_type_style_index_0_id_a795a14e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1157:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xo-default-footer-navigation[data-v-a795a14e]{padding:40px 0 30px}.xo-default-footer-navigation[data-v-a795a14e] .container{padding-left:5%;padding-right:5%;margin-left:5%;margin-right:5%;max-width:100%}.xo-default-footer-navigation[data-v-a795a14e] .flex-none{flex:none!important;margin-right:200px}.xo-default-footer-navigation[data-v-a795a14e] .d-flex{display:flex!important}.xo-default-footer-navigation[data-v-a795a14e] .d-inline-block{display:inline-block}.xo-default-footer-navigation[data-v-a795a14e] .gap{margin-bottom:25px}.xo-default-footer-navigation[data-v-a795a14e] .navigation-container ._title{margin-bottom:16px}.xo-default-footer-navigation[data-v-a795a14e] .navigation-container .links .link,.xo-default-footer-navigation[data-v-a795a14e] .navigation-container .links a{display:flex;font-size:1.1429rem;font-weight:300;line-height:1.7143rem;letter-spacing:-.28px;color:#839295;display:block;margin-bottom:16px}@media screen and (max-width:767px){.xo-default-footer-navigation[data-v-a795a14e] .desktop{display:none}}.xo-default-footer-navigation[data-v-a795a14e] .mobile{display:none}@media screen and (max-width:767px){.xo-default-footer-navigation[data-v-a795a14e] .mobile{display:block}}.xo-default-footer-navigation[data-v-a795a14e] .mobile .accordion,.xo-default-footer-navigation[data-v-a795a14e] .mobile .accordion .accordion-title{margin-bottom:10px}.xo-default-footer-navigation[data-v-a795a14e] .mobile .accordion .accordion-content .link,.xo-default-footer-navigation[data-v-a795a14e] .mobile .accordion .accordion-content a{font-size:1.1429rem;font-weight:300;line-height:1.7143rem;letter-spacing:-.28px;color:#839295;display:block;margin-bottom:10px}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1364:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/templates/Jackpot/FooterBase.vue?vue&type=template&id=a795a14e&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xo-default-footer-navigation"},[_vm._ssrNode("<div class=\"container\" data-v-a795a14e>","</div>",[_vm._ssrNode("<div class=\"row\" data-v-a795a14e>","</div>",[_vm._ssrNode("<div class=\"col flex-none\" data-v-a795a14e>","</div>",[_vm._ssrNode("<div class=\"logo\" data-v-a795a14e><img"+(_vm._ssrAttr("src",__webpack_require__(89)))+" width=\"96\" height=\"40\" alt=\"FX1\" data-v-a795a14e></div><div class=\"gap\" data-v-a795a14e></div>"),_c('XODefaultFooterGetAppDark')],2),_vm._l((_vm.desktopNavigation),function(navigation,index){return _vm._ssrNode("<div class=\"col\" data-v-a795a14e>","</div>",[_vm._ssrNode("<div class=\"navigation-container\" data-v-a795a14e>","</div>",[_vm._ssrNode("<h4 class=\"_title\" data-v-a795a14e>"+_vm._ssrEscape(_vm._s(navigation.title))+"</h4>"),_vm._ssrNode("<div class=\"links\" data-v-a795a14e>","</div>",[_vm._l((navigation.links),function(link,index){return (navigation.title != 'Socials')?_c('nuxt-link',{key:index,staticClass:"link",attrs:{"to":("" + (link.url))}},[_vm._v(_vm._s(link.label))]):_vm._e()}),_vm._ssrNode((_vm._ssrList((navigation.links),function(link,index){return (((navigation.title == 'Socials')?("<a"+(_vm._ssrAttr("href",link.url))+" target=\"_blank\" class=\"d-flex\" data-v-a795a14e>"+((link.icon)?("<img"+(_vm._ssrAttr("src",__webpack_require__(665)("./" + (link.icon) + ".svg")))+" width=\"18\" height=\"18\""+(_vm._ssrAttr("alt",link.alt))+" style=\"margin-right: 10px\" data-v-a795a14e>"):"<!---->")+"<p data-v-a795a14e>"+_vm._ssrEscape(_vm._s(link.label))+"</p></a>"):"<!---->"))})))],2)],2)])})],2),_vm._ssrNode("<div class=\"mobile\" data-v-a795a14e>","</div>",_vm._l((_vm.mobileNavigation),function(navigation,index){return _vm._ssrNode("<div class=\"accordion\" data-v-a795a14e>","</div>",[_vm._ssrNode("<div class=\"accordion-title row items-center justify-between\" data-v-a795a14e>","</div>",[_vm._ssrNode("<h4 class=\"_title\" data-v-a795a14e>"+_vm._ssrEscape(_vm._s(navigation.title))+"</h4>"),_vm._ssrNode("<div class=\"_icon\" data-v-a795a14e>","</div>",[_c('b-icon',{attrs:{"icon":navigation.isOpen ? 'chevron-up' : 'chevron-down'}})],1)],2),_c('transition',{attrs:{"name":"fade"}},[(navigation.isOpen)?_c('div',{staticClass:"accordion-content"},_vm._l((navigation.links),function(link,index){return _c('nuxt-link',{key:(index + "-l"),staticClass:"link",attrs:{"to":("" + (link.url))}},[_vm._v(_vm._s(link.label))])}),1):_vm._e()])],1)}),0)])])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/templates/Jackpot/FooterBase.vue?vue&type=template&id=a795a14e&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/templates/Jackpot/FooterBase.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var FooterBasevue_type_script_lang_js_ = ({
  name: 'XODefaultFooterNavigation',
  components: {
    XODefaultFooterGetAppDark: () => __webpack_require__.e(/* import() */ 97).then(__webpack_require__.bind(null, 1402))
  },
  data() {
    return {
      desktopNavigation: [{
        title: 'Product',
        links: [{
          label: 'Leagues & Clubs',
          url: '/explore'
        }, {
          label: 'Customer Support',
          url: '/locker-room/fx-1-support/'
        }]
      }, {
        title: 'Company',
        links: [{
          label: 'About',
          url: '/about'
        }, {
          label: 'Contact',
          url: '/contact'
        }]
      }, {
        title: 'Legal stuff',
        links: [{
          label: 'Terms',
          url: '/terms-conditions'
        }, {
          label: 'Privacy',
          url: '/privacy'
        }]
      }, {
        title: 'Socials',
        links: [{
          label: 'Telegram',
          url: 'https://t.me/fx1_sports_portal',
          icon: 'telegram-footer',
          alt: 'telegram-footer'
        }, {
          label: 'Twitter',
          url: 'https://twitter.com/FX1Sports',
          icon: 'twitter-footer',
          alt: 'twitter-footer'
        }, {
          label: 'Medium',
          url: 'https://medium.com/fx1sports',
          icon: 'medium-footer',
          alt: 'medium-footer'
        }]
      }],
      mobileNavigation: [{
        title: 'Product',
        links: [{
          label: 'Leagues & Clubs',
          url: '/explore'
        }, {
          label: 'Customer Support',
          url: '/locker-room/fx-1-support/'
        }]
      }, {
        title: 'Company',
        links: [{
          label: 'About',
          url: '/about'
        }, {
          label: 'Contact',
          url: '/contact'
        }]
      }, {
        title: 'Legal stuff',
        links: [{
          label: 'Terms',
          url: '/terms-conditions'
        }, {
          label: 'Privacy',
          url: '/privacy'
        }]
      }]
    };
  }
});
// CONCATENATED MODULE: ./components/templates/Jackpot/FooterBase.vue?vue&type=script&lang=js&
 /* harmony default export */ var Jackpot_FooterBasevue_type_script_lang_js_ = (FooterBasevue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/templates/Jackpot/FooterBase.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1156)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Jackpot_FooterBasevue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "a795a14e",
  "de9b52c2"
  
)

/* harmony default export */ var FooterBase = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 486:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/app-store-group.352ef34.svg";

/***/ }),

/***/ 487:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/app-store.39fe2f5.svg";

/***/ }),

/***/ 488:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAiIGhlaWdodD0iNiIgdmlld0JveD0iMCAwIDEwIDYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+DQo8cGF0aCBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTIuODU4ODNlLTA4IDAuODQ5MzM2TDQuOTUyMTMgNS44MDE0N0w1IDUuNzUzNkw1LjA0Nzg3IDUuODAxNDdMMTAgMC44NDkzMzZMOS4zNDU5OCAwLjE5NTMxMkw1IDQuNTQxMjlMMC42NTQwMjQgMC4xOTUzMTJMMi44NTg4M2UtMDggMC44NDkzMzZaIiBmaWxsPSJ3aGl0ZSIvPg0KPC9zdmc+DQo="

/***/ }),

/***/ 489:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/discord.f1104f0.svg";

/***/ }),

/***/ 490:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxMCAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik02LjI0NDUgMTZWOC43MTExMUg4LjczMzM5TDkuMDg4OTQgNS44NjY2N0g2LjI0NDVWNC4wODg4OUM2LjI0NDUgMy4yODg4OSA2LjUxMTE3IDIuNjY2NjcgNy42NjY3MiAyLjY2NjY3SDkuMTc3ODNWMC4wODg4ODg5QzguODIyMjggMC4wODg4ODg5IDcuOTMzMzggMCA2Ljk1NTU5IDBDNC44MjIyNiAwIDMuMzExMTUgMS4zMzMzMyAzLjMxMTE1IDMuNzMzMzNWNS44NjY2N0gwLjgyMjI2NlY4LjcxMTExSDMuMzExMTVWMTZINi4yNDQ1WiIgZmlsbD0id2hpdGUiLz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 491:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/google-play-group.e80e818.svg";

/***/ }),

/***/ 492:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/instagram.52a516e.svg";

/***/ }),

/***/ 493:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0xNiAxNS42NDQxVjkuNzI4MDZDMTYgNi41NTgwNiAxNC4zMDggNS4wODMwNiAxMi4wNTIgNS4wODMwNkMxMC4yMzE1IDUuMDgzMDYgOS40MTU1IDYuMDg0NTYgOC45NjEgNi43ODc1NlY1LjMyNTU2SDUuNTMxQzUuNTc2NSA2LjI5NDA2IDUuNTMxIDE1LjY0NDEgNS41MzEgMTUuNjQ0MUg4Ljk2MVY5Ljg4MTU2QzguOTYxIDkuNTc0MDYgOC45ODMgOS4yNjU1NiA5LjA3NCA5LjA0NTU2QzkuMzIxNSA4LjQyOTA2IDkuODg2IDcuNzkxMDYgMTAuODMzIDcuNzkxMDZDMTIuMDc0NSA3Ljc5MTA2IDEyLjU3MDUgOC43MzcwNiAxMi41NzA1IDEwLjEyNDFWMTUuNjQ0NkgxNlYxNS42NDQxWk0xLjkxNzUgMy45MTcwNkMzLjExMyAzLjkxNzA2IDMuODU4NSAzLjEyNDA2IDMuODU4NSAyLjEzMzU2QzMuODM2NSAxLjEyMTU2IDMuMTEzNSAwLjM1MTU2MiAxLjk0MDUgMC4zNTE1NjJDMC43Njc1IDAuMzUxNTYyIDAgMS4xMjEwNiAwIDIuMTMzNTZDMCAzLjEyNDA2IDAuNzQ0NSAzLjkxNzA2IDEuODk2IDMuOTE3MDZIMS45MTc1Wk0zLjYzMjUgMTUuNjQ0MVY1LjMyNTU2SDAuMjAzVjE1LjY0NDFIMy42MzI1WiIgZmlsbD0id2hpdGUiLz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 494:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzYiIGhlaWdodD0iMjIiIHZpZXdCb3g9IjAgMCAzNiAyMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0yMC4zMDYyIDExQzIwLjMwNjIgMTYuNTkxMyAxNS43NjEzIDIxLjEyNSAxMC4xNTIgMjEuMTI1QzguODIwNTkgMjEuMTI2OCA3LjUwMTg3IDIwLjg2NjMgNi4yNzExMyAyMC4zNTg0QzUuMDQwNCAxOS44NTA2IDMuOTIxNzQgMTkuMTA1MyAyLjk3OTA0IDE4LjE2NTFDMi4wMzYzNCAxNy4yMjQ5IDEuMjg4MDYgMTYuMTA4MiAwLjc3NjkxMSAxNC44Nzg4QzAuMjY1NzY2IDEzLjY0OTQgMC4wMDE3NzE2NyAxMi4zMzE0IDAgMTFDMCA1LjQwNjUxIDQuNTQ1IDAuODc1MDEyIDEwLjE1MiAwLjg3NTAxMkMxMS40ODM2IDAuODcyOTQyIDEyLjgwMjYgMS4xMzMyMSAxNC4wMzM2IDEuNjQwOTRDMTUuMjY0NiAyLjE0ODY4IDE2LjM4MzUgMi44OTM5NCAxNy4zMjY0IDMuODM0MTdDMTguMjY5NCA0Ljc3NDM5IDE5LjAxNzggNS44OTExNSAxOS41MjkxIDcuMTIwNjhDMjAuMDQwNCA4LjM1MDIxIDIwLjMwNDUgOS42Njg0MiAyMC4zMDYyIDExWk0zMS40NDM4IDExQzMxLjQ0MzggMTYuMjY1IDI5LjE3MTIgMjAuNTMxIDI2LjM2NzggMjAuNTMxQzIzLjU2NDIgMjAuNTMxIDIxLjI5MTcgMTYuMjYyOCAyMS4yOTE3IDExQzIxLjI5MTcgNS43MzUwMSAyMy41NjQyIDEuNDY5MDEgMjYuMzY3OCAxLjQ2OTAxQzI5LjE3MTIgMS40NjkwMSAzMS40NDM4IDUuNzM3MjYgMzEuNDQzOCAxMVpNMzYgMTFDMzYgMTUuNzE2IDM1LjIwMTMgMTkuNTM4OCAzNC4yMTM1IDE5LjUzODhDMzMuMjI4IDE5LjUzODggMzIuNDI5MiAxNS43MTM4IDMyLjQyOTIgMTFDMzIuNDI5MiA2LjI4NDAxIDMzLjIyOCAyLjQ2MTI2IDM0LjIxNTcgMi40NjEyNkMzNS4yMDEyIDIuNDYxMjYgMzYgNi4yODQwMSAzNiAxMVoiIGZpbGw9IndoaXRlIi8+DQo8L3N2Zz4NCg=="

/***/ }),

/***/ 495:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/playstore.30d85aa.svg";

/***/ }),

/***/ 496:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMjciIHZpZXdCb3g9IjAgMCAzMiAyNyIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0yOS4wNjUgMC40ODE3NjNDMjkuMDY1IDAuNDgxNzYzIDMxLjk3ODcgLTAuNjU0NDg3IDMxLjczNSAyLjEwNDc2QzMxLjY1NDcgMy4yNDEwMSAzMC45MjY1IDcuMjE4MjYgMzAuMzU5NSAxMS41MTk1TDI4LjQxNyAyNC4yNjJDMjguNDE3IDI0LjI2MiAyOC4yNTUgMjYuMTI4OCAyNi43OTc3IDI2LjQ1MzVDMjUuMzQxMiAyNi43Nzc1IDIzLjE1NTcgMjUuMzE3MyAyMi43NTA3IDI0Ljk5MjVDMjIuNDI2NyAyNC43NDg4IDE2LjY4MDIgMjEuMDk2MyAxNC42NTY3IDE5LjMxMTNDMTQuMDg5NyAxOC44MjM4IDEzLjQ0MTcgMTcuODUwMyAxNC43Mzc3IDE2LjcxNEwyMy4yMzYgOC41OTc1MUMyNC4yMDcyIDcuNjI0MDEgMjUuMTc4NSA1LjM1MTUxIDIxLjEzMTUgOC4xMTA3Nkw5Ljc5OSAxNS44MjA4QzkuNzk5IDE1LjgyMDggOC41MDM3NSAxNi42MzMgNi4wNzU5OSAxNS45MDI1TDAuODEzOTk0IDE0LjI3ODhDMC44MTM5OTQgMTQuMjc4OCAtMS4xMjg1MSAxMy4wNjE1IDIuMTkwMjQgMTEuODQ0M0MxMC4yODUgOC4wMjk3NiAyMC4yNDEyIDQuMTM0MjYgMjkuMDYzNSAwLjQ4MTc2M0gyOS4wNjVaIiBmaWxsPSJ3aGl0ZSIvPg0KPC9zdmc+DQo="

/***/ }),

/***/ 497:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNMTMuMTg1NSAyLjk1MzA2QzEzLjkxMDggMi42NDc2OCAxNC42ODgzIDMuMjYwOTcgMTQuNTYwMiA0LjAzNzQzTDEzLjA0NzYgMTMuMjA4NkMxMi45MDE4IDE0LjA5MjggMTEuOTMwNiAxNC42MDAyIDExLjExOTMgMTQuMTU5NkMxMC40NDA0IDEzLjc5MDggOS40MzMyNSAxMy4yMjMzIDguNTI1NTEgMTIuNjMwMkM4LjA3MjI1IDEyLjMzNCA2LjY4NDMxIDExLjM4NDIgNi44NTQ5MSAxMC43MDgyQzcuMDAwNzggMTAuMTMwMSA5LjMzNDA1IDcuOTU4MTcgMTAuNjY3NCA2LjY2NjVDMTEuMTkxMSA2LjE1OTEyIDEwLjk1MjYgNS44NjYwMSAxMC4zMzQgNi4zMzMxN0M4Ljc5OTY1IDcuNDkyMDQgNi4zMzYxOSA5LjI1Mzk3IDUuNTIxNTUgOS43NDk4NEM0LjgwMjggMTAuMTg3MyA0LjQyNzUyIDEwLjI2MiAzLjk3OTg5IDEwLjE4NzNDMy4xNjI0NyAxMC4wNTExIDIuNDA0NjIgOS44NDAxNyAxLjc4NTkgOS41ODM3QzAuOTQ5NjU1IDkuMjM3MDQgMC45OTAzODggOC4wODc4NCAxLjc4NTMzIDcuNzUzMTdMMTMuMTg1NSAyLjk1MzA2WiIgZmlsbD0id2hpdGUiLz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 498:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzMiIGhlaWdodD0iMjYiIHZpZXdCb3g9IjAgMCAzMyAyNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0zMi4xOTAxIDNDMzEuMDM1MSAzLjUyNSAyOS43OTAxIDMuODcgMjguNTAwMSA0LjAzNUMyOS44MjAxIDMuMjQgMzAuODQwMSAxLjk4IDMxLjMyMDEgMC40NjVDMzAuMDc1MSAxLjIxNSAyOC42OTUxIDEuNzQgMjcuMjQwMSAyLjA0QzI2LjA1NTEgMC43NSAyNC4zOTAxIDAgMjIuNTAwMSAwQzE4Ljk3NTEgMCAxNi4wOTUxIDIuODggMTYuMDk1MSA2LjQzNUMxNi4wOTUxIDYuOTQ1IDE2LjE1NTEgNy40NCAxNi4yNjAxIDcuOTA1QzEwLjkyMDEgNy42MzUgNi4xNjUwNiA1LjA3IDMuMDAwMDYgMS4xODVDMi40NDUwNiAyLjEzIDIuMTMwMDYgMy4yNCAyLjEzMDA2IDQuNDFDMi4xMzAwNiA2LjY0NSAzLjI1NTA2IDguNjI1IDQuOTk1MDYgOS43NUMzLjkzMDA2IDkuNzUgMi45NDAwNiA5LjQ1IDIuMDcwMDYgOVY5LjA0NUMyLjA3MDA2IDEyLjE2NSA0LjI5MDA2IDE0Ljc3NSA3LjIzMDA2IDE1LjM2QzYuMjg2MTUgMTUuNjE4MyA1LjI5NTIgMTUuNjU0MyA0LjMzNTA2IDE1LjQ2NUM0Ljc0MjQ3IDE2Ljc0MzcgNS41NDAzNiAxNy44NjI2IDYuNjE2NTggMTguNjY0NEM3LjY5MjggMTkuNDY2MiA4Ljk5MzIzIDE5LjkxMDUgMTAuMzM1MSAxOS45MzVDOC4wNjA1IDIxLjczNTcgNS4yNDEwNSAyMi43MDkgMi4zNDAwNiAyMi42OTVDMS44MzAwNiAyMi42OTUgMS4zMjAwNiAyMi42NjUgMC44MTAwNTkgMjIuNjA1QzMuNjYwMDYgMjQuNDM1IDcuMDUwMDYgMjUuNSAxMC42ODAxIDI1LjVDMjIuNTAwMSAyNS41IDI4Ljk5NTEgMTUuNjkgMjguOTk1MSA3LjE4NUMyOC45OTUxIDYuOSAyOC45OTUxIDYuNjMgMjguOTgwMSA2LjM0NUMzMC4yNDAxIDUuNDQ1IDMxLjMyMDEgNC4zMDUgMzIuMTkwMSAzWiIgZmlsbD0id2hpdGUiLz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 499:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/twitter.384e9c6.svg";

/***/ }),

/***/ 665:
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./app-store-group.svg": 486,
	"./app-store.svg": 487,
	"./chevron-down.svg": 488,
	"./discord.svg": 489,
	"./facebook.svg": 490,
	"./google-play-group.svg": 491,
	"./instagram.svg": 492,
	"./linkedin.svg": 493,
	"./medium-footer.svg": 494,
	"./playstore.svg": 495,
	"./telegram-footer.svg": 496,
	"./telegram.svg": 497,
	"./twitter-footer.svg": 498,
	"./twitter.svg": 499
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 665;

/***/ }),

/***/ 921:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1157);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("d64045a2", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=77.js.map
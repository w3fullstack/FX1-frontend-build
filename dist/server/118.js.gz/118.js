exports.ids = [118];
exports.modules = {

/***/ 1067:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Avatar_vue_vue_type_style_index_0_id_5f1f1eba_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(877);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Avatar_vue_vue_type_style_index_0_id_5f1f1eba_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Avatar_vue_vue_type_style_index_0_id_5f1f1eba_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Avatar_vue_vue_type_style_index_0_id_5f1f1eba_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Avatar_vue_vue_type_style_index_0_id_5f1f1eba_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1068:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xa-forms-avatar[data-v-5f1f1eba] .actions{width:100%;margin-top:10px}.xa-forms-avatar[data-v-5f1f1eba] .actions ._delete,.xa-forms-avatar[data-v-5f1f1eba] .actions .accept{margin:0 10px;cursor:pointer}.xa-forms-avatar[data-v-5f1f1eba] .actions .accept{color:#219653}.xa-forms-avatar[data-v-5f1f1eba] .actions ._delete{color:#f14668}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1428:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/atoms/Forms/Avatar.vue?vue&type=template&id=5f1f1eba&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xa-forms-avatar row justify-center"},[_c('croppa',{attrs:{"width":_vm.size,"height":_vm.size,"placeholder":_vm.placeholder,"placeholder-font-size":_vm.placeholderFontSize,"zoom-speed":5,"show-remove-button":false,"image-border-radius":_vm.imageBorderRadius,"canvas-color":"#f8f8f8","show-loading":"","disable-rotation":"","prevent-white-space":""},on:{"file-choose":function($event){return _vm.fnShowAvatarActions()}},model:{value:(_vm.avatar),callback:function ($$v) {_vm.avatar=$$v},expression:"avatar"}}),(_vm.showActions)?_vm._ssrNode("<div class=\"actions row justify-center\" data-v-5f1f1eba>","</div>",[_vm._ssrNode("<div class=\"accept\" data-v-5f1f1eba>","</div>",[_c('b-icon',{attrs:{"icon":"check"}})],1),_vm._ssrNode("<div class=\"_delete\" data-v-5f1f1eba>","</div>",[_c('b-icon',{attrs:{"icon":"close"}})],1)]):_vm._e()],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/atoms/Forms/Avatar.vue?vue&type=template&id=5f1f1eba&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/atoms/Forms/Avatar.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Avatarvue_type_script_lang_js_ = ({
  name: 'XAFormsAvatar',
  props: {
    size: {
      type: Number,
      default: 200
    },
    placeholder: {
      type: String,
      default: 'Choose an avatar'
    },
    rounded: {
      type: Boolean,
      default: false
    },
    circle: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      avatar: null
    };
  },
  computed: {
    placeholderFontSize() {
      return this.size * 0.09;
    },
    imageBorderRadius() {
      let imageBorderRadius;
      if (this.rounded) imageBorderRadius = 1000;
      if (this.circle) imageBorderRadius = 10;
      return imageBorderRadius;
    },
    showActions: {
      get() {
        var _this$avatar;
        return ((_this$avatar = this.avatar) === null || _this$avatar === void 0 ? void 0 : _this$avatar.hasImage()) || false;
      },
      set(value) {
        return value;
      }
    }
  },
  methods: {
    fnShowAvatarActions() {
      this.showActions = true;
    },
    fnRemoveAvatar() {
      this.avatar.remove();
    },
    fnAcceptAvatar() {
      this.avatar.remove();
      // const url = this.avatar.generateDataUrl()
    }
  }
});
// CONCATENATED MODULE: ./components/atoms/Forms/Avatar.vue?vue&type=script&lang=js&
 /* harmony default export */ var Forms_Avatarvue_type_script_lang_js_ = (Avatarvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/atoms/Forms/Avatar.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1067)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Forms_Avatarvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "5f1f1eba",
  "63fe50ec"
  
)

/* harmony default export */ var Avatar = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 877:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1068);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("50b0c4b3", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=118.js.map
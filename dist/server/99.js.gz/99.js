exports.ids = [99];
exports.modules = {

/***/ 1133:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_EditTo_vue_vue_type_style_index_0_id_1fda0c87_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(910);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_EditTo_vue_vue_type_style_index_0_id_1fda0c87_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_EditTo_vue_vue_type_style_index_0_id_1fda0c87_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_EditTo_vue_vue_type_style_index_0_id_1fda0c87_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_EditTo_vue_vue_type_style_index_0_id_1fda0c87_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1134:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xa-channels-edit-to[data-v-1fda0c87]{margin-bottom:20px;width:100%}.xa-channels-edit-to[data-v-1fda0c87] .details{border-left:2px solid #fff;margin-left:30px;padding-left:10px;padding-right:30px}.xa-channels-edit-to[data-v-1fda0c87] .details .media-container{width:38px;height:38px;border-radius:4px;margin-right:10px}.xa-channels-edit-to[data-v-1fda0c87] .details .media-container img{width:100%;height:100%;-o-object-fit:cover;object-fit:cover;border-radius:4px}.xa-channels-edit-to[data-v-1fda0c87] .details .name{font-size:1.0714rem;line-height:18px;margin-bottom:4px}.xa-channels-edit-to[data-v-1fda0c87] .details ._message{font-size:12px;font-weight:300;line-height:14px;letter-spacing:-.18px;color:hsla(0,0%,100%,.5);white-space:pre-wrap;word-break:break-word;display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis}.xa-channels-edit-to[data-v-1fda0c87] .details ._message.photo{color:#fff;font-size:1rem}.xa-channels-edit-to[data-v-1fda0c87] .actions .icon{opacity:.5;cursor:pointer}.xa-channels-edit-to[data-v-1fda0c87].has-media .details{padding-left:10px}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1400:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/atoms/Channels/EditTo.vue?vue&type=template&id=1fda0c87&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xa-channels-edit-to row items-center justify-between",class:_vm.media.length && 'has-media'},[_vm._ssrNode("<div class=\"_icon row\" data-v-1fda0c87><img"+(_vm._ssrAttr("src",__webpack_require__(619)))+" data-v-1fda0c87></div><div class=\"details col row\" data-v-1fda0c87>"+((_vm.media.length)?("<div class=\"media-container\" data-v-1fda0c87>"+((_vm.photoURL)?("<img"+(_vm._ssrAttr("src",_vm.photoURL))+" data-v-1fda0c87>"):"<!---->")+"</div>"):"<!---->")+"<div class=\"col\" data-v-1fda0c87><div class=\"name\" data-v-1fda0c87>Edit</div>"+((_vm.message)?("<div class=\"_message\" data-v-1fda0c87>"+(_vm._s(_vm.message))+"</div>"):"<!---->")+((_vm.photoURL && !_vm.message)?("<div class=\"_message photo\" data-v-1fda0c87>Photo</div>"):"<!---->")+"</div></div>"),_vm._ssrNode("<div class=\"actions\" data-v-1fda0c87>","</div>",[_vm._ssrNode("<div class=\"close\" data-v-1fda0c87>","</div>",[_c('b-icon',{attrs:{"icon":"close"}})],1)])],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/atoms/Channels/EditTo.vue?vue&type=template&id=1fda0c87&scoped=true&lang=pug&

// EXTERNAL MODULE: external "vuex"
var external_vuex_ = __webpack_require__(4);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/atoms/Channels/EditTo.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var EditTovue_type_script_lang_js_ = ({
  name: 'XAChannelsReplyTo',
  data() {
    return {
      imgURL: null
    };
  },
  computed: {
    ...Object(external_vuex_["mapGetters"])({
      getChatActive: 'chats/getChatActive'
    }),
    chatID() {
      var _this$getChatActive;
      return ((_this$getChatActive = this.getChatActive) === null || _this$getChatActive === void 0 ? void 0 : _this$getChatActive.chatID) || null;
    },
    message() {
      var _this$getChatActive2;
      return ((_this$getChatActive2 = this.getChatActive) === null || _this$getChatActive2 === void 0 ? void 0 : _this$getChatActive2.text) || null;
    },
    media() {
      var _this$getChatActive3;
      return ((_this$getChatActive3 = this.getChatActive) === null || _this$getChatActive3 === void 0 ? void 0 : _this$getChatActive3.Media) || [];
    },
    localMedia() {
      var _this$getChatActive4;
      return ((_this$getChatActive4 = this.getChatActive) === null || _this$getChatActive4 === void 0 ? void 0 : _this$getChatActive4.localMedia) || null;
    },
    photoURL() {
      var _this$media$;
      if (this.localMedia) {
        this.fnResizeImage();
      }
      return this.imgURL || ((_this$media$ = this.media[0]) === null || _this$media$ === void 0 ? void 0 : _this$media$.PhotoURL) || null;
    }
  },
  mounted() {
    this.$root.$on('evtRtCancelEdit', () => {
      this.fnCancelEdit();
    });
    this.$root.$on('evtRtHideEdit', () => {
      this.fnHideEdit();
    });
  },
  methods: {
    ...Object(external_vuex_["mapActions"])({
      setChatActive: 'chats/setChatActive',
      setChatShowEdit: 'chats/setChatShowEdit'
    }),
    fnCancelEdit() {
      this.setChatActive({});
      this.setChatShowEdit(false);
    },
    fnHideEdit() {
      this.setChatShowEdit(false);
    },
    async fnResizeImage() {
      var _this$localMedia$;
      if (!this.localMedia.length) return;
      const file = (_this$localMedia$ = this.localMedia[0]) === null || _this$localMedia$ === void 0 ? void 0 : _this$localMedia$.file;
      const reader = new FileReader();

      // Wait for the data url to be loaded from the file
      const dataURL = await new Promise(resolve => {
        reader.onload = e => resolve(e.target.result);
        reader.readAsDataURL(file);
      });

      // Wait for the image to be loaded
      const img = new Image();
      await new Promise(resolve => {
        img.onload = resolve;
        img.src = dataURL;
      });
      const imgNaturalWidth = img.naturalWidth;
      const imgNaturalHeight = img.naturalHeight;
      if ((imgNaturalWidth || imgNaturalHeight) <= 50) {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = imgNaturalWidth;
        canvas.height = imgNaturalHeight;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        this.imgURL = canvas.toDataURL('image/png', 1);
        return;
      }

      // Resize the image with a canvas
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const [maxWidth, maxHeight] = [50, 50];
      const [imgWidth, imgHeight] = [imgNaturalWidth, imgNaturalHeight];
      const ratio = Math.min(maxWidth / imgWidth, maxHeight / imgHeight);
      canvas.width = imgWidth * ratio;
      canvas.height = imgHeight * ratio;
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      this.imgURL = canvas.toDataURL('image/png', 1);
    }
  }
});
// CONCATENATED MODULE: ./components/atoms/Channels/EditTo.vue?vue&type=script&lang=js&
 /* harmony default export */ var Channels_EditTovue_type_script_lang_js_ = (EditTovue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/atoms/Channels/EditTo.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1133)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Channels_EditTovue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "1fda0c87",
  "4a2b9c3d"
  
)

/* harmony default export */ var EditTo = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 619:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTkiIGhlaWdodD0iMTkiIHZpZXdCb3g9IjAgMCAxOSAxOSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNMTguMjEgMy42MzA1NUMxOC42IDQuMDIwNTUgMTguNiA0LjY1MDU1IDE4LjIxIDUuMDQwNTVMMTYuMzggNi44NzA1NUwxMi42MyAzLjEyMDU1TDE0LjQ2IDEuMjkwNTVDMTQuODUgMC45MDA1NDcgMTUuNDggMC45MDA1NDcgMTUuODcgMS4yOTA1NUwxOC4yMSAzLjYzMDU1Wk0wLjUgMTkuMDAwNVYxNS4yNTA1TDExLjU2IDQuMTkwNTVMMTUuMzEgNy45NDA1NUw0LjI1IDE5LjAwMDVIMC41WiIgZmlsbD0id2hpdGUiLz4NCjwvc3ZnPg0K"

/***/ }),

/***/ 910:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1134);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("3cf6714a", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=99.js.map
exports.ids = [5];
exports.modules = {

/***/ 1204:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatLightbox_vue_vue_type_style_index_0_id_d838b874_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(945);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatLightbox_vue_vue_type_style_index_0_id_d838b874_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatLightbox_vue_vue_type_style_index_0_id_d838b874_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatLightbox_vue_vue_type_style_index_0_id_d838b874_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatLightbox_vue_vue_type_style_index_0_id_d838b874_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1205:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xm-channels-chat-lightbox[data-v-d838b874]{position:fixed;top:0;left:0;width:100%;height:100%;z-index:999}.xm-channels-chat-lightbox[data-v-d838b874] .back-drop{background-color:rgba(0,0,0,.8);position:absolute;top:0;left:0;width:100%;height:100%;z-index:0}.xm-channels-chat-lightbox[data-v-d838b874] .close{position:absolute;top:30px;right:30px;z-index:2;cursor:pointer}.xm-channels-chat-lightbox[data-v-d838b874] .media-slider{width:100%;height:100%}.xm-channels-chat-lightbox[data-v-d838b874] .media-slider .hooper .hooper-list .hooper-track .hooper-slide .media-container{height:100%}.xm-channels-chat-lightbox[data-v-d838b874] .slider-navigation .btn-navigation{position:absolute;top:0;bottom:0;z-index:1;cursor:pointer}.xm-channels-chat-lightbox[data-v-d838b874] .slider-navigation .btn-navigation.btn-prev{left:20px}.xm-channels-chat-lightbox[data-v-d838b874] .slider-navigation .btn-navigation.btn-next{right:20px}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1383:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Channels/ChatLightbox.vue?vue&type=template&id=d838b874&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return (_vm.show)?_c('div',{staticClass:"xm-channels-chat-lightbox"},[_vm._ssrNode("<div class=\"back-drop\" data-v-d838b874></div>"),_vm._ssrNode("<div class=\"close\" data-v-d838b874>","</div>",[_c('b-icon',{attrs:{"icon":"close","size":"is-medium"}})],1),_vm._ssrNode("<div class=\"media-slider\" data-v-d838b874>","</div>",[_c('hooper',{ref:"mediaSlider",staticStyle:{"height":"100%"},attrs:{"settings":_vm.hooperSettings,"initial-slide":_vm.initialSlide}},_vm._l((_vm.getMediaLightbox),function(media,index){return _c('slide',{key:index},[_c('div',{staticClass:"media-container row items-center justify-center",on:{"click":function($event){if($event.target !== $event.currentTarget){ return null; }$event.preventDefault();return _vm.fnHideLightbox()}}},[_c('nuxt-img',{attrs:{"src":media.src}})],1)])}),1)],1),(_vm.getMediaLightbox.length > 1)?_vm._ssrNode("<div class=\"slider-navigation\" data-v-d838b874>","</div>",[_vm._ssrNode("<div class=\"btn-navigation btn-prev row items-center\" data-v-d838b874>","</div>",[_c('b-icon',{attrs:{"icon":"chevron-left","size":"is-large"}})],1),_vm._ssrNode("<div class=\"btn-navigation btn-next row items-center\" data-v-d838b874>","</div>",[_c('b-icon',{attrs:{"icon":"chevron-right","size":"is-large"}})],1)]):_vm._e()],2):_vm._e()}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Channels/ChatLightbox.vue?vue&type=template&id=d838b874&scoped=true&lang=pug&

// EXTERNAL MODULE: external "vuex"
var external_vuex_ = __webpack_require__(4);

// EXTERNAL MODULE: external "hooper"
var external_hooper_ = __webpack_require__(220);

// EXTERNAL MODULE: ./node_modules/hooper/dist/hooper.css
var hooper = __webpack_require__(485);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Channels/ChatLightbox.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ var ChatLightboxvue_type_script_lang_js_ = ({
  name: 'XMChannelsChatLightbox',
  components: {
    Hooper: external_hooper_["Hooper"],
    Slide: external_hooper_["Slide"]
  },
  data() {
    return {
      show: false,
      initialSlide: 0
    };
  },
  computed: {
    ...Object(external_vuex_["mapGetters"])({
      getMediaLightbox: 'media/getMediaLightbox'
    }),
    hooperSettings() {
      const hooperSettings = {
        itemsToShow: 1,
        itemsToSlide: 1,
        wheelControl: false,
        mouseDrag: false,
        infiniteScroll: true
      };
      return hooperSettings;
    }
  },
  beforeMount() {
    window.addEventListener('keyup', this.onKeyUp);
  },
  mounted() {
    this.$root.$on('evtRtShowLightbox', value => {
      this.show = value === null || value === void 0 ? void 0 : value.show;
      this.initialSlide = value === null || value === void 0 ? void 0 : value.initialSlide;
    });
  },
  beforeDestroy() {
    window.removeEventListener('keyup', this.onKeyUp);
  },
  methods: {
    ...Object(external_vuex_["mapActions"])({
      setMediaLightbox: 'media/setMediaLightbox'
    }),
    fnPrevSlide() {
      this.$refs.mediaSlider.slidePrev();
    },
    fnNextSlide() {
      this.$refs.mediaSlider.slideNext();
    },
    async fnHideLightbox() {
      await this.setMediaLightbox([]);
      this.show = false;
    },
    onKeyUp(e) {
      if (e.key === 'Escape') {
        this.fnHideLightbox();
      }
    }
  }
});
// CONCATENATED MODULE: ./components/molecules/Channels/ChatLightbox.vue?vue&type=script&lang=js&
 /* harmony default export */ var Channels_ChatLightboxvue_type_script_lang_js_ = (ChatLightboxvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/Channels/ChatLightbox.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1204)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Channels_ChatLightboxvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "d838b874",
  "8e381da0"
  
)

/* harmony default export */ var ChatLightbox = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 485:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(556);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
__webpack_require__(7).default("1fbb21b2", content, true)

/***/ }),

/***/ 556:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".hooper-slide{flex-shrink:0;height:100%;margin:0;padding:0;list-style:none}.hooper-progress{position:absolute;top:0;right:0;left:0;height:4px;background-color:#efefef}.hooper-progress-inner{height:100%;background-color:#4285f4;transition:.3s}.hooper-pagination{position:absolute;bottom:0;right:50%;transform:translateX(50%);display:flex;padding:5px 10px}.hooper-indicators{display:flex;list-style:none;margin:0;padding:0}.hooper-indicator.is-active,.hooper-indicator:hover{background-color:#4285f4}.hooper-indicator{margin:0 2px;width:12px;height:4px;border-radius:4px;border:none;padding:0;background-color:#fff;cursor:pointer}.hooper-pagination.is-vertical{bottom:auto;right:0;top:50%;transform:translateY(-50%)}.hooper-pagination.is-vertical .hooper-indicators{flex-direction:column}.hooper-pagination.is-vertical .hooper-indicator{width:6px}.hooper-next,.hooper-prev{background-color:transparent;border:none;padding:1em;position:absolute;top:50%;transform:translateY(-50%);cursor:pointer}.hooper-next.is-disabled,.hooper-prev.is-disabled{opacity:.3;cursor:not-allowed}.hooper-next{right:0}.hooper-prev{left:0}.hooper-navigation.is-vertical .hooper-next{top:auto;bottom:0;transform:none}.hooper-navigation.is-vertical .hooper-prev{top:0;bottom:auto;right:0;left:auto;transform:none}.hooper-navigation.is-rtl .hooper-prev{left:auto;right:0}.hooper-navigation.is-rtl .hooper-next{right:auto;left:0}.hooper{position:relative;width:100%;height:200px}.hooper,.hooper *{box-sizing:border-box}.hooper-list{overflow:hidden;width:100%;height:100%}.hooper-track{display:flex;box-sizing:border-box;width:100%;height:100%;padding:0;margin:0}.hooper.is-vertical .hooper-track{flex-direction:column;height:200px}.hooper.is-rtl{direction:rtl}.hooper-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 945:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1205);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("4c92deae", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=5.js.map
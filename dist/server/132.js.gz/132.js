exports.ids = [132];
exports.modules = {

/***/ 1248:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WhitepaperSection_vue_vue_type_style_index_0_id_60731849_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(967);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WhitepaperSection_vue_vue_type_style_index_0_id_60731849_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WhitepaperSection_vue_vue_type_style_index_0_id_60731849_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WhitepaperSection_vue_vue_type_style_index_0_id_60731849_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_WhitepaperSection_vue_vue_type_style_index_0_id_60731849_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1249:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".token-whitepaper-section[data-v-60731849]{width:auto;position:relative;overflow:hidden;z-index:2;padding:100px 0 150px}.token-whitepaper-section[data-v-60731849] .actions{margin:20px 12px!important}.token-whitepaper-section[data-v-60731849] .button{margin-top:25px;width:250px!important;height:60px;border-radius:8px}.token-whitepaper-section[data-v-60731849] .top-margin-a{margin-top:80px}.token-whitepaper-section[data-v-60731849] .top-margin-b{margin-top:40px}.token-whitepaper-section[data-v-60731849] .top-margin-c{margin-top:20px}.token-whitepaper-section[data-v-60731849] .actions{margin:12px}.token-whitepaper-section[data-v-60731849] .purple-text{color:#886bf2}.token-whitepaper-section[data-v-60731849] .main-box{position:relative;box-shadow:0 25px 77px -10px hsla(0,0%,100%,.2);border:1px solid #385960;border-radius:8px;background-color:#0c353e;margin:12px;height:500px;padding:25px 0}.token-whitepaper-section[data-v-60731849] .main-box .section-left img{width:auto;height:450px}.token-whitepaper-section[data-v-60731849] .main-box .section-right{margin-top:5%;width:72%!important}@media screen and (max-width:1650px){.token-whitepaper-section[data-v-60731849] .main-box .section-right{margin-top:6%}}@media screen and (max-width:1580px){.token-whitepaper-section[data-v-60731849] .main-box .section-right{margin-top:7%}}@media screen and (max-width:1530px){.token-whitepaper-section[data-v-60731849] .main-box .section-right{width:82%!important}}@media screen and (max-width:1450px){.token-whitepaper-section[data-v-60731849] .main-box .section-right{margin-top:8.5%}}.token-whitepaper-section[data-v-60731849] .main-box .text-yellow{color:#ffaf23!important}@media screen and (max-width:1021px){.token-whitepaper-section[data-v-60731849] .main-box{margin:0}.token-whitepaper-section[data-v-60731849] .section-right{margin-left:7%}}@media screen and (max-width:500px){.token-whitepaper-section[data-v-60731849]{padding:50px 0}.token-whitepaper-section[data-v-60731849] .top-margin-b{margin-top:5px}.token-whitepaper-section[data-v-60731849] .actions{margin:20px 0!important}.token-whitepaper-section[data-v-60731849] .main-box{margin:0;height:auto;box-shadow:0 5px 15px -1px hsla(0,0%,100%,.2)}.token-whitepaper-section[data-v-60731849] .main-box .section-right{margin-top:0;padding:20px}.token-whitepaper-section[data-v-60731849] .main-box .section-left img{padding:20px 20px 0;width:100%;height:auto}.token-whitepaper-section[data-v-60731849] .main-box .section-right{width:100%!important}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1414:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/WhitepaperSection.vue?vue&type=template&id=60731849&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"token-whitepaper-section row"},[_vm._ssrNode("<div class=\"container token-container-howToBuy text-center\" data-v-60731849>","</div>",[_c('EmbedVideo',{attrs:{"isWhitepaper":true}}),_vm._ssrNode("<div class=\"row\" data-v-60731849>","</div>",[_vm._ssrNode("<div class=\"col actions\" data-v-60731849>","</div>",[_c('b-button',{attrs:{"type":"is-primary"},on:{"click":function($event){$event.preventDefault();return _vm.downloadFile()}}},[_vm._v("Download Whitepaper")])],1)])],1)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Token/WhitepaperSection.vue?vue&type=template&id=60731849&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/WhitepaperSection.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var WhitepaperSectionvue_type_script_lang_js_ = ({
  name: 'WhitepaperSection',
  components: {
    EmbedVideo: () => __webpack_require__.e(/* import() */ 23).then(__webpack_require__.bind(null, 1437))
  },
  methods: {
    downloadFile() {
      const link = document.createElement('a');
      link.href = '/FX1_Whitepaper__V1.0.pdf';
      link.download = '';
      link.target = '_blank';
      link.click();
    },
    showAlertMessage() {
      this.$toast.success('$FX1 available to purchase mid to late April', {
        duration: 5000,
        position: 'bottom-left',
        className: 'fx1-success'
      });
    }
  }
});
// CONCATENATED MODULE: ./components/molecules/Token/WhitepaperSection.vue?vue&type=script&lang=js&
 /* harmony default export */ var Token_WhitepaperSectionvue_type_script_lang_js_ = (WhitepaperSectionvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/Token/WhitepaperSection.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1248)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Token_WhitepaperSectionvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "60731849",
  "16925f14"
  
)

/* harmony default export */ var WhitepaperSection = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 967:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1249);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("9c7eeada", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=132.js.map
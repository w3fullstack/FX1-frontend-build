exports.ids = [103];
exports.modules = {

/***/ 1180:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_style_index_0_id_0aed8c13_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(933);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_style_index_0_id_0aed8c13_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_style_index_0_id_0aed8c13_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_style_index_0_id_0aed8c13_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_style_index_0_id_0aed8c13_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1181:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(24);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(616);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".token-banner[data-v-0aed8c13]{width:auto;position:relative;overflow:hidden;padding:165px 0 130px}.token-banner[data-v-0aed8c13] .token-h1{-webkit-text-stroke:0;font-weight:500!important;text-shadow:none!important}.token-banner[data-v-0aed8c13] .overlay{top:0;position:absolute;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");background-position:50%;background-repeat:no-repeat;width:100%;height:100%;overflow:hidden;z-index:0;zoom:1.1}.token-banner[data-v-0aed8c13] .content-middle{position:relative;z-index:1;width:100%;margin:auto;max-width:962px}.token-banner[data-v-0aed8c13] .content-middle .actions{margin:75px 0 25px}.token-banner[data-v-0aed8c13] .content-middle .actions .button{width:235px;height:82px;text-transform:uppercase;margin-left:10px;margin-right:10px}.token-banner[data-v-0aed8c13] .content-middle .actions .button:last-child{background-color:#0c353e}.token-banner[data-v-0aed8c13] .content-middle h2{font-size:1.5714rem;line-height:2.4286rem;letter-spacing:-.66px;max-width:700px;margin:auto}.token-banner[data-v-0aed8c13] .content-middle .launch-text span{color:hsla(0,0%,100%,.8)}@media screen and (max-width:1215px){.token-banner[data-v-0aed8c13]{padding-bottom:100px}.token-banner[data-v-0aed8c13] .token-h1{font-size:80px;margin-bottom:40px}.token-banner[data-v-0aed8c13] .token-h2-c{font-size:18px!important;line-height:53.28px}.token-banner[data-v-0aed8c13] .token-p{font-size:14px!important}.token-banner[data-v-0aed8c13] .jackpot-p1{font-size:60px!important}}@media screen and (max-width:870px){.token-banner[data-v-0aed8c13] .token-h1{font-size:60px;margin-bottom:20px}}@media screen and (max-width:600px){.token-banner[data-v-0aed8c13]{padding-bottom:75px}.token-banner[data-v-0aed8c13] .token-h2-c{font-size:14px!important;padding-left:10px;padding-right:10px}.token-banner[data-v-0aed8c13] .token-h1{font-size:50px}.token-banner[data-v-0aed8c13] .jackpot-p1{font-size:42px!important}.token-banner[data-v-0aed8c13] .token-p{font-size:12px!important}.token-banner[data-v-0aed8c13] .time-left-inner{margin:0 3px}.token-banner[data-v-0aed8c13] .time-left-inner:first-child{margin:0 20px!important}.token-banner[data-v-0aed8c13] .break-line{display:none!important}.token-banner[data-v-0aed8c13] .margin-bottom-2{margin-bottom:50px}}@media screen and (max-width:450px){.token-banner[data-v-0aed8c13] .token-h1{font-size:40px}}@media screen and (max-width:356px){.token-banner[data-v-0aed8c13] .jackpot-p1{font-size:34px!important}.token-banner[data-v-0aed8c13] .token-h1{font-size:34px}.token-banner[data-v-0aed8c13] .token-p{font-size:10px!important}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1375:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Jackpot/Banner.vue?vue&type=template&id=0aed8c13&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"token-banner row"},[_vm._ssrNode("<div class=\"overlay\" data-v-0aed8c13></div><div class=\"container is-max-widescreen\" data-v-0aed8c13><div class=\"content-middle text-center\" data-v-0aed8c13><h1 class=\"token-h1\" data-v-0aed8c13>The FX1 Jackpot</h1><h2 class=\"token-h2-c grey-text\" data-v-0aed8c13>Buy $FXI now to earn tickets for the upcoming Jackpot draw.<br class=\"break-line\" data-v-0aed8c13> The more tickets you buy and hold, the better chance you have to win.</h2><div class=\"margin-bottom-2\" data-v-0aed8c13></div><div class=\"time-left\" data-v-0aed8c13><div class=\"time-left-inner\" data-v-0aed8c13><p class=\"jackpot-p1\" data-v-0aed8c13>"+_vm._ssrEscape(_vm._s(_vm.timeLeft.days))+"</p><p class=\"token-p grey-text\" data-v-0aed8c13>DAYS</p></div><div class=\"time-left-inner\" data-v-0aed8c13><p class=\"jackpot-p1\" data-v-0aed8c13>"+_vm._ssrEscape(_vm._s(_vm.timeLeft.hours))+"</p><p class=\"token-p grey-text\" data-v-0aed8c13>HOURS</p></div><div class=\"time-left-inner\" data-v-0aed8c13><p class=\"jackpot-p1\" data-v-0aed8c13>:</p><p class=\"token-p grey-text\" data-v-0aed8c13> </p></div><div class=\"time-left-inner\" data-v-0aed8c13><p class=\"jackpot-p1\" data-v-0aed8c13>"+_vm._ssrEscape(_vm._s(_vm.timeLeft.minutes))+"</p><p class=\"token-p grey-text\" data-v-0aed8c13>MINUTES</p></div><div class=\"time-left-inner\" data-v-0aed8c13><p class=\"jackpot-p1\" data-v-0aed8c13>:</p><p class=\"token-p\" data-v-0aed8c13> </p></div><div class=\"time-left-inner\" data-v-0aed8c13><p class=\"jackpot-p1\" data-v-0aed8c13>"+_vm._ssrEscape(_vm._s(_vm.timeLeft.seconds))+"</p><p class=\"token-p grey-text\" data-v-0aed8c13>SECONDS</p></div></div><div class=\"actions\" data-v-0aed8c13><a href=\"https://app.uniswap.org/swap?outputCurrency=0xC5190E7FEC4d97a3a3b1aB42dfedac608e2d0793\" target=\"_blank\" class=\"button jackpot-button\" data-v-0aed8c13>Buy $FX1</a></div></div></div>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Jackpot/Banner.vue?vue&type=template&id=0aed8c13&scoped=true&lang=pug&

// EXTERNAL MODULE: external "moment"
var external_moment_ = __webpack_require__(215);
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Jackpot/Banner.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var Bannervue_type_script_lang_js_ = ({
  name: 'TokenBanner',
  data() {
    return {
      timeLeft: {
        days: 0,
        hours: 0,
        minutes: 0,
        seconds: 0
      },
      timerInterval: null
    };
  },
  mounted() {
    this.updateCountDown();
  },
  beforeDestroy() {
    clearInterval(this.timerInterval);
  },
  methods: {
    showAlertMessage() {
      this.$toast.success('$FX1 available to purchase mid to late April', {
        duration: 5000,
        position: 'bottom-left',
        className: 'fx1-success'
      });
    },
    updateCountDown() {
      this.timerInterval = setInterval(() => {
        // Countdown to 11th November 2023 12:00 AM PST
        const date1 = external_moment_default()(1699430400000);
        const date2 = external_moment_default()(new Date());

        // Get the duration between the two dates
        const durationDiff = Object(external_moment_["duration"])(date1.diff(date2));
        // const days = date1.diff(date2, 'days')
        // const totalHours = date1.diff(date2, 'hours')

        // Extract hours, minutes, and seconds from the duration
        const days = durationDiff.days();
        const hours = durationDiff.hours();
        const minutes = durationDiff.minutes();
        const seconds = durationDiff.seconds();
        this.timeLeft = {
          days,
          hours,
          minutes,
          seconds
        };
      }, 1000);
    }
  }
});
// CONCATENATED MODULE: ./components/molecules/Jackpot/Banner.vue?vue&type=script&lang=js&
 /* harmony default export */ var Jackpot_Bannervue_type_script_lang_js_ = (Bannervue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/Jackpot/Banner.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1180)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Jackpot_Bannervue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "0aed8c13",
  "cec6ff6a"
  
)

/* harmony default export */ var Banner = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 616:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/gradient.6f2f16b.png";

/***/ }),

/***/ 933:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1181);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("0d4d0cb6", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=103.js.map
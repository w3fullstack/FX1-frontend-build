exports.ids = [145];
exports.modules = {

/***/ 1139:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_style_index_0_id_5bb21f2c_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(913);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_style_index_0_id_5bb21f2c_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_style_index_0_id_5bb21f2c_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_style_index_0_id_5bb21f2c_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_style_index_0_id_5bb21f2c_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1140:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xp-home[data-v-5bb21f2c]{background:linear-gradient(0deg,#000,transparent 71.01%),#08252c;min-height:calc(100vh - 683px)}.xp-home[data-v-5bb21f2c] h3{font-size:1.5714rem;line-height:2.4286rem;letter-spacing:-.66px}@media screen and (min-width:768px)and (max-width:1439px){.xp-home[data-v-5bb21f2c] .container{padding:0 40px}}@media screen and (max-width:1439px){.xp-home[data-v-5bb21f2c] h1{font-size:48px;line-height:60px;margin-bottom:33px}.xp-home[data-v-5bb21f2c] h2{font-size:28px;line-height:36px;margin-bottom:20px}.xp-home[data-v-5bb21f2c] p.txt-subtitle{font-size:2rem;line-height:36px}.xp-home[data-v-5bb21f2c] p.txt-title{font-size:36px;line-height:44px}}@media screen and (max-width:767px){.xp-home[data-v-5bb21f2c] h1{font-size:32px;line-height:36px}.xp-home[data-v-5bb21f2c] h2{font-size:20px;line-height:26px}.xp-home[data-v-5bb21f2c] p.txt-title{font-size:28px}.xp-home[data-v-5bb21f2c] p.txt-subtitle{font-size:20px;line-height:26px}.xp-home[data-v-5bb21f2c] p.txt-intro{font-size:14px;line-height:20px}.xp-home[data-v-5bb21f2c] p.txt-subtitle-1{font-size:32px;line-height:36px}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1355:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/Home.vue?vue&type=template&id=5bb21f2c&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xp-home"},[_c('XOHomeBanner'),_c('XOHomeAfterBanner'),_c('XOConnectAPP'),_c('XOHomeCatalogs'),_c('XOHomeClubs'),_c('XOHomeWhoIs'),_c('XOHomeWaitingFor')],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/pages/Home.vue?vue&type=template&id=5bb21f2c&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/Home.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Homevue_type_script_lang_js_ = ({
  name: 'XPHome',
  components: {
    XOHomeBanner: () => __webpack_require__.e(/* import() */ 109).then(__webpack_require__.bind(null, 1386)),
    XOHomeAfterBanner: () => __webpack_require__.e(/* import() */ 108).then(__webpack_require__.bind(null, 1387)),
    XOConnectAPP: () => __webpack_require__.e(/* import() */ 91).then(__webpack_require__.bind(null, 1388)),
    XOHomeCatalogs: () => __webpack_require__.e(/* import() */ 110).then(__webpack_require__.bind(null, 1389)),
    XOHomeClubs: () => __webpack_require__.e(/* import() */ 17).then(__webpack_require__.bind(null, 1380)),
    XOHomeWhoIs: () => __webpack_require__.e(/* import() */ 92).then(__webpack_require__.bind(null, 1390)),
    XOHomeWaitingFor: () => __webpack_require__.e(/* import() */ 11).then(__webpack_require__.bind(null, 1382))
  }
});
// CONCATENATED MODULE: ./components/pages/Home.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_Homevue_type_script_lang_js_ = (Homevue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/pages/Home.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1139)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pages_Homevue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "5bb21f2c",
  "89ce243e"
  
)

/* harmony default export */ var Home = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 913:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1140);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("3ae7672d", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=145.js.map
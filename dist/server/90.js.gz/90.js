exports.ids = [90];
exports.modules = {

/***/ 1242:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_RoadmapSection_vue_vue_type_style_index_0_id_95899674_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(964);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_RoadmapSection_vue_vue_type_style_index_0_id_95899674_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_RoadmapSection_vue_vue_type_style_index_0_id_95899674_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_RoadmapSection_vue_vue_type_style_index_0_id_95899674_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_RoadmapSection_vue_vue_type_style_index_0_id_95899674_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1243:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".token-roadmap-section[data-v-95899674]{width:100%;position:relative;overflow:hidden;padding:150px 0 0;z-index:2;min-height:2450px}@media screen and (max-width:1200px){.token-roadmap-section[data-v-95899674]{min-height:2150px}}@media screen and (max-width:930px){.token-roadmap-section[data-v-95899674]{min-height:1950px}}@media screen and (max-width:500px){.token-roadmap-section[data-v-95899674]{min-height:1700px;padding:50px 0 70px}}.token-roadmap-section[data-v-95899674] .for-mobile{display:none}@media screen and (max-width:734px){.token-roadmap-section[data-v-95899674] .for-desktop-tablet{display:none}.token-roadmap-section[data-v-95899674] .for-mobile{display:block}}.token-roadmap-section[data-v-95899674] .token-container-reduce{padding:0!important;margin:0!important;width:100%;height:100%;min-width:100%;position:relative}.token-roadmap-section[data-v-95899674] .top-margin-a{margin-top:25px}.token-roadmap-section[data-v-95899674] .top-margin-b{margin-top:70px}.token-roadmap-section[data-v-95899674] .left-side{padding-right:20%}.token-roadmap-section[data-v-95899674] .layer-top{position:absolute;top:270px;left:50%}@media screen and (max-width:1020px){.token-roadmap-section[data-v-95899674] .layer-top{top:200px}}.token-roadmap-section[data-v-95899674] .layer-middle{position:absolute;top:1020px;right:50%}@media screen and (max-width:1200px){.token-roadmap-section[data-v-95899674] .layer-middle{top:910px;left:50%;right:0}}@media screen and (max-width:1020px){.token-roadmap-section[data-v-95899674] .layer-middle{top:820px}}.token-roadmap-section[data-v-95899674] .layer-bottom{position:absolute;top:1770px;left:50%}@media screen and (max-width:1200px){.token-roadmap-section[data-v-95899674] .layer-bottom{top:1555px}}@media screen and (max-width:1020px){.token-roadmap-section[data-v-95899674] .layer-bottom{top:1455px}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1411:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/RoadmapSection.vue?vue&type=template&id=95899674&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"token-roadmap-section row",attrs:{"id":"roadmap"}},[_vm._ssrNode("<div class=\"container token-container-reduce text-center\" data-v-95899674><h1 data-v-95899674>Roadmap</h1><div class=\"for-desktop-tablet\" data-v-95899674><div class=\"layer-top text-left\" data-v-95899674><ul class=\"token-u\" data-v-95899674><li class=\"token-p\" data-v-95899674>Close pre-seed funding of 1.7M</li><li class=\"token-p\" data-v-95899674>Launch our custom-built website</li><li class=\"token-p\" data-v-95899674>Release our iOS and Android apps</li><li class=\"token-p\" data-v-95899674>Add NBA, NBL, WNBA Locker Rooms</li><li class=\"token-p\" data-v-95899674>Add app push notifications</li><li class=\"token-p\" data-v-95899674>Build our first smart contracts (ERC-721)</li><li class=\"token-p\" data-v-95899674>Add UFC, NFL, and NCAA Locker Rooms</li><li class=\"token-p\" data-v-95899674>Run our first live streaming event</li><li class=\"token-p\" data-v-95899674>Partner with Proof for token launch (ERC-20)</li><li class=\"token-p\" data-v-95899674>Add event rooms for additional sports</li></ul></div><div class=\"layer-middle text-left\" data-v-95899674><ul class=\"token-u\" data-v-95899674><li class=\"token-p\" data-v-95899674>$FX1 token release</li><li class=\"token-p\" data-v-95899674>Public and private streamed sports rooms + audio and video</li><li class=\"token-p\" data-v-95899674>Complete tokenomics design</li><li class=\"token-p\" data-v-95899674>The start of our A.I. research and development</li><li class=\"token-p\" data-v-95899674>Encrypted one-to-one and group messages</li><li class=\"token-p\" data-v-95899674>Revenue share and gamification offering</li><li class=\"token-p\" data-v-95899674>Form key partnerships to help us scale and grow</li><li class=\"token-p\" data-v-95899674>Migration to a new chain that better supports our vision</li></ul></div><div class=\"layer-bottom text-left\" data-v-95899674><ul class=\"token-u\" data-v-95899674><li class=\"token-p\" data-v-95899674>Form partnerships with major sports leagues</li><li class=\"token-p\" data-v-95899674>Create partnership with a global P.R agency</li><li class=\"token-p\" data-v-95899674>Official launch in Europe</li><li class=\"token-p\" data-v-95899674>List on major T1 centralized exchanges</li><li class=\"token-p\" data-v-95899674>Official launch into Asia</li></ul></div></div></div><div class=\"container token-container\" data-v-95899674><div class=\"for-mobile\" data-v-95899674><img"+(_vm._ssrAttr("src",__webpack_require__(632)))+" alt=\"Phase 1 - Launch\" data-v-95899674><ul class=\"token-u text-left\" data-v-95899674><li class=\"token-p\" data-v-95899674>Close pre-seed funding of 1.7M</li><li class=\"token-p\" data-v-95899674>Launch our custom-built website</li><li class=\"token-p\" data-v-95899674>Release our iOS and Android apps</li><li class=\"token-p\" data-v-95899674>Add NBA, NBL, WNBA Locker Rooms</li><li class=\"token-p\" data-v-95899674>Add app push notifications</li><li class=\"token-p\" data-v-95899674>Build our first smart contracts (ERC-721)</li><li class=\"token-p\" data-v-95899674>Add UFC, NFL, and NCAA Locker Rooms</li><li class=\"token-p\" data-v-95899674>Run our first live streaming event</li><li class=\"token-p\" data-v-95899674>Partner with Proof for token launch (ERC-20)</li><li class=\"token-p\" data-v-95899674>Add live sports streams across multiple sports</li></ul><img"+(_vm._ssrAttr("src",__webpack_require__(633)))+" alt=\"Phase 1 - Launch\" data-v-95899674><ul class=\"token-u text-left\" data-v-95899674><li class=\"token-p\" data-v-95899674>$FX1 token release</li><li class=\"token-p\" data-v-95899674>Public and private streamed sports rooms + audio and video</li><li class=\"token-p\" data-v-95899674>Encrypted one-to-one and group messages</li><li class=\"token-p\" data-v-95899674>Token rewards and gamification offering</li><li class=\"token-p\" data-v-95899674>Partner with leading streaming platforms</li><li class=\"token-p\" data-v-95899674>Play by play and real-time game data</li><li class=\"token-p\" data-v-95899674>Migrate smart contracts to Avalanche Network</li><li class=\"token-p\" data-v-95899674>NFT fan collection drops</li></ul><img"+(_vm._ssrAttr("src",__webpack_require__(634)))+" alt=\"Phase 1 - Launch\" data-v-95899674><ul class=\"token-u text-left\" data-v-95899674><li class=\"token-p\" data-v-95899674>Form partnerships with major sports leagues</li><li class=\"token-p\" data-v-95899674>Create partnership with a global P.R agency</li><li class=\"token-p\" data-v-95899674>Official launch in Europe</li><li class=\"token-p\" data-v-95899674>List on major exchanges (Binance, Coinbase, Kraken, Crypto.com)</li><li class=\"token-p\" data-v-95899674>Official launch into Asia</li></ul></div></div>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Token/RoadmapSection.vue?vue&type=template&id=95899674&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Token/RoadmapSection.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var RoadmapSectionvue_type_script_lang_js_ = ({
  name: 'RoadmapSection'
});
// CONCATENATED MODULE: ./components/molecules/Token/RoadmapSection.vue?vue&type=script&lang=js&
 /* harmony default export */ var Token_RoadmapSectionvue_type_script_lang_js_ = (RoadmapSectionvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/Token/RoadmapSection.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1242)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Token_RoadmapSectionvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "95899674",
  "45016825"
  
)

/* harmony default export */ var RoadmapSection = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 632:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/Roadmap-Mobile-1.1fd233c.svg";

/***/ }),

/***/ 633:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/Roadmap-Mobile-2.f0a5bdc.svg";

/***/ }),

/***/ 634:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/Roadmap-Mobile-3.5314f37.svg";

/***/ }),

/***/ 964:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1243);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("d6e70c08", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=90.js.map
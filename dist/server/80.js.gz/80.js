exports.ids = [80];
exports.modules = {

/***/ 1047:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Left_vue_vue_type_style_index_0_id_3d4209e8_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(867);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Left_vue_vue_type_style_index_0_id_3d4209e8_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Left_vue_vue_type_style_index_0_id_3d4209e8_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Left_vue_vue_type_style_index_0_id_3d4209e8_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Left_vue_vue_type_style_index_0_id_3d4209e8_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1048:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xm-locker-room-header-left[data-v-3d4209e8]{width:100%;max-width:250px;margin-top:auto;margin-bottom:auto}@media screen and (max-width:1023px){.xm-locker-room-header-left[data-v-3d4209e8]{width:auto;max-width:unset}}.xm-locker-room-header-left[data-v-3d4209e8].is-logged-in{width:auto;max-width:unset}.xm-locker-room-header-left[data-v-3d4209e8] .logo{margin-top:2px}.xm-locker-room-header-left[data-v-3d4209e8] .logo a img{width:55px}@media screen and (max-width:767px){.xm-locker-room-header-left[data-v-3d4209e8] .logo{max-width:39px;margin-top:4px;margin-left:2px}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1049:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Center_vue_vue_type_style_index_0_id_a969f14e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(868);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Center_vue_vue_type_style_index_0_id_a969f14e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Center_vue_vue_type_style_index_0_id_a969f14e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Center_vue_vue_type_style_index_0_id_a969f14e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Center_vue_vue_type_style_index_0_id_a969f14e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1050:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xm-locker-room-header-center[data-v-a969f14e]{margin-left:auto;margin-right:5%}@media screen and (max-width:767px){.xm-locker-room-header-center[data-v-a969f14e]{margin-right:31px}}.xm-locker-room-header-center[data-v-a969f14e] .is-mobile{display:none}@media screen and (max-width:767px){.xm-locker-room-header-center[data-v-a969f14e] .is-mobile{display:flex}}@media screen and (max-width:767px){.xm-locker-room-header-center[data-v-a969f14e] .is-desktop{display:none}}@media screen and (max-width:767px){.xm-locker-room-header-center[data-v-a969f14e] .mentions{margin-right:-3px}}.xm-locker-room-header-center[data-v-a969f14e] .placeholder{display:flex;flex-direction:column;align-items:center;justify-content:center;margin-top:14px}.xm-locker-room-header-center[data-v-a969f14e] .placeholder a{margin-top:9px;color:#94a6aa;font-size:1rem;font-weight:500}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1051:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Right_vue_vue_type_style_index_0_id_a1cf4040_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(869);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Right_vue_vue_type_style_index_0_id_a1cf4040_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Right_vue_vue_type_style_index_0_id_a1cf4040_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Right_vue_vue_type_style_index_0_id_a1cf4040_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Right_vue_vue_type_style_index_0_id_a1cf4040_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1052:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".menu-section[data-v-a1cf4040]{display:flex!important;align-items:center!important}.menu-section .marg-left[data-v-a1cf4040]{margin-left:10px}.menu-section .logout[data-v-a1cf4040]{color:#f85454!important}.menu-section .link[data-v-a1cf4040]{color:#0c353e!important}.xm-locker-room-header-right[data-v-a1cf4040]{height:100%}@media screen and (max-width:1023px){.xm-locker-room-header-right[data-v-a1cf4040]{width:100%;max-width:75px}}@media screen and (max-width:767px){.xm-locker-room-header-right[data-v-a1cf4040]{width:auto;max-width:unset}}.xm-locker-room-header-right[data-v-a1cf4040].is-logged-in{width:100%}@media screen and (max-width:767px){.xm-locker-room-header-right[data-v-a1cf4040].is-logged-in{width:auto;max-width:unset}}@media screen and (max-width:1023px){.xm-locker-room-header-right[data-v-a1cf4040] .desktop-view{display:none}}.xm-locker-room-header-right[data-v-a1cf4040] .desktop-view .btn-signin,.xm-locker-room-header-right[data-v-a1cf4040] .desktop-view .btn-signup{text-transform:uppercase;width:125px;height:42px;cursor:pointer;color:#fff}.xm-locker-room-header-right[data-v-a1cf4040] .desktop-view .btn-signin{opacity:.6}.xm-locker-room-header-right[data-v-a1cf4040] .mobile-view{display:none}@media screen and (max-width:1023px){.xm-locker-room-header-right[data-v-a1cf4040] .mobile-view{display:block}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1053:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Header_vue_vue_type_style_index_0_id_57d03db8_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(870);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Header_vue_vue_type_style_index_0_id_57d03db8_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Header_vue_vue_type_style_index_0_id_57d03db8_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Header_vue_vue_type_style_index_0_id_57d03db8_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Header_vue_vue_type_style_index_0_id_57d03db8_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1054:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xt-locker-room-header[data-v-57d03db8]{background-color:transparent;min-height:80px;position:absolute;width:100%;top:0;left:0;padding:0 48px;z-index:11}@media screen and (max-width:1365px){.xt-locker-room-header[data-v-57d03db8]{padding:0 20px}}@media screen and (max-width:767px){.xt-locker-room-header[data-v-57d03db8]{padding:0 15px;min-height:58px}}.right-header[data-v-57d03db8]{margin-left:auto}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1306:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/templates/Jackpot/Header.vue?vue&type=template&id=57d03db8&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xt-locker-room-header row"},[_c('XMLockerRoomHeaderLeft'),_c('XMLockerRoomHeaderCenter'),_vm._ssrNode("<div class=\"right-header\" data-v-57d03db8>","</div>",[_c('client-only',[_c('XMLockerRoomHeaderRight')],1)],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/templates/Jackpot/Header.vue?vue&type=template&id=57d03db8&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Jackpot/Header/Left.vue?vue&type=template&id=3d4209e8&scoped=true&lang=pug&
var Leftvue_type_template_id_3d4209e8_scoped_true_lang_pug_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xm-locker-room-header-left",class:_vm.isLoggedIn && 'is-logged-in'},[_vm._ssrNode("<div class=\"logo\" data-v-3d4209e8>","</div>",[_c('nuxt-link',{attrs:{"to":"/"}},[_c('img',{attrs:{"src":__webpack_require__(89),"alt":"FX1"}})])],1)])}
var Leftvue_type_template_id_3d4209e8_scoped_true_lang_pug_staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Jackpot/Header/Left.vue?vue&type=template&id=3d4209e8&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Jackpot/Header/Left.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//

/* harmony default export */ var Leftvue_type_script_lang_js_ = ({
  name: 'XMLockerRoomHeaderLeft'
});
// CONCATENATED MODULE: ./components/molecules/Jackpot/Header/Left.vue?vue&type=script&lang=js&
 /* harmony default export */ var Header_Leftvue_type_script_lang_js_ = (Leftvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/Jackpot/Header/Left.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1047)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Header_Leftvue_type_script_lang_js_,
  Leftvue_type_template_id_3d4209e8_scoped_true_lang_pug_render,
  Leftvue_type_template_id_3d4209e8_scoped_true_lang_pug_staticRenderFns,
  false,
  injectStyles,
  "3d4209e8",
  "3d5038f2"
  
)

/* harmony default export */ var Left = (component.exports);
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Jackpot/Header/Center.vue?vue&type=template&id=a969f14e&scoped=true&lang=pug&
var Centervue_type_template_id_a969f14e_scoped_true_lang_pug_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xm-locker-room-header-center row"},[_c('XALockerRoomHeaderNavigationButton',{class:_vm.isExplore && 'active',attrs:{"label":"Explore","link":"/explore","inactiveIcon":__webpack_require__(96),"activeIcon":__webpack_require__(90)}}),_c('XALockerRoomHeaderNavigationButton',{staticClass:"locker-rooms is-desktop",attrs:{"label":"$FX1 Token","link":"/token","width":"24","height":"24","max-width":"unset","inactiveIcon":__webpack_require__(92),"activeIcon":__webpack_require__(93)}}),_c('XALockerRoomHeaderNavigationButton',{staticClass:"is-mobile",attrs:{"label":"$FX1 Token","link":"/token","width":"24","height":"24","max-width":"unset","inactiveIcon":__webpack_require__(92),"activeIcon":__webpack_require__(93)}})],1)}
var Centervue_type_template_id_a969f14e_scoped_true_lang_pug_staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Jackpot/Header/Center.vue?vue&type=template&id=a969f14e&scoped=true&lang=pug&

// EXTERNAL MODULE: external "vuex"
var external_vuex_ = __webpack_require__(4);

// EXTERNAL MODULE: ./components/atoms/LockerRoom/Header/NavigationButton.vue + 4 modules
var NavigationButton = __webpack_require__(76);

// EXTERNAL MODULE: ./components/atoms/Mentions/Unseen.vue + 4 modules
var Unseen = __webpack_require__(77);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Jackpot/Header/Center.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ var Centervue_type_script_lang_js_ = ({
  name: 'XMLockerRoomHeaderCenter',
  components: {
    XALockerRoomHeaderNavigationButton: NavigationButton["a" /* default */],
    XAMentionsUnseen: Unseen["a" /* default */]
  },
  computed: {
    ...Object(external_vuex_["mapGetters"])({
      getLockerRoomSupporting: 'lockerRoom/getLockerRoomSupporting'
    }),
    isLockerRoom() {
      var _this$$route, _this$$route$params;
      return ((_this$$route = this.$route) === null || _this$$route === void 0 ? void 0 : (_this$$route$params = _this$$route.params) === null || _this$$route$params === void 0 ? void 0 : _this$$route$params.slug) && this.$route.name.includes('locker-room');
    },
    isExplore() {
      var _this$$route2, _this$$route2$params;
      return ((_this$$route2 = this.$route) === null || _this$$route2 === void 0 ? void 0 : (_this$$route2$params = _this$$route2.params) === null || _this$$route2$params === void 0 ? void 0 : _this$$route2$params.slug) || this.$route.name === 'explore';
    },
    lockerRoomSlug() {
      const supporting = this.getLockerRoomSupporting[0] || [];
      const channelSlug = supporting === null || supporting === void 0 ? void 0 : supporting.slug;
      const defaultSlug = supporting === null || supporting === void 0 ? void 0 : supporting.defaultChannelSlug;
      if (this.getLockerRoomSupporting.length) {
        return `/locker-room/${channelSlug}/${defaultSlug}`;
      }
      return '/';
    },
    isMention() {
      var _this$$route3, _this$$route3$params;
      return (_this$$route3 = this.$route) === null || _this$$route3 === void 0 ? void 0 : (_this$$route3$params = _this$$route3.params) === null || _this$$route3$params === void 0 ? void 0 : _this$$route3$params.id;
    }
  }
});
// CONCATENATED MODULE: ./components/molecules/Jackpot/Header/Center.vue?vue&type=script&lang=js&
 /* harmony default export */ var Header_Centervue_type_script_lang_js_ = (Centervue_type_script_lang_js_); 
// CONCATENATED MODULE: ./components/molecules/Jackpot/Header/Center.vue



function Center_injectStyles (context) {
  
  var style0 = __webpack_require__(1049)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var Center_component = Object(componentNormalizer["a" /* default */])(
  Header_Centervue_type_script_lang_js_,
  Centervue_type_template_id_a969f14e_scoped_true_lang_pug_render,
  Centervue_type_template_id_a969f14e_scoped_true_lang_pug_staticRenderFns,
  false,
  Center_injectStyles,
  "a969f14e",
  "1e388256"
  
)

/* harmony default export */ var Center = (Center_component.exports);
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Jackpot/Header/Right.vue?vue&type=template&id=a1cf4040&scoped=true&lang=pug&
var Rightvue_type_template_id_a1cf4040_scoped_true_lang_pug_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xm-locker-room-header-right row items-center justify-end",class:_vm.isLoggedIn && 'is-logged-in'},[(_vm.isLoggedIn)?[_vm._ssrNode("<div class=\"desktop-view row items-center\" data-v-a1cf4040>","</div>",[_c('b-dropdown',{staticClass:"user-menu",attrs:{"aria-role":"list","position":"is-bottom-left","append-to-body":"","mobile-modal":false},scopedSlots:_vm._u([{key:"trigger",fn:function(ref){
var active = ref.active;
return [_c('XAMyAvatar')]}}],null,false,1860002218)},[_c('b-dropdown-item',{attrs:{"aria-role":"listitem"}},[_c('nuxt-link',{attrs:{"to":"/account/settings"}},[_c('div',{staticClass:"menu-section"},[_c('div',{staticClass:"link marg-left"},[_vm._v("My account")])])])],1),_c('b-dropdown-item',{attrs:{"aria-role":"listitem"},on:{"click":function($event){return _vm.fnLogOut()}}},[_c('div',{staticClass:"menu-section"},[_c('img',{attrs:{"src":__webpack_require__(91)}}),_c('div',{staticClass:"logout marg-left"},[_vm._v("Log out")])])])],1)],1),_vm._ssrNode("<div class=\"mobile-view\" data-v-a1cf4040>","</div>",[_vm._ssrNode("<div class=\"mobile-menu row\" data-v-a1cf4040>","</div>",[_c('b-icon',{attrs:{"icon":"menu","custom-size":"mdi-36px"}})],1),(_vm.showMobileMenu)?_c('XALoggedInMobileView'):_vm._e()],1)]:_vm._e(),(!_vm.isLoggedIn)?[_vm._ssrNode("<div class=\"desktop-view row items-center\" data-v-a1cf4040>","</div>",[_c('b-button',{staticClass:"btn-signup",attrs:{"type":"is-primary","tag":"router-link","to":"/signin"}},[_vm._v("Sign In")])],1),_vm._ssrNode("<div class=\"mobile-view\" data-v-a1cf4040>","</div>",[_vm._ssrNode("<div class=\"mobile-menu row\" data-v-a1cf4040>","</div>",[_c('b-icon',{attrs:{"icon":"menu","custom-size":"mdi-36px"}})],1),(_vm.showMobileMenu)?_c('XALoggedInMobileView'):_vm._e()],1)]:_vm._e()],2)}
var Rightvue_type_template_id_a1cf4040_scoped_true_lang_pug_staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/Jackpot/Header/Right.vue?vue&type=template&id=a1cf4040&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/Jackpot/Header/Right.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var Rightvue_type_script_lang_js_ = ({
  name: 'XMLockerRoomHeaderRight',
  components: {
    XALockerRoomHeaderSearch: () => __webpack_require__.e(/* import() */ 14).then(__webpack_require__.bind(null, 1392)),
    XMLockerRoomHeaderNotifications: () => __webpack_require__.e(/* import() */ 15).then(__webpack_require__.bind(null, 1393)),
    XAMyAvatar: () => __webpack_require__.e(/* import() */ 4).then(__webpack_require__.bind(null, 1394)),
    XALoggedInMobileView: () => __webpack_require__.e(/* import() */ 126).then(__webpack_require__.bind(null, 1401))
  },
  data() {
    return {
      showMobileMenu: false
    };
  },
  mounted() {
    // console.log("isLoggedIn: ", this.isLoggedIn);
    this.$root.$on('evtRtShowMobileMenu', value => {
      this.showMobileMenu = value;
    });
  },
  methods: {
    ...Object(external_vuex_["mapActions"])({
      authLogOut: 'auth/authLogOut',
      clearAuthDetails: 'auth/clearAuthDetails'
    }),
    async fnLogOut() {
      this.$fireMess.unSubscribeToTopic({
        topicName: this.userID
      });
      await this.authLogOut();
      const disconnect = this.$root.ChatSocket ? this.$root.ChatSocket.disconnect() : null;
      await this.$router.push({
        path: '/'
      });
      await this.clearAuthDetails();
      this.$mixpanel.reset();
      return disconnect;
    }
  }
});
// CONCATENATED MODULE: ./components/molecules/Jackpot/Header/Right.vue?vue&type=script&lang=js&
 /* harmony default export */ var Header_Rightvue_type_script_lang_js_ = (Rightvue_type_script_lang_js_); 
// CONCATENATED MODULE: ./components/molecules/Jackpot/Header/Right.vue



function Right_injectStyles (context) {
  
  var style0 = __webpack_require__(1051)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var Right_component = Object(componentNormalizer["a" /* default */])(
  Header_Rightvue_type_script_lang_js_,
  Rightvue_type_template_id_a1cf4040_scoped_true_lang_pug_render,
  Rightvue_type_template_id_a1cf4040_scoped_true_lang_pug_staticRenderFns,
  false,
  Right_injectStyles,
  "a1cf4040",
  "f22cb168"
  
)

/* harmony default export */ var Right = (Right_component.exports);
// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/templates/Jackpot/Header.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//




/* harmony default export */ var Headervue_type_script_lang_js_ = ({
  name: 'XTLockerRoomHeader',
  components: {
    XMLockerRoomHeaderLeft: Left,
    XMLockerRoomHeaderCenter: Center,
    XMLockerRoomHeaderRight: Right
  }
});
// CONCATENATED MODULE: ./components/templates/Jackpot/Header.vue?vue&type=script&lang=js&
 /* harmony default export */ var Jackpot_Headervue_type_script_lang_js_ = (Headervue_type_script_lang_js_); 
// CONCATENATED MODULE: ./components/templates/Jackpot/Header.vue



function Header_injectStyles (context) {
  
  var style0 = __webpack_require__(1053)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var Header_component = Object(componentNormalizer["a" /* default */])(
  Jackpot_Headervue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  Header_injectStyles,
  "57d03db8",
  "ce6349c0"
  
)

/* harmony default export */ var Header = __webpack_exports__["default"] = (Header_component.exports);

/***/ }),

/***/ 867:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1048);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("52feb91b", content, true, context)
};

/***/ }),

/***/ 868:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1050);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("420bfa4b", content, true, context)
};

/***/ }),

/***/ 869:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1052);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("39dde599", content, true, context)
};

/***/ }),

/***/ 870:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1054);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("b24e5c1e", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=80.js.map
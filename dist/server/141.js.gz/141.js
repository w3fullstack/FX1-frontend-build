exports.ids = [141];
exports.modules = {

/***/ 1055:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_About_vue_vue_type_style_index_0_id_ef5cd492_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(871);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_About_vue_vue_type_style_index_0_id_ef5cd492_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_About_vue_vue_type_style_index_0_id_ef5cd492_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_About_vue_vue_type_style_index_0_id_ef5cd492_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_About_vue_vue_type_style_index_0_id_ef5cd492_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1056:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".page-content[data-v-ef5cd492]{min-height:calc(100vh - 406px);border-bottom:1px solid #1c3e45;background-color:#0c353e;padding:50px}.page-content[data-v-ef5cd492] a{color:#fff;text-decoration:underline}.page-content[data-v-ef5cd492] .bottom-border{border-bottom:2px solid #fff}.page-content[data-v-ef5cd492] h1{font-size:3rem;line-height:1.2;margin:40px 0 20px;letter-spacing:0}.page-content[data-v-ef5cd492] h2{font-size:1.5714rem;font-weight:500;margin-bottom:.75rem}.page-content[data-v-ef5cd492] h3{font-size:1.5714rem;line-height:1.2;margin:40px 0 20px}.page-content[data-v-ef5cd492] p{font-size:1.1429rem;font-weight:300;margin-bottom:20px}.page-content[data-v-ef5cd492] ul{margin:0;padding:0}.page-content[data-v-ef5cd492] ul li{list-style-type:none;font-size:1.1429rem;font-weight:300;margin-bottom:.7143rem;margin-left:1.4286rem}.page-content[data-v-ef5cd492] ul li ul li{list-style-type:none}.page-content[data-v-ef5cd492] pre{display:block;padding:.7143rem;word-break:break-all;background-color:#f5f5f5;border:1px solid #ccc;border-radius:5px;font-size:12px;white-space:pre-line;margin-bottom:.7143rem}.page-content[data-v-ef5cd492] pre span{display:block}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1342:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/About.vue?vue&type=template&id=ef5cd492&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"page-content"},[_vm._ssrNode("<div class=\"container is-max-desktop\" data-v-ef5cd492><h1 style=\"margin-top: 0\" data-v-ef5cd492>About Us</h1><h2 data-v-ef5cd492>Our Vision</h2><p data-v-ef5cd492>To redefine how Gen Z and Millennial's consume and interact with sports.</p><h2 data-v-ef5cd492>Our Mission</h2><p data-v-ef5cd492>We are on a mission to evolve and enhance the overall experience of watching sports online for Gen Z’sand young Millennial communities. FX1 will grow viewership by enabling them to connect and engage socially\nwhile watching online sports with their friends, while also having the ability to earn income, prizes, and clout.</p><h2 data-v-ef5cd492>What We Do</h2><p data-v-ef5cd492>Our product is an interactive live messaging platform that seamlessly integrates and enhances the streamed sportsgame day experience, making it easier for fans to connect and engage socially while watching sports online.</p><p data-v-ef5cd492>Fans will be able to browse all their streamed sports platforms in one place, watch live sports online, chatwith friends anywhere, and earn rewards and prizes while watching sports.</p><p data-v-ef5cd492>FX1 will partner with streaming platforms, sporting leagues, and media rights holders. Our platform complementsand enhances the online experience for its customers.</p><p data-v-ef5cd492>Unlike the current streaming platforms that offer streamed content to customers in return for a fee, FX1 leveragesthis streamed content by overlaying it with proprietary-built technology that further enhances the experience.</p><p data-v-ef5cd492>FX1 Pty Ltd is an Australian-owned company. It also owns FIT3 LLC, which represents theNorth American arm of FX1. Our North American team is based out of California and supports\nFX1 across product development, sales, and marketing.</p><p data-v-ef5cd492>To get in touch please shoot us an email to <a href=\"mailto:hello@fx1.io\" data-v-ef5cd492><strong data-v-ef5cd492>hello@fx1.io</strong></a>.</p></div>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/pages/About.vue?vue&type=template&id=ef5cd492&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/About.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Aboutvue_type_script_lang_js_ = ({
  name: 'XPAbout'
});
// CONCATENATED MODULE: ./components/pages/About.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_Aboutvue_type_script_lang_js_ = (Aboutvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/pages/About.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1055)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pages_Aboutvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "ef5cd492",
  "46eb920a"
  
)

/* harmony default export */ var About = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 871:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1056);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("a5ffff1c", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=141.js.map
exports.ids = [81];
exports.modules = {

/***/ 1168:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Benefits_vue_vue_type_style_index_0_id_0f859b5c_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(927);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Benefits_vue_vue_type_style_index_0_id_0f859b5c_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Benefits_vue_vue_type_style_index_0_id_0f859b5c_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Benefits_vue_vue_type_style_index_0_id_0f859b5c_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Benefits_vue_vue_type_style_index_0_id_0f859b5c_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1169:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".benefits-section[data-v-0f859b5c]{width:100%;position:relative;padding:200px 0 0;z-index:2}.benefits-section[data-v-0f859b5c] .circles{width:100%;max-width:unset;position:absolute;top:50%;left:10%;transform:translate(-50%,-30%);overflow:hidden;z-index:-1}@media screen and (max-width:1025px){.benefits-section[data-v-0f859b5c] .circles{width:75%;transform:translate(-50%);top:unset;left:5%;bottom:-35%}}@media screen and (max-width:500px){.benefits-section[data-v-0f859b5c] .circles{display:none}}.benefits-section[data-v-0f859b5c] .top-margin-a{margin-top:110px}@media screen and (max-width:1025px){.benefits-section[data-v-0f859b5c] .top-margin-a{margin-top:60px}}.benefits-section[data-v-0f859b5c] .top-margin-b{margin-top:70px}.benefits-section[data-v-0f859b5c] h2{font-size:60px;text-align:center}@media screen and (max-width:1025px){.benefits-section[data-v-0f859b5c] h2{font-size:36px;line-height:40px;font-weight:600}}@media screen and (max-width:500px){.benefits-section[data-v-0f859b5c] h2{font-size:28px;line-height:31px;font-weight:700;text-align:left}}.benefits-section[data-v-0f859b5c] .content-container{margin-right:-30px}@media screen and (max-width:1025px){.benefits-section[data-v-0f859b5c] .content-container{margin-right:-20px}}@media screen and (max-width:500px){.benefits-section[data-v-0f859b5c] .content-container{margin-right:0}}.benefits-section[data-v-0f859b5c] .content-container .card{background-color:#0c353e;border-radius:20px;margin-bottom:30px;padding:20px;flex-basis:calc(33.33333% - 30px);margin-right:30px}@media screen and (max-width:1025px){.benefits-section[data-v-0f859b5c] .content-container .card{flex-basis:calc(50% - 20px);margin-right:20px}}@media screen and (max-width:500px){.benefits-section[data-v-0f859b5c] .content-container .card{flex-basis:100%;margin-right:0}}.benefits-section[data-v-0f859b5c] .content-container .token-p{margin-top:10px;font-size:23px!important;line-height:32px!important}@media screen and (max-width:500px){.benefits-section[data-v-0f859b5c]{padding:100px 0}.benefits-section[data-v-0f859b5c] .top-margin-b{margin-top:0!important}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1369:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/BossMembership/Benefits.vue?vue&type=template&id=0f859b5c&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"benefits-section row"},[_vm._ssrNode("<img"+(_vm._ssrAttr("src",__webpack_require__(599)))+" alt=\"circles\" class=\"circles\" data-v-0f859b5c><div class=\"container token-container\" data-v-0f859b5c><div class=\"row\" data-v-0f859b5c><div class=\"col\" data-v-0f859b5c><h2 data-v-0f859b5c>What are the benefits?</h2><div class=\"top-margin-a\" data-v-0f859b5c></div><div class=\"row content-container\" data-v-0f859b5c><div class=\"card\" data-v-0f859b5c><div class=\"flex-column items-start\" data-v-0f859b5c><div class=\"svg-icon\" data-v-0f859b5c><img"+(_vm._ssrAttr("src",__webpack_require__(601)))+" data-v-0f859b5c></div><p class=\"token-p\" data-v-0f859b5c>Your own “Game Boss” membership NFT to promote on your FX1 profile</p></div></div><div class=\"card\" data-v-0f859b5c><div class=\"flex-column items-start\" data-v-0f859b5c><div class=\"svg-icon\" data-v-0f859b5c><img"+(_vm._ssrAttr("src",__webpack_require__(609)))+" data-v-0f859b5c></div><p class=\"token-p\" data-v-0f859b5c>Voting rights on product release schedules, and company direction</p></div></div><div class=\"card\" data-v-0f859b5c><div class=\"flex-column items-start\" data-v-0f859b5c><div class=\"svg-icon\" data-v-0f859b5c><img"+(_vm._ssrAttr("src",__webpack_require__(604)))+" data-v-0f859b5c></div><p class=\"token-p\" data-v-0f859b5c>Access to early release products for testing and feedback</p></div></div><div class=\"card\" data-v-0f859b5c><div class=\"flex-column items-start\" data-v-0f859b5c><div class=\"svg-icon\" data-v-0f859b5c><img"+(_vm._ssrAttr("src",__webpack_require__(608)))+" data-v-0f859b5c></div><p class=\"token-p\" data-v-0f859b5c>Receive quarterly company updates, usually reserved for shareholders</p></div></div><div class=\"card\" data-v-0f859b5c><div class=\"flex-column items-start\" data-v-0f859b5c><div class=\"svg-icon\" data-v-0f859b5c><img"+(_vm._ssrAttr("src",__webpack_require__(606)))+" data-v-0f859b5c></div><p class=\"token-p\" data-v-0f859b5c>Access to a the private membership Locker Room on FX1</p></div></div><div class=\"card\" data-v-0f859b5c><div class=\"flex-column items-start\" data-v-0f859b5c><div class=\"svg-icon\" data-v-0f859b5c><img"+(_vm._ssrAttr("src",__webpack_require__(605)))+" data-v-0f859b5c></div><p class=\"token-p\" data-v-0f859b5c>Access to early releases on Fan Avatar NFT collections</p></div></div></div></div></div></div>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/molecules/BossMembership/Benefits.vue?vue&type=template&id=0f859b5c&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/molecules/BossMembership/Benefits.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Benefitsvue_type_script_lang_js_ = ({
  name: 'ForWho'
});
// CONCATENATED MODULE: ./components/molecules/BossMembership/Benefits.vue?vue&type=script&lang=js&
 /* harmony default export */ var BossMembership_Benefitsvue_type_script_lang_js_ = (Benefitsvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/molecules/BossMembership/Benefits.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1168)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  BossMembership_Benefitsvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "0f859b5c",
  "5c573c68"
  
)

/* harmony default export */ var Benefits = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 599:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/circle-2.bb5ec15.png";

/***/ }),

/***/ 601:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/electro.0cf28ce.svg";

/***/ }),

/***/ 604:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/feedback.7ba01ce.svg";

/***/ }),

/***/ 605:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/keys.d1e4483.svg";

/***/ }),

/***/ 606:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/membership.31a6580.svg";

/***/ }),

/***/ 608:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/rocket.1fc55b9.svg";

/***/ }),

/***/ 609:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/rupor.578333f.svg";

/***/ }),

/***/ 927:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1169);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("68b1bdfb", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=81.js.map
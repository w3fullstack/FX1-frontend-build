exports.ids = [138];
exports.modules = {

/***/ 1294:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatFriendsList_vue_vue_type_style_index_0_id_0fee57d3_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(990);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatFriendsList_vue_vue_type_style_index_0_id_0fee57d3_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatFriendsList_vue_vue_type_style_index_0_id_0fee57d3_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatFriendsList_vue_vue_type_style_index_0_id_0fee57d3_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatFriendsList_vue_vue_type_style_index_0_id_0fee57d3_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1295:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(24);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(310);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".friends-list__container[data-v-0fee57d3]{display:flex;flex-direction:column;margin-top:25px}.friends-list__container .friend[data-v-0fee57d3]{display:flex;align-items:center;margin-bottom:23px}.friends-list__container .friend input[type=checkbox]+label[data-v-0fee57d3]{display:block;margin:.2em;cursor:pointer;padding:.2em}.friends-list__container .friend input[type=checkbox][data-v-0fee57d3]{display:none}.friends-list__container .friend input[type=checkbox]+label[data-v-0fee57d3]:before{content:\"\";width:24px;height:24px;border:3px solid #94a6aa;border-radius:5px;display:inline-block;padding-left:.2em;padding-bottom:.3em;margin-right:.2em;vertical-align:bottom;color:transparent;transition:.2s}.friends-list__container .friend input[type=checkbox]+label[data-v-0fee57d3]:active:before{transform:scale(0)}.friends-list__container .friend input[type=checkbox]:checked+label[data-v-0fee57d3]:before{background-color:#f85454;border-color:#f85454;color:#fff;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");background-repeat:no-repeat;background-position:50%}.friends-list__container .friend .friend-avatar[data-v-0fee57d3]{display:flex;position:relative;margin:0 16px}.friends-list__container .friend .friend-avatar img[data-v-0fee57d3]{width:32px;height:32px;border-radius:50%}.friends-list__container .friend .friend-avatar .default-avatar[data-v-0fee57d3]{width:32px;height:32px;display:flex;justify-content:center;align-items:center;background-color:#f85454;border-radius:50%;font-weight:300;font-size:13px;text-transform:uppercase}.friends-list__container .friend .online[data-v-0fee57d3]:after{content:\"\";position:absolute;width:12px;height:12px;bottom:-3px;right:-2px;background-color:#2ddc1e;border-radius:50%;border:3px solid #08252c}.friends-list__container .friend span[data-v-0fee57d3]{font-weight:400;font-size:15px;line-height:20px;color:#fff;opacity:.5;text-transform:none}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1441:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/ExploreEvent/ChatFriendsList.vue?vue&type=template&id=0fee57d3&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return (_vm.friendsList)?_c('div',{staticClass:"friends-list__container"},[_vm._ssrNode((_vm._ssrList((_vm.friendsList),function(friend){return ("<div class=\"friend\" data-v-0fee57d3><input type=\"checkbox\""+(_vm._ssrAttr("id",friend.id || friend.username))+(_vm._ssrAttr("value",friend.id))+(_vm._ssrAttr("checked",Array.isArray(_vm.selectedIds)?_vm._i(_vm.selectedIds,friend.id)>-1:(_vm.selectedIds)))+" data-v-0fee57d3><label"+(_vm._ssrAttr("for",friend.id || friend.username))+" data-v-0fee57d3></label><div"+(_vm._ssrClass("friend-avatar",[_vm.userOnline(friend.id) ? 'online' : '']))+" data-v-0fee57d3>"+((friend.Avatar && friend.Avatar.PhotoURL)?("<img"+(_vm._ssrAttr("src",friend.Avatar.PhotoURL))+" data-v-0fee57d3>"):("<div class=\"default-avatar\" data-v-0fee57d3>"+_vm._ssrEscape(_vm._s(friend.username.charAt(0).toUpperCase()))+"</div>"))+"</div><span data-v-0fee57d3>"+_vm._ssrEscape(_vm._s(friend.username))+"</span></div>")})))]):_vm._e()}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/organisms/ExploreEvent/ChatFriendsList.vue?vue&type=template&id=0fee57d3&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/organisms/ExploreEvent/ChatFriendsList.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var ChatFriendsListvue_type_script_lang_js_ = ({
  name: 'XOChatFriendsList',
  props: {
    friendsList: {
      type: Array,
      default: () => []
    },
    onlineMembers: {
      type: Array,
      default: () => []
    },
    selectedFriendsIds: {
      type: Array,
      default: () => []
    }
  },
  computed: {
    selectedIds: {
      get() {
        return this.selectedFriendsIds;
      },
      set(value) {
        this.$emit('update:selectedFriendsIds', value);
      }
    },
    onlineUsers() {
      const onlineUsers = this.onlineMembers ? this.onlineMembers.map(e => {
        var _e$User;
        return e === null || e === void 0 ? void 0 : (_e$User = e.User) === null || _e$User === void 0 ? void 0 : _e$User.id;
      }) : [];
      return onlineUsers;
    },
    userOnline() {
      return user => this.onlineUsers.includes(user);
    }
  }
});
// CONCATENATED MODULE: ./components/organisms/ExploreEvent/ChatFriendsList.vue?vue&type=script&lang=js&
 /* harmony default export */ var ExploreEvent_ChatFriendsListvue_type_script_lang_js_ = (ChatFriendsListvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/organisms/ExploreEvent/ChatFriendsList.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1294)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  ExploreEvent_ChatFriendsListvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "0fee57d3",
  "8b4c41aa"
  
)

/* harmony default export */ var ChatFriendsList = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 990:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1295);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("3e3b5e54", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=138.js.map
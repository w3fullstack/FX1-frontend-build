exports.ids = [36];
exports.modules = {

/***/ 1318:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./pages/create-new-password.vue?vue&type=template&id=4a4c9ad8&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('XPCreateNewPassword')}
var staticRenderFns = []


// CONCATENATED MODULE: ./pages/create-new-password.vue?vue&type=template&id=4a4c9ad8&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./pages/create-new-password.vue?vue&type=script&lang=js&
//
//
//
//

/* harmony default export */ var create_new_passwordvue_type_script_lang_js_ = ({
  name: 'PageCreateNewPassword',
  components: {
    XPCreateNewPassword: () => __webpack_require__.e(/* import() */ 143).then(__webpack_require__.bind(null, 1344))
  },
  layout: 'auth',
  mounted() {
    const params = {
      pageName: 'Create new password',
      isLoggedIn: this.isLoggedIn
    };
    this.$mixpanelClient.trackViewPage(params);
  }
});
// CONCATENATED MODULE: ./pages/create-new-password.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_create_new_passwordvue_type_script_lang_js_ = (create_new_passwordvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./pages/create-new-password.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pages_create_new_passwordvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  "48c62485"
  
)

/* harmony default export */ var create_new_password = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=create-new-password.js.map
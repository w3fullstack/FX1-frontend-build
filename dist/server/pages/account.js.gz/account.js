exports.ids = [31];
exports.modules = {

/***/ 1316:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./pages/account.vue?vue&type=template&id=648b6364&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('XPAccount')}
var staticRenderFns = []


// CONCATENATED MODULE: ./pages/account.vue?vue&type=template&id=648b6364&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./pages/account.vue?vue&type=script&lang=js&
//
//
//
//

/* harmony default export */ var accountvue_type_script_lang_js_ = ({
  name: 'PageAccount',
  components: {
    XPAccount: () => __webpack_require__.e(/* import() */ 78).then(__webpack_require__.bind(null, 1304))
  },
  layout: 'account'
});
// CONCATENATED MODULE: ./pages/account.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_accountvue_type_script_lang_js_ = (accountvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./pages/account.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pages_accountvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  "e8e0854e"
  
)

/* harmony default export */ var account = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=account.js.map
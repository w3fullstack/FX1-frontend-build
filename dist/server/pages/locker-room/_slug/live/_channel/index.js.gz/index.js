exports.ids = [45];
exports.modules = {

/***/ 1029:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_style_index_0_id_cb17a90a_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(858);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_style_index_0_id_cb17a90a_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_style_index_0_id_cb17a90a_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_style_index_0_id_cb17a90a_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_style_index_0_id_cb17a90a_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1030:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".video-container[data-v-cb17a90a]{width:100%;height:85vh}.toolbar-container[data-v-cb17a90a]{width:100%;height:25vh;background:#0c353e;color:#fff;padding:10px 30px}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1334:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./pages/locker-room/_slug/live/_channel/index.vue?vue&type=template&id=cb17a90a&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"is-flex",staticStyle:{"width":"100vw","height":"100vh"}},[_vm._ssrNode("<div style=\"width: 100%; position: relative;\" data-v-cb17a90a>","</div>",[_vm._ssrNode("<img"+(_vm._ssrAttr("src",__webpack_require__(582)))+" height=\"100px\" style=\"position: absolute; top: 20px; left:20px; z-index: 100 !important; cursor: pointer;\" data-v-cb17a90a><iframe"+(_vm._ssrAttr("src",_vm.link))+" class=\"video-container\" style=\"width: 100%;\" data-v-cb17a90a></iframe>"),_vm._ssrNode("<div class=\"toolbar-container\" data-v-cb17a90a>","</div>",[_vm._ssrNode("<div class=\"is-flex\" data-v-cb17a90a>","</div>",[_vm._ssrNode("<div data-v-cb17a90a><div class=\"is-flex mb-2\" data-v-cb17a90a><h3 class=\"col\" data-v-cb17a90a>"+_vm._ssrEscape("# "+_vm._s(_vm.name))+"</h3><img"+(_vm._ssrAttr("src",__webpack_require__(583)))+" data-v-cb17a90a></div><div class=\"is-flex mb-3 align-center\" data-v-cb17a90a><img"+(_vm._ssrAttr("src",__webpack_require__(584)))+" class=\"mr-3\" data-v-cb17a90a><h4 class=\"has-text-weight-light\" data-v-cb17a90a>"+_vm._ssrEscape(_vm._s(_vm.date))+"</h4></div></div>"),_vm._ssrNode("<div class=\"ml-auto\" data-v-cb17a90a>","</div>",[(!_vm.showLiveChat)?_c('b-button',{attrs:{"type":"is-white","outlined":"","icon-left":"message"},on:{"click":function($event){_vm.showLiveChat = true}}},[_vm._v("Open Chat")]):_vm._e()],1)],2)])],2),(_vm.showLiveChat)?_vm._ssrNode("<div class=\"xp-locker-room-channels row col\" style=\"max-width: 25%; width: 100%;\" data-v-cb17a90a>","</div>",[_c('client-only',[(!_vm.getLockerRoomIsLoading)?[(_vm.isSupported && _vm.isLoggedIn)?_c('XTLockerRoomSupported'):_c('XTLockerRoomUnsupported',{attrs:{"live":true}})]:_vm._e()],2)],1):_vm._e()])}
var staticRenderFns = []


// CONCATENATED MODULE: ./pages/locker-room/_slug/live/_channel/index.vue?vue&type=template&id=cb17a90a&scoped=true&lang=pug&

// EXTERNAL MODULE: external "uuid"
var external_uuid_ = __webpack_require__(38);

// EXTERNAL MODULE: external "moment"
var external_moment_ = __webpack_require__(215);
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_);

// EXTERNAL MODULE: external "vuex-map-fields"
var external_vuex_map_fields_ = __webpack_require__(2);

// EXTERNAL MODULE: external "vuex"
var external_vuex_ = __webpack_require__(4);

// EXTERNAL MODULE: external "lodash/map"
var map_ = __webpack_require__(225);
var map_default = /*#__PURE__*/__webpack_require__.n(map_);

// EXTERNAL MODULE: external "lodash/findIndex"
var findIndex_ = __webpack_require__(226);
var findIndex_default = /*#__PURE__*/__webpack_require__.n(findIndex_);

// EXTERNAL MODULE: ./mixins/meta.js
var meta = __webpack_require__(435);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./pages/locker-room/_slug/live/_channel/index.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//








/* harmony default export */ var _channelvue_type_script_lang_js_ = ({
  name: 'PageLockerRoomChannels',
  components: {
    XTLockerRoomSupported: () => __webpack_require__.e(/* import() */ 7).then(__webpack_require__.bind(null, 1353)),
    XTLockerRoomUnsupported: () => __webpack_require__.e(/* import() */ 27).then(__webpack_require__.bind(null, 1354))
  },
  mixins: [meta["a" /* default */]],
  layout: 'live',
  async asyncData({
    app,
    route,
    store
  }) {
    var _route$params, _route$params2, _notificationActive$c, _notificationActive$N, _notificationActive$N2;
    const notificationActive = await store.state.notification.active;
    const slug = route === null || route === void 0 ? void 0 : (_route$params = route.params) === null || _route$params === void 0 ? void 0 : _route$params.slug;
    const slugChannel = route === null || route === void 0 ? void 0 : (_route$params2 = route.params) === null || _route$params2 === void 0 ? void 0 : _route$params2.channel;
    const params = {
      channelSlug: route.params.channel
      // count: 10,
    };

    const paramsCreatedAt = {
      channelSlug: route.params.channel,
      cursor: (notificationActive === null || notificationActive === void 0 ? void 0 : (_notificationActive$c = notificationActive.createdAt) === null || _notificationActive$c === void 0 ? void 0 : _notificationActive$c.toString()) || (notificationActive === null || notificationActive === void 0 ? void 0 : (_notificationActive$N = notificationActive.Notification) === null || _notificationActive$N === void 0 ? void 0 : (_notificationActive$N2 = _notificationActive$N.createdAt) === null || _notificationActive$N2 === void 0 ? void 0 : _notificationActive$N2.toString()),
      direction: 'up'
    };
    let chatItems;
    if (notificationActive) {
      const {
        getMessagesByChannelSlugUsingCreatedAtAsCursor: {
          items
        }
      } = await app.$api.getMessagesByChannelSlugUsingCreatedAtAsCursor(paramsCreatedAt);
      chatItems = items;
    } else {
      const {
        getMessagesByChannelSlug: {
          items
        }
      } = await app.$api.getMessagesByChannelSlug(params);
      chatItems = items;
    }

    // async await parallel
    const [{
      getChannel
    }, {
      getLockerRoom
    }] = await Promise.all([app.$api.getChannel({
      slug: slugChannel
    }), app.$api.getLockerRoom({
      slug
    })]);
    const chats = [];
    chats.push(...chatItems);
    const supporting = store.state.lockerRoom.supporting || [];
    const active = supporting.filter(x => {
      return (x === null || x === void 0 ? void 0 : x.slug) === slug;
    });
    const isSupporting = !!active.length;
    return {
      isSupported: isSupporting || (getLockerRoom === null || getLockerRoom === void 0 ? void 0 : getLockerRoom.isSupported),
      channel: getChannel,
      lockerRoom: getLockerRoom,
      chats,
      isLive: true
    };
  },
  data() {
    return {
      socket: null,
      myEmitErrors: {},
      channel: null,
      oldChannel: null,
      isSupported: true,
      lockerRoom: null,
      chats: [],
      usersTyping: [],
      isLive: false,
      showToolbar: true
    };
  },
  computed: {
    ...Object(external_vuex_map_fields_["mapFields"])('locker-room', ['lockerRoomActive', 'lockerRoomReply']),
    ...Object(external_vuex_map_fields_["mapFields"])('user', ['userID', 'userName', 'userAvatar']),
    ...Object(external_vuex_map_fields_["mapFields"])('channels', ['channelActive']),
    ...Object(external_vuex_map_fields_["mapFields"])('app', ['showLoader', 'showLiveChat']),
    ...Object(external_vuex_["mapGetters"])({
      getMediaFilesLocal: 'media/getMediaFilesLocal',
      getLockerRoomIsLoading: 'lockerRoom/getLockerRoomIsLoading'
    }),
    channelDetails() {
      var _this$channelActive;
      return ((_this$channelActive = this.channelActive) === null || _this$channelActive === void 0 ? void 0 : _this$channelActive.Livestream) || null;
    },
    initialDate() {
      var _this$channelDetails;
      return ((_this$channelDetails = this.channelDetails) === null || _this$channelDetails === void 0 ? void 0 : _this$channelDetails.startDate) || null;
    },
    date() {
      return external_moment_default()(this.initialDate, 'DD/MM/YYYY').format('DD MMMM YYYY');
    },
    link() {
      var _this$channelDetails2;
      return ((_this$channelDetails2 = this.channelDetails) === null || _this$channelDetails2 === void 0 ? void 0 : _this$channelDetails2.link) || null;
    },
    name() {
      var _this$channelDetails3;
      return ((_this$channelDetails3 = this.channelDetails) === null || _this$channelDetails3 === void 0 ? void 0 : _this$channelDetails3.title) || null;
    }
  },
  watch: {
    lockerRoomActive: {
      deep: true,
      handler(value) {
        this.isSupported = this.isSupported || (value === null || value === void 0 ? void 0 : value.isSupported);
      }
    },
    $route: {
      deep: true,
      immediate: true,
      handler() {
        this.$root.$emit('evtRtCancelEdit');
        this.clearChatDeleted();
      }
    }
  },
  async created() {
    var _this$channel, _Sports$;
    await this.$store.dispatch('locker-room/setLockerRoomActive', this.lockerRoom);
    this.lockerRoomReply = null;
    const {
      Club,
      League,
      FanGroup,
      Sports
    } = this.lockerRoomActive || {};
    this.metaTitle = `${(_this$channel = this.channel) === null || _this$channel === void 0 ? void 0 : _this$channel.name} | ${(League === null || League === void 0 ? void 0 : League.name) || (Club === null || Club === void 0 ? void 0 : Club.name) || (FanGroup === null || FanGroup === void 0 ? void 0 : FanGroup.name)} | ${(_Sports$ = Sports[0]) === null || _Sports$ === void 0 ? void 0 : _Sports$.name} - FX1`;
  },
  mounted() {
    this.socket = this.$nuxtSocket({
      channel: '/',
      auth: {
        token: this.$store.state.auth.token || null,
        type: 'desktop'
      },
      transports: ['websocket']
    });
    this.$root.$on('evtRtSendMessage', (message, reply, media, mentionsUserIDs) => {
      this.fnSendMessage(message, reply, media, mentionsUserIDs);
    });
    this.$root.$on('evtRtEditMessage', data => {
      this.fnEditMessage(data);
    });
    this.$root.$on('evtRtDeleteMessage', data => {
      this.fnDeleteMessage(data);
    });
    this.fnConnectToChannel();

    // RECEIVED MESSAGE
    this.socket.on('on-message', data => {
      this.chats.push(data.chat);
    });

    // EDIT MESSAGE
    this.socket.on('on-edit-message', data => {
      if (!data.chat) return;
      map_default()(this.chats, function (chat) {
        if (chat.chatID === data.chat.chatID) {
          chat.text = data.chat.text;
          chat.isEdited = true;
        }
      });
    });

    // DELETE MESSAGE
    this.socket.on('on-delete-message', data => {
      var _data$chat;
      if (!data.chat) return;
      const index = findIndex_default()(this.chats, {
        chatID: data.chat.chatID
      });
      if (data !== null && data !== void 0 && (_data$chat = data.chat) !== null && _data$chat !== void 0 && _data$chat.isDeletedEveryone) {
        this.chats.splice(index, 1);
        this.fnDeleteReply({
          chatID: data.chat.chatID,
          deleteForSelf: false,
          deleteForEveryone: true
        });
      }
    });

    // TYPING MESSAGE
    this.socket.on('on-typing-message-v2', data => {
      this.usersTyping = data.filter(({
        username,
        channelSlug
      }) => username && channelSlug === this.channelActive.slug).map(({
        username
      }) => username);
    });

    // SERVER LOGS
    this.socket.on('logs', data => {
      // this.$toast.info(JSON.stringify(data))
      console.log('SERVERLOGS', data);
    });
    this.clearLockerRoomDeletedManagers();
    this.$root.$on('evtRtGetChannel', () => {
      this.fnGetChannel();
    });
    this.channelActive = this.channel;
    this.$root.$on('evtRtIsTyping', user => {
      this.fnTypingMessage({
        userName: user.userName,
        status: true
      });
    });
    this.$root.$on('evtRtDoneTyping', user => {
      this.fnTypingMessage({
        userName: user.userName,
        status: false
      });
    });
    this.fnRetrieveIsSupported();
  },
  beforeDestroy() {
    if (this.oldChannel) {
      this.$root.$emit('evtReloadLockerRoom', this.oldChannel);
    }
    this.$root.$off('evtRtSendMessage');
  },
  methods: {
    ...Object(external_vuex_["mapActions"])({
      clearLockerRoomDeletedManagers: 'locker-room/clearLockerRoomDeletedManagers',
      clearChatDeleted: 'chats/clearChatDeleted',
      setLockerRoomIsLoading: 'lockerRoom/setLockerRoomIsLoading',
      clearSelectedGift: 'giphy/clearSelectedGif'
    }),
    async fnSendMessage(message, reply, media, mentionsUserIDs) {
      try {
        const chat = {
          User: {
            username: this.userName || 'FX1 User',
            Avatar: this.userAvatar,
            id: this.userID
          },
          chatID: Object(external_uuid_["v4"])(),
          text: message,
          channelSlug: this.$route.params.channel,
          lockerRoomSlug: this.$route.params.slug,
          repliedTo: reply ? {
            User: {
              username: reply === null || reply === void 0 ? void 0 : reply.name,
              id: reply === null || reply === void 0 ? void 0 : reply.userID
            },
            gif: reply === null || reply === void 0 ? void 0 : reply.gif,
            text: reply === null || reply === void 0 ? void 0 : reply.text,
            chatID: reply === null || reply === void 0 ? void 0 : reply.chatID,
            Media: reply === null || reply === void 0 ? void 0 : reply.Media
          } : null,
          Media: media.length ? media : null,
          MentionedUserIDs: mentionsUserIDs
        };
        await this.socket.emit('send-message', chat, () => {});
        chat.localMedia = this.getMediaFilesLocal || null;
        chat.replyLocalMedia = (reply === null || reply === void 0 ? void 0 : reply.localMedia) || null;
        this.chats.push(chat);
        const lockerRoom = this.lockerRoomActive;
        const channel = this.channelActive;
        this.$mixpanelClient.trackSendMessage({
          channel,
          lockerRoom,
          reply
        });
        this.$nextTick(() => {
          this.$root.$emit('evtRtScrollToBottom');
        });
        await this.clearSelectedGift();
      } catch (error) {} finally {
        const input = document.querySelector('.chat-input');
        input === null || input === void 0 ? void 0 : input.focus();
      }
    },
    async fnEditMessage({
      chatID,
      text,
      repliedToChatID,
      Media
    }) {
      await this.socket.emit('edit-message', {
        channelSlug: this.$route.params.channel,
        chatID,
        text,
        repliedToChatID,
        Media
      }, () => {});
    },
    async fnDeleteMessage({
      chatID,
      deleteForSelf,
      deleteForEveryone
    }) {
      await this.socket.emit('delete-message', {
        channelSlug: this.$route.params.channel,
        chatID,
        isDeletedSelf: deleteForSelf,
        isDeletedEveryone: deleteForEveryone
      }, () => {
        this.fnDeleteReply({
          chatID,
          deleteForSelf,
          deleteForEveryone
        });
      });
    },
    fnConnectToChannel() {
      this.oldChannel = this.$route.params.channel || null;
      if (this.oldChannel) {
        this.$root.$emit('evtReloadLockerRoom', this.oldChannel);
      }
      this.socket.emit('join-channel', {
        channelSlug: this.$route.params.channel
      }, ( /* resp */
      ) => {
        const lockerRoom = this.lockerRoomActive;
        const channel = this.channelActive;
        const params = {
          lockerRoom,
          channel,
          pageName: 'Locker room channel - livestream',
          isLoggedIn: this.isLoggedIn
        };
        this.$mixpanelClient.trackViewPage(params);
        // const data = resp.map((e) => {
        //   const repliedTo = e?.repliedTo
        //   return {
        //     ...e,
        //     ...{
        //       Reply: e?.repliedTo
        //         ? {
        //             text: repliedTo?.text,
        //             date: repliedTo?.date,
        //             chatID: repliedTo?.chatID,
        //             name: repliedTo?.User?.username,
        //           }
        //         : null,
        //     },
        //   }
        // })
        // for (const item in data) {
        //   this.chats.push(data[item])
        // }
        this.$store.dispatch('notification/clearActiveChannelNotification', this.$route.params.channel);
        this.reloadUnreadChats();
      });
    },
    async fnGetChannel() {
      var _this$$route$params;
      const slug = (_this$$route$params = this.$route.params) === null || _this$$route$params === void 0 ? void 0 : _this$$route$params.channel;
      const {
        getChannel
      } = await this.$api.getChannel({
        slug
      });
      this.channel = getChannel;
    },
    async fnRetrievePageDetails() {
      var _this$$route, _this$$route$params2, _this$$route2, _this$$route2$params;
      const slug = (_this$$route = this.$route) === null || _this$$route === void 0 ? void 0 : (_this$$route$params2 = _this$$route.params) === null || _this$$route$params2 === void 0 ? void 0 : _this$$route$params2.slug;
      const slugChannel = (_this$$route2 = this.$route) === null || _this$$route2 === void 0 ? void 0 : (_this$$route2$params = _this$$route2.params) === null || _this$$route2$params === void 0 ? void 0 : _this$$route2$params.channel;
      const params = {
        channelSlug: this.$route.params.channel
      };

      // async await parallel
      const [{
        getMessagesByChannelSlug: {
          items
        }
      }, {
        getChannel
      }, {
        getLockerRoom
      }] = await Promise.all([this.$api.getMessagesByChannelSlug(params), this.$api.getChannel({
        slug: slugChannel
      }), this.$api.getLockerRoom({
        slug
      })]);
      const chats = [];
      chats.push(...items);
      this.isSupported = getLockerRoom === null || getLockerRoom === void 0 ? void 0 : getLockerRoom.isSupported;
      this.channel = getChannel;
      this.lockerRoom = getLockerRoom;
      this.chats = chats;
    },
    fnDeleteReply({
      chatID,
      deleteForEveryone,
      deleteForSelf
    }) {
      map_default()(this.chats, function (data) {
        var _data$repliedTo;
        if (((_data$repliedTo = data.repliedTo) === null || _data$repliedTo === void 0 ? void 0 : _data$repliedTo.chatID) === chatID) {
          data.repliedTo = {
            ...{
              isDeletedEveryone: deleteForEveryone,
              isDeletedSelf: deleteForSelf
            },
            ...data.repliedTo
          };
        }
      });
    },
    fnTypingMessage({
      userName,
      status
    }) {
      this.socket.emit('typing-message-v2', {
        channelSlug: this.$route.params.channel,
        userName,
        isTyping: status
      });
    },
    async reloadUnreadChats() {
      if (!this.isLoggedIn) return;
      const {
        Me: {
          Supporting
        }
      } = await this.$api.getMyProfileSupporting();
      if (!Supporting) return;
      const initialCount = [];
      await (Supporting === null || Supporting === void 0 ? void 0 : Supporting.map(data => {
        return initialCount.push({
          slug: data.slug,
          totalUnreadMessagesCount: data.totalUnreadMessagesCount
        });
      }));
      await this.$store.dispatch('notification/setLockerRoomCount', initialCount);
    },
    async fnRetrieveIsSupported() {
      try {
        var _this$$route$params3;
        const {
          getLockerRoom: {
            isSupported
          }
        } = await this.$api.getLockerRoomIsSupported({
          slug: (_this$$route$params3 = this.$route.params) === null || _this$$route$params3 === void 0 ? void 0 : _this$$route$params3.slug
        });
        this.isSupported = isSupported;
      } catch (error) {} finally {
        this.setLockerRoomIsLoading(false);
      }
    }
  }
});
// CONCATENATED MODULE: ./pages/locker-room/_slug/live/_channel/index.vue?vue&type=script&lang=js&
 /* harmony default export */ var live_channelvue_type_script_lang_js_ = (_channelvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./pages/locker-room/_slug/live/_channel/index.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1029)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  live_channelvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "cb17a90a",
  "2134c298"
  
)

/* harmony default export */ var _channel = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 435:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ({
  data() {
    return {
      metaTitle: '',
      metaDescription: 'Show the world who you support'
    };
  },
  head() {
    var _this$$route;
    return {
      title: this.metaTitle || 'FX1',
      link: [{
        rel: 'canonical',
        href: `${this.baseURL}${(_this$$route = this.$route) === null || _this$$route === void 0 ? void 0 : _this$$route.fullPath}`
      }],
      meta: [{
        hid: 'description',
        name: 'description',
        content: this.metaDescription.replace(/<\/?[^>]+(>|$)/g, '')
      }, {
        hid: 'twitter:title',
        name: 'twitter:title',
        content: this.metaTitle
      }, {
        hid: 'twitter:description',
        name: 'twitter:description',
        content: this.metaDescription.replace(/<\/?[^>]+(>|$)/g, '')
      }, {
        hid: 'twitter:image',
        name: 'twitter:image',
        content: this.fx1Logo
      }, {
        hid: 'twitter:image:alt',
        name: 'twitter:image:alt',
        content: this.metaTitle
      }, {
        hid: 'og:title',
        property: 'og:title',
        content: this.metaTitle
      }, {
        hid: 'og:description',
        property: 'og:description',
        content: this.metaDescription.replace(/<\/?[^>]+(>|$)/g, '')
      }, {
        hid: 'og:image',
        property: 'og:image',
        content: this.fx1Logo
      }, {
        hid: 'og:image:secure_url',
        property: 'og:image:secure_url',
        content: this.fx1Logo
      }, {
        hid: 'og:image:alt',
        property: 'og:image:alt',
        content: this.metaTitle
      }]
    };
  }
});

/***/ }),

/***/ 582:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCiAgPHBhdGggZD0iTTIwIDExSDcuODNMMTMuNDIgNS40MUwxMiA0TDQgMTJMMTIgMjBMMTMuNDEgMTguNTlMNy44MyAxM0gyMFYxMVoiIGZpbGw9IndoaXRlIi8+DQo8L3N2Zz4NCg=="

/***/ }),

/***/ 583:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/live.d8dab2b.svg";

/***/ }),

/***/ 584:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/calendar.2c2a19d.svg";

/***/ }),

/***/ 858:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1030);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("2d84c405", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=index.js.map
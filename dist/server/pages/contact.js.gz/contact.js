exports.ids = [35,0];
exports.modules = {

/***/ 1005:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Contact_vue_vue_type_style_index_0_id_a6dc607e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(846);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Contact_vue_vue_type_style_index_0_id_a6dc607e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Contact_vue_vue_type_style_index_0_id_a6dc607e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Contact_vue_vue_type_style_index_0_id_a6dc607e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Contact_vue_vue_type_style_index_0_id_a6dc607e_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 1006:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".xp-contact[data-v-a6dc607e]{min-height:calc(100vh - 111px);background-color:#0c353e;border-bottom:1px solid #1c3e45;background-size:cover;background-position:50%;background-repeat:no-repeat;padding:45px 0;display:flex;flex-wrap:wrap;align-items:center;position:relative}.xp-contact[data-v-a6dc607e] h1{font-size:4.2857rem;font-weight:500;line-height:1.2;letter-spacing:0}.xp-contact[data-v-a6dc607e] .banner{min-height:220px;background-size:cover;background-position:50%;padding:0 15px;display:none;flex-wrap:wrap;align-items:center;color:#fff;position:relative}.xp-contact[data-v-a6dc607e] .banner .text-center{position:relative;z-index:1}.xp-contact[data-v-a6dc607e] .contents{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center}.xp-contact[data-v-a6dc607e] .contents .left-content{flex:10000 1 0%;padding-right:.75rem}.xp-contact[data-v-a6dc607e] .contents .left-content h1{color:#fff}.xp-contact[data-v-a6dc607e] .contents .right-content{width:100%;max-width:475px;padding-left:.75rem}.xp-contact[data-v-a6dc607e] .contents .right-content .actions .button{height:82px}@media screen and (max-width:1023px){.xp-contact[data-v-a6dc607e] .contents .left-content,.xp-contact[data-v-a6dc607e] .contents .right-content{width:100%;max-width:50%}}@media screen and (max-width:767px){.xp-contact[data-v-a6dc607e]{background-image:none;padding:0 0 45px}.xp-contact[data-v-a6dc607e] h1{font-size:2.2857rem;text-align:center}.xp-contact[data-v-a6dc607e] .banner{display:flex}.xp-contact[data-v-a6dc607e] .contents{padding-top:1.5rem;padding-bottom:3rem}.xp-contact[data-v-a6dc607e] .contents .left-content{display:none}.xp-contact[data-v-a6dc607e] .contents .right-content{max-width:100%}.xp-contact[data-v-a6dc607e] .contents .right-content .input-error{color:#f14668!important}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 1312:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./pages/contact.vue?vue&type=template&id=76cb17ec&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('XPContact')}
var staticRenderFns = []


// CONCATENATED MODULE: ./pages/contact.vue?vue&type=template&id=76cb17ec&lang=pug&

// EXTERNAL MODULE: ./mixins/meta.js
var meta = __webpack_require__(435);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/Contact.vue?vue&type=template&id=a6dc607e&scoped=true&lang=pug&
var Contactvue_type_template_id_a6dc607e_scoped_true_lang_pug_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xp-contact"},[_vm._ssrNode("<div class=\"banner\" data-v-a6dc607e><div class=\"text-center\" data-v-a6dc607e><h1 data-v-a6dc607e>We would love to hear from you</h1><p data-v-a6dc607e>No matter if you`re a fan with a question, or a club or league looking to get involved, we would love to hear from you.</p></div></div>"),_vm._ssrNode("<div class=\"container is-max-widescreen\" data-v-a6dc607e>","</div>",[_vm._ssrNode("<div class=\"contents\" data-v-a6dc607e>","</div>",[_vm._ssrNode("<div class=\"left-content\" data-v-a6dc607e><h1 data-v-a6dc607e>We would love to hear from you</h1><h3 data-v-a6dc607e>No matter if you`re a fan with a question, or a club or league looking to get involved, we would love to hear from you.</h3></div>"),_vm._ssrNode("<div class=\"right-content\" data-v-a6dc607e>","</div>",[_vm._ssrNode("<form action=\"#\" autocomplete=\"off\" data-v-a6dc607e>","</form>",[_vm._ssrNode("<div class=\"columns\" data-v-a6dc607e>","</div>",[_vm._ssrNode("<div class=\"column is-6\" data-v-a6dc607e>","</div>",[_c('FormInput',{attrs:{"placeholder":"First Name","disabled":_vm.isSubmitting,"error":_vm.validation.firstError('firstName'),"error-class":"has-text-white"},model:{value:(_vm.firstName),callback:function ($$v) {_vm.firstName=$$v},expression:"firstName"}})],1),_vm._ssrNode("<div class=\"column is-6\" data-v-a6dc607e>","</div>",[_c('FormInput',{attrs:{"placeholder":"Last Name","disabled":_vm.isSubmitting,"error":_vm.validation.firstError('lastName'),"error-class":"has-text-white"},model:{value:(_vm.lastName),callback:function ($$v) {_vm.lastName=$$v},expression:"lastName"}})],1)]),_vm._ssrNode("<div class=\"mb-5\" data-v-a6dc607e>","</div>",[_c('FormInput',{attrs:{"error":_vm.validation.firstError('sportingOrganization'),"placeholder":"Sporting Organization","disabled":_vm.isSubmitting},model:{value:(_vm.sportingOrganization),callback:function ($$v) {_vm.sportingOrganization=$$v},expression:"sportingOrganization"}})],1),_vm._ssrNode("<div class=\"mb-5\" data-v-a6dc607e>","</div>",[_c('FormInput',{attrs:{"placeholder":"Email","disabled":_vm.isSubmitting,"error":_vm.validation.firstError('email'),"error-class":"has-text-white"},model:{value:(_vm.email),callback:function ($$v) {_vm.email=$$v},expression:"email"}})],1),_vm._ssrNode("<div class=\"mb-5\" data-v-a6dc607e>","</div>",[_c('FormInput',{attrs:{"type":"text","placeholder":"Phone Number","disabled":_vm.isSubmitting},model:{value:(_vm.phoneNumber),callback:function ($$v) {_vm.phoneNumber=$$v},expression:"phoneNumber"}})],1),_vm._ssrNode("<div class=\"mb-6\" data-v-a6dc607e>","</div>",[_c('FormInput',{attrs:{"type":"textarea","placeholder":"I'm messaging because...","min-height":160,"disabled":_vm.isSubmitting,"isAutoGrow":true,"error":_vm.validation.firstError('message'),"error-class":"has-text-white"},model:{value:(_vm.message),callback:function ($$v) {_vm.message=$$v},expression:"message"}})],1),_vm._ssrNode("<div class=\"actions\" data-v-a6dc607e>","</div>",[_c('b-button',{staticClass:"is-uppercase",attrs:{"type":"is-primary","expanded":"","loading":_vm.isSubmitting},on:{"click":function($event){$event.preventDefault();return _vm.doSubmitEnquiry()}}},[_vm._v("Send Enquiry")])],1)])])],2)])],2)}
var Contactvue_type_template_id_a6dc607e_scoped_true_lang_pug_staticRenderFns = []


// CONCATENATED MODULE: ./components/pages/Contact.vue?vue&type=template&id=a6dc607e&scoped=true&lang=pug&

// EXTERNAL MODULE: external "simple-vue-validator"
var external_simple_vue_validator_ = __webpack_require__(37);

// EXTERNAL MODULE: ./components/atoms/Forms/Input.vue + 4 modules
var Input = __webpack_require__(991);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/pages/Contact.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ var Contactvue_type_script_lang_js_ = ({
  name: 'XPContact',
  components: {
    FormInput: Input["default"]
  },
  validators: {
    firstName(value) {
      return external_simple_vue_validator_["Validator"].value(value).required('First Name field is required.');
    },
    lastName(value) {
      return external_simple_vue_validator_["Validator"].value(value).required('Last Name field is required.');
    },
    email(value) {
      return external_simple_vue_validator_["Validator"].value(value).required('Email field is required.').email("That doesn't look like a valid email.");
    },
    message(value) {
      return external_simple_vue_validator_["Validator"].value(value).required('Message field is required.');
    },
    sportingOrganization(value) {
      return external_simple_vue_validator_["Validator"].value(value).required('Sporting field is required.');
    }
  },
  data() {
    return {
      firstName: '',
      lastName: '',
      email: '',
      phoneNumber: '',
      message: '',
      sportingOrganization: '',
      isSubmitting: false
    };
  },
  methods: {
    doSubmitEnquiry() {
      this.isSubmitting = true;
      this.$validate().then(async success => {
        if (success) {
          try {
            const input = {
              sportingOrganization: this.sportingOrganization,
              message: this.message,
              email: this.email,
              firstName: this.firstName,
              lastName: this.lastName,
              phoneNumber: this.phoneNumber
            };
            let e;
            try {
              await this.$api.createFormEntry({
                type: 'Inquiry',
                data: input
              });
            } catch (error) {
              e = error;
              this.$toast.error('Something went wrong , Please try again!.', {
                duration: 5000,
                position: 'top-center'
              });
            } finally {
              if (!e) this.$toast.success('Thank you, we’ll review your message and get back to you shortly.', {
                duration: 5000,
                position: 'top-center'
              });
            }
            e = null;
            this.firstName = '';
            this.lastName = '';
            this.email = '';
            this.phoneNumber = '';
            this.message = '';
            this.sportingOrganization = '';
            this.validation.reset();
            // this.setMedalEnquiryMessage()
          } catch (error) {
            var _error$response;
            error === null || error === void 0 ? void 0 : (_error$response = error.response) === null || _error$response === void 0 ? void 0 : _error$response.errors.forEach(error => {
              this.$toast.success(error.message, {
                duration: 5000,
                position: 'bottom-left',
                className: 'fx1-success',
                iconPack: 'mdi',
                icon: 'alert-circle-outline'
              });
            });
          } finally {
            this.isSubmitting = false;
          }
        } else {
          this.isSubmitting = false;
        }
      });
    }
  }
});
// CONCATENATED MODULE: ./components/pages/Contact.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_Contactvue_type_script_lang_js_ = (Contactvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/pages/Contact.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(1005)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pages_Contactvue_type_script_lang_js_,
  Contactvue_type_template_id_a6dc607e_scoped_true_lang_pug_render,
  Contactvue_type_template_id_a6dc607e_scoped_true_lang_pug_staticRenderFns,
  false,
  injectStyles,
  "a6dc607e",
  "35558ee4"
  
)

/* harmony default export */ var Contact = (component.exports);
// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./pages/contact.vue?vue&type=script&lang=js&
//
//
//
//



/* harmony default export */ var contactvue_type_script_lang_js_ = ({
  components: {
    XPContact: Contact
  },
  mixins: [meta["a" /* default */]],
  created() {
    this.metaTitle = 'Contact';
  },
  mounted() {
    const params = {
      pageName: 'Contact us',
      isLoggedIn: this.isLoggedIn
    };
    this.$mixpanelClient.trackViewPage(params);
  }
});
// CONCATENATED MODULE: ./pages/contact.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_contactvue_type_script_lang_js_ = (contactvue_type_script_lang_js_); 
// CONCATENATED MODULE: ./pages/contact.vue





/* normalize component */

var contact_component = Object(componentNormalizer["a" /* default */])(
  pages_contactvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  "5a5f25cc"
  
)

/* harmony default export */ var contact = __webpack_exports__["default"] = (contact_component.exports);

/***/ }),

/***/ 435:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ({
  data() {
    return {
      metaTitle: '',
      metaDescription: 'Show the world who you support'
    };
  },
  head() {
    var _this$$route;
    return {
      title: this.metaTitle || 'FX1',
      link: [{
        rel: 'canonical',
        href: `${this.baseURL}${(_this$$route = this.$route) === null || _this$$route === void 0 ? void 0 : _this$$route.fullPath}`
      }],
      meta: [{
        hid: 'description',
        name: 'description',
        content: this.metaDescription.replace(/<\/?[^>]+(>|$)/g, '')
      }, {
        hid: 'twitter:title',
        name: 'twitter:title',
        content: this.metaTitle
      }, {
        hid: 'twitter:description',
        name: 'twitter:description',
        content: this.metaDescription.replace(/<\/?[^>]+(>|$)/g, '')
      }, {
        hid: 'twitter:image',
        name: 'twitter:image',
        content: this.fx1Logo
      }, {
        hid: 'twitter:image:alt',
        name: 'twitter:image:alt',
        content: this.metaTitle
      }, {
        hid: 'og:title',
        property: 'og:title',
        content: this.metaTitle
      }, {
        hid: 'og:description',
        property: 'og:description',
        content: this.metaDescription.replace(/<\/?[^>]+(>|$)/g, '')
      }, {
        hid: 'og:image',
        property: 'og:image',
        content: this.fx1Logo
      }, {
        hid: 'og:image:secure_url',
        property: 'og:image:secure_url',
        content: this.fx1Logo
      }, {
        hid: 'og:image:alt',
        property: 'og:image:alt',
        content: this.metaTitle
      }]
    };
  }
});

/***/ }),

/***/ 573:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(679);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("74fa9b2e", content, true, context)
};

/***/ }),

/***/ 678:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Input_vue_vue_type_style_index_0_id_33d861d7_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(573);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Input_vue_vue_type_style_index_0_id_33d861d7_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Input_vue_vue_type_style_index_0_id_33d861d7_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Input_vue_vue_type_style_index_0_id_33d861d7_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_7_oneOf_1_4_node_modules_vue_loader_lib_index_js_vue_loader_options_Input_vue_vue_type_style_index_0_id_33d861d7_prod_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 679:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(6);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".input-error[data-v-33d861d7],.message-alert[data-v-33d861d7]{color:#f85454!important;font-size:10px}.xa-forms-input[data-v-33d861d7].has-error .field .control input[type=password],.xa-forms-input[data-v-33d861d7].has-error .field .control input[type=text],.xa-forms-input[data-v-33d861d7].has-error .field .control textarea{border-color:#f85454!important}.xa-forms-input[data-v-33d861d7].has-error .field .control .icon.is-right{color:#f85454!important}.xa-forms-input[data-v-33d861d7] .field{margin-bottom:3px}.xa-forms-input[data-v-33d861d7] .field .label{font-size:1rem;font-weight:400;margin-bottom:3px;color:#050505}.xa-forms-input[data-v-33d861d7] .field .control input[type=password],.xa-forms-input[data-v-33d861d7] .field .control input[type=text],.xa-forms-input[data-v-33d861d7] .field .control textarea{font-size:1.1429rem;font-weight:300;line-height:1.7143rem;box-shadow:none;color:#050505;border:1px solid #dbdbdb;border-radius:5px;height:56px}.xa-forms-input[data-v-33d861d7] .field .control input[type=password]::-moz-placeholder,.xa-forms-input[data-v-33d861d7] .field .control input[type=text]::-moz-placeholder,.xa-forms-input[data-v-33d861d7] .field .control textarea::-moz-placeholder{color:#65676b}.xa-forms-input[data-v-33d861d7] .field .control input[type=password]::placeholder,.xa-forms-input[data-v-33d861d7] .field .control input[type=text]::placeholder,.xa-forms-input[data-v-33d861d7] .field .control textarea::placeholder{color:#65676b}.xa-forms-input[data-v-33d861d7] .field .control input[type=password]:-ms-input-placeholder,.xa-forms-input[data-v-33d861d7] .field .control input[type=text]:-ms-input-placeholder,.xa-forms-input[data-v-33d861d7] .field .control textarea:-ms-input-placeholder{color:#65676b}.xa-forms-input[data-v-33d861d7] .field .control textarea{resize:none}.xa-forms-input[data-v-33d861d7] .field .control textarea+.icon{top:5px;bottom:unset}.xa-forms-input[data-v-33d861d7] .field .control .icon{bottom:0;margin:auto 0;right:5px}.xa-forms-input[data-v-33d861d7] .field .control.is-loading:after{top:0;bottom:0;margin:auto 0;right:10px}.xa-forms-input[data-v-33d861d7].input-outlined .field .control input[type=password],.xa-forms-input[data-v-33d861d7].input-outlined .field .control input[type=text]{background-color:transparent;border-color:#2a4e55;color:#fff}.xa-forms-input[data-v-33d861d7].input-outlined .field .control input[type=password]::-moz-placeholder,.xa-forms-input[data-v-33d861d7].input-outlined .field .control input[type=text]::-moz-placeholder{color:#94a6aa}.xa-forms-input[data-v-33d861d7].input-outlined .field .control input[type=password]::placeholder,.xa-forms-input[data-v-33d861d7].input-outlined .field .control input[type=text]::placeholder{color:#94a6aa}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 846:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1006);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(7).default
module.exports.__inject__ = function (context) {
  add("13c87918", content, true, context)
};

/***/ }),

/***/ 991:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/pug-plain-loader??ref--1-oneOf-0-0!./node_modules/vue-loader/lib??vue-loader-options!./components/atoms/Forms/Input.vue?vue&type=template&id=33d861d7&scoped=true&lang=pug&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"xa-forms-input",class:[_vm.error && 'has-error', _vm.outlined && 'input-outlined']},[_c('b-field',{attrs:{"label":_vm.label,"message":_vm.message}},[_c('b-input',{attrs:{"autocomplete":"off","expanded":"","value":_vm.value,"type":_vm.type,"placeholder":_vm.placeholder,"password-reveal":_vm.isPassword,"icon-right":(_vm.error && 'message-alert') || (!_vm.error && _vm.iconOnRight),"disabled":_vm.disabled,"loading":_vm.loading,"icon-right-clickable":_vm.iconRightClickable,"id":_vm.id},on:{"input":function($event){return _vm.$emit('input', $event)},"blur":_vm.handleBlur,"focus":_vm.handleFocus,"icon-right-click":function($event){return _vm.$emit('icon-on-right-click', $event)}},nativeOn:{"keyup":function($event){if(!$event.type.indexOf('key')&&_vm._k($event.keyCode,"enter",13,$event.key,"Enter")){ return null; }return _vm.$emit('enter', $event)}}})],1),_vm._ssrNode(((_vm.error)?("<div class=\"input-error\" data-v-33d861d7>"+_vm._ssrEscape(_vm._s(_vm.error))+"</div>"):"<!---->"))],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/atoms/Forms/Input.vue?vue&type=template&id=33d861d7&scoped=true&lang=pug&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/atoms/Forms/Input.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Inputvue_type_script_lang_js_ = ({
  name: 'XAFormsInput',
  props: {
    outlined: {
      type: Boolean,
      default: false
    },
    label: {
      type: String,
      default: ''
    },
    hasLabel: {
      type: Boolean,
      default: true
    },
    value: {
      type: String,
      default: ''
    },
    message: {
      type: String,
      default: ''
    },
    type: {
      type: String,
      default: 'text'
    },
    placeholder: {
      type: String,
      default: ''
    },
    disabled: {
      type: Boolean,
      default: false
    },
    loading: {
      type: Boolean,
      default: false
    },
    error: {
      type: String,
      default: ''
    },
    id: {
      type: String,
      default: ''
    },
    iconOnRight: {
      type: String,
      default: null
    },
    iconOnRightClick: {
      type: Function,
      default: null
    }
  },
  computed: {
    isPassword() {
      return this.type === 'password';
    },
    iconRightClickable() {
      return !!this.iconOnRight;
    }
  },
  methods: {
    handleFocus(e) {
      this.$emit('focus', e);
    },
    handleBlur(e) {
      this.$emit('blur', e);
    }
  }
});
// CONCATENATED MODULE: ./components/atoms/Forms/Input.vue?vue&type=script&lang=js&
 /* harmony default export */ var Forms_Inputvue_type_script_lang_js_ = (Inputvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/atoms/Forms/Input.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(678)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  Forms_Inputvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "33d861d7",
  "f44113ae"
  
)

/* harmony default export */ var Input = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=contact.js.map